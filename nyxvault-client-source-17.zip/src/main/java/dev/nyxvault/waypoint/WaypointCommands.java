package dev.nyxvault.waypoint;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.util.Notifications;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** /nyx wp add|addat|list|select|remove|toggle|group|export|import */
public final class WaypointCommands {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private WaypointCommands() { }

    private static void say(FabricClientCommandSource src, String msg) { src.sendFeedback(Component.literal("[NYX] " + msg)); }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        var wp = ClientCommandManager.literal("wp")
                .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            Waypoint w = NyxvaultClient.waypoints().addHere(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), w == null ? "Вы не в мире." : "Добавлено: " + w.name);
                            return 1;
                        })))
                .then(ClientCommandManager.literal("addat")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .then(ClientCommandManager.argument("x", DoubleArgumentType.doubleArg())
                                        .then(ClientCommandManager.argument("y", DoubleArgumentType.doubleArg())
                                                .then(ClientCommandManager.argument("z", DoubleArgumentType.doubleArg()).executes(c -> {
                                                    Minecraft mc = Minecraft.getInstance();
                                                    if (mc.level == null) { say(c.getSource(), "Вы не в мире."); return 0; }
                                                    Waypoint w = new Waypoint();
                                                    w.name = StringArgumentType.getString(c, "name");
                                                    w.x = DoubleArgumentType.getDouble(c, "x");
                                                    w.y = DoubleArgumentType.getDouble(c, "y");
                                                    w.z = DoubleArgumentType.getDouble(c, "z");
                                                    w.dimension = mc.level.dimension().toString();
                                                    NyxvaultClient.waypoints().add(w);
                                                    say(c.getSource(), "Добавлено: " + w.name);
                                                    return 1;
                                                }))))))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    List<Waypoint> l = NyxvaultClient.waypoints().search("", true);
                    if (l.isEmpty()) say(c.getSource(), "Меток нет.");
                    Minecraft mc = Minecraft.getInstance();
                    for (Waypoint w : l) {
                        String dist = mc.player == null ? "?" : String.format("%.0f м", w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
                        say(c.getSource(), String.format("%s%s [%s] (%d, %d, %d) %s%s", w.id.equals(NyxvaultClient.waypoints().activeId()) ? "* " : "",
                                w.name, w.group, (int) w.x, (int) w.y, (int) w.z, dist, w.enabled ? "" : " (выкл.)"));
                    }
                    return 1;
                }))
                .then(ClientCommandManager.literal("select")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            boolean ok = NyxvaultClient.waypoints().select(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), ok ? "Выбрана." : "Не найдена.");
                            return ok ? 1 : 0;
                        })))
                .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            boolean ok = NyxvaultClient.waypoints().remove(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), ok ? "Удалена." : "Не найдена.");
                            return ok ? 1 : 0;
                        })))
                .then(ClientCommandManager.literal("toggle")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            Waypoint w = NyxvaultClient.waypoints().find(StringArgumentType.getString(c, "name"));
                            if (w == null) { say(c.getSource(), "Не найдена."); return 0; }
                            w.enabled = !w.enabled;
                            ConfigManager.requestSave();
                            say(c.getSource(), w.name + (w.enabled ? " включена" : " выключена"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("group")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .then(ClientCommandManager.argument("group", StringArgumentType.word()).executes(c -> {
                                    Waypoint w = NyxvaultClient.waypoints().find(StringArgumentType.getString(c, "name"));
                                    if (w == null) { say(c.getSource(), "Не найдена."); return 0; }
                                    w.group = StringArgumentType.getString(c, "group");
                                    ConfigManager.requestSave();
                                    say(c.getSource(), "Группа задана.");
                                    return 1;
                                }))))
                .then(ClientCommandManager.literal("export").executes(c -> {
                    try {
                        Path p = ConfigManager.dir().resolve("waypoints-export.json");
                        Files.createDirectories(p.getParent());
                        Files.writeString(p, GSON.toJson(NyxvaultClient.waypoints().all()), StandardCharsets.UTF_8);
                        say(c.getSource(), "Экспорт: " + p);
                        return 1;
                    } catch (Exception e) {
                        say(c.getSource(), "Ошибка экспорта: " + e.getMessage());
                        return 0;
                    }
                }))
                .then(ClientCommandManager.literal("import").executes(c -> {
                    try {
                        Path p = ConfigManager.dir().resolve("waypoints-export.json");
                        List<Waypoint> in = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), new TypeToken<List<Waypoint>>() { }.getType());
                        if (in == null) throw new IllegalStateException("empty file");
                        int ok = 0, bad = 0;
                        List<Waypoint> merged = new ArrayList<>(NyxvaultClient.waypoints().all());
                        for (Waypoint w : in) {
                            if (w != null && w.valid() && merged.stream().noneMatch(x -> x.id.equals(w.id))) { merged.add(w); ok++; } else bad++;
                        }
                        NyxvaultClient.waypoints().replaceAll(merged, NyxvaultClient.waypoints().activeId());
                        ConfigManager.requestSave();
                        say(c.getSource(), "Импортировано " + ok + ", пропущено " + bad);
                        Notifications.push("Импортировано меток: " + ok);
                        return 1;
                    } catch (Exception e) {
                        say(c.getSource(), "Ошибка импорта: " + e.getMessage());
                        return 0;
                    }
                }));

        d.register(ClientCommandManager.literal("nyx").then(wp));
        d.register(ClientCommandManager.literal("nyx").then(ClientCommandManager.literal("wp")
                .then(ClientCommandManager.literal("gui").executes(c -> {
                    dev.nyxvault.gui.WaypointScreen.pendingOpen = true; // opened on the next tick, after the chat closes
                    return 1;
                }))));
        d.register(ClientCommandManager.literal("nyx").then(ClientCommandManager.literal("coords").executes(c -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return 0;
            String t = (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ());
            mc.keyboardHandler.setClipboard(t);
            say(c.getSource(), "Скопировано: " + t);
            return 1;
        })));
    }
}
