package dev.nyxvault.waypoint;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.util.Notifications;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** /nyx wp add|addat|list|select|remove|toggle|group|export|import */
public final class WaypointCommands {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private WaypointCommands() { }

    private static void say(FabricClientCommandSource src, String msg) { src.sendFeedback(Component.literal("[NYX] " + msg)); }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        var wp = ClientCommandManager.literal("wp")
                .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            Waypoint w = NyxvaultClient.waypoints().addHere(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), w == null ? "Not in a world." : "Added " + w.name);
                            return 1;
                        })))
                .then(ClientCommandManager.literal("addat")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .then(ClientCommandManager.argument("x", DoubleArgumentType.doubleArg())
                                        .then(ClientCommandManager.argument("y", DoubleArgumentType.doubleArg())
                                                .then(ClientCommandManager.argument("z", DoubleArgumentType.doubleArg()).executes(c -> {
                                                    Minecraft mc = Minecraft.getInstance();
                                                    if (mc.level == null) { say(c.getSource(), "Not in a world."); return 0; }
                                                    Waypoint w = new Waypoint();
                                                    w.name = StringArgumentType.getString(c, "name");
                                                    w.x = DoubleArgumentType.getDouble(c, "x");
                                                    w.y = DoubleArgumentType.getDouble(c, "y");
                                                    w.z = DoubleArgumentType.getDouble(c, "z");
                                                    w.dimension = mc.level.dimension().toString();
                                                    NyxvaultClient.waypoints().add(w);
                                                    say(c.getSource(), "Added " + w.name);
                                                    return 1;
                                                }))))))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    List<Waypoint> l = NyxvaultClient.waypoints().search("", true);
                    if (l.isEmpty()) say(c.getSource(), "No waypoints.");
                    Minecraft mc = Minecraft.getInstance();
                    for (Waypoint w : l) {
                        String dist = mc.player == null ? "?" : String.format("%.0fm", w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
                        say(c.getSource(), String.format("%s%s [%s] (%d, %d, %d) %s%s", w.id.equals(NyxvaultClient.waypoints().activeId()) ? "* " : "",
                                w.name, w.group, (int) w.x, (int) w.y, (int) w.z, dist, w.enabled ? "" : " (off)"));
                    }
                    return 1;
                }))
                .then(ClientCommandManager.literal("select")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            boolean ok = NyxvaultClient.waypoints().select(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), ok ? "Selected." : "Not found.");
                            return ok ? 1 : 0;
                        })))
                .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            boolean ok = NyxvaultClient.waypoints().remove(StringArgumentType.getString(c, "name"));
                            say(c.getSource(), ok ? "Removed." : "Not found.");
                            return ok ? 1 : 0;
                        })))
                .then(ClientCommandManager.literal("toggle")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                            Waypoint w = NyxvaultClient.waypoints().find(StringArgumentType.getString(c, "name"));
                            if (w == null) { say(c.getSource(), "Not found."); return 0; }
                            w.enabled = !w.enabled;
                            ConfigManager.requestSave();
                            say(c.getSource(), w.name + (w.enabled ? " enabled" : " disabled"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("group")
                        .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .then(ClientCommandManager.argument("group", StringArgumentType.word()).executes(c -> {
                                    Waypoint w = NyxvaultClient.waypoints().find(StringArgumentType.getString(c, "name"));
                                    if (w == null) { say(c.getSource(), "Not found."); return 0; }
                                    w.group = StringArgumentType.getString(c, "group");
                                    ConfigManager.requestSave();
                                    say(c.getSource(), "Group set.");
                                    return 1;
                                }))))
                .then(ClientCommandManager.literal("export").executes(c -> {
                    try {
                        Path p = ConfigManager.dir().resolve("waypoints-export.json");
                        Files.createDirectories(p.getParent());
                        Files.writeString(p, GSON.toJson(NyxvaultClient.waypoints().all()), StandardCharsets.UTF_8);
                        say(c.getSource(), "Exported to " + p);
                        return 1;
                    } catch (Exception e) {
                        say(c.getSource(), "Export failed: " + e.getMessage());
                        return 0;
                    }
                }))
                .then(ClientCommandManager.literal("import").executes(c -> {
                    try {
                        Path p = ConfigManager.dir().resolve("waypoints-export.json");
                        List<Waypoint> in = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), new TypeToken<List<Waypoint>>() { }.getType());
                        if (in == null) throw new IllegalStateException("empty file");
                        int ok = 0, bad = 0;
                        List<Waypoint> merged = new ArrayList<>(NyxvaultClient.waypoints().all());
                        for (Waypoint w : in) {
                            if (w != null && w.valid() && merged.stream().noneMatch(x -> x.id.equals(w.id))) { merged.add(w); ok++; } else bad++;
                        }
                        NyxvaultClient.waypoints().replaceAll(merged, NyxvaultClient.waypoints().activeId());
                        ConfigManager.requestSave();
                        say(c.getSource(), "Imported " + ok + ", skipped " + bad);
                        Notifications.push("Imported " + ok + " waypoint(s)");
                        return 1;
                    } catch (Exception e) {
                        say(c.getSource(), "Import failed: " + e.getMessage());
                        return 0;
                    }
                }));

        d.register(ClientCommandManager.literal("nyx").then(wp));
    }
}
