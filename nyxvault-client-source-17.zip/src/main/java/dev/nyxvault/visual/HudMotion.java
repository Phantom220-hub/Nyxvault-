package dev.nyxvault.visual;

import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.Minecraft;

/**
 * Smooth enter/exit animation for HUD elements when you switch them on or off. It only changes how
 * HUD boxes are drawn (position offset, alpha, scale); it never touches gameplay and uses no blur.
 * Reduced Motion replaces slide/scale with a quick fade. Applies to every draggable HUD element
 * (global settings; per-element animation settings are not provided).
 */
public final class HudMotion extends Module {
    public enum Style { SLIDE_FADE, SLIDE, FADE, SCALE }

    private static HudMotion instance;

    private final EnumSetting<Style> style = add(new EnumSetting<>("Style", Style.SLIDE_FADE));
    private final NumberSetting speed = add(NumberSetting.decimal("Animation Speed", 1.0, 0.5, 3.0, 0.1));
    private final NumberSetting intensity = add(NumberSetting.decimal("Animation Intensity", 1.0, 0.0, 2.0, 0.1));
    private final BoolSetting reduced = add(new BoolSetting("Reduced Motion", false));

    /** Output of {@link #apply}: pixel offset, scale factor (set per element before drawing). */
    public static float dx, dy, sc = 1f;
    private static long lastNs;
    private static float dt = 0.016f;

    public HudMotion() {
        super("HUD Motion", "Smooth slide/fade/scale animation when HUD elements appear and disappear.", Category.VISUALS);
        instance = this;
    }

    public static boolean active() { return instance != null && instance.enabled(); }

    /** Call once per frame before drawing HUD elements. */
    public static void beginFrame() {
        long now = System.nanoTime();
        dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
    }

    /** Moves the element's animation value toward on/off. Without HUD Motion it snaps. */
    public static void step(HudModule h, boolean on) {
        if (!active() || !h.motionInit) { h.motion = on ? 1f : 0f; h.motionInit = true; return; }
        float sp = 6f * instance.speed.asFloat() * (instance.reduced.get() ? 1.5f : 1f);
        h.motion += (on ? 1f : -1f) * sp * dt;
        h.motion = Math.max(0f, Math.min(1f, h.motion));
    }

    /** True while a switched-off element is still animating out and must be drawn. */
    public static boolean exiting(HudModule h) { return active() && h.motion > 0.01f; }

    /**
     * Computes offsets for one element; returns its alpha multiplier (0..1).
     * @param b bounds {x, y, w, h} in GUI pixels
     */
    public static float apply(HudModule h, int[] b, Minecraft mc) {
        dx = 0f; dy = 0f; sc = 1f;
        if (!active() || HudModule.editing) return 1f;
        float t = h.motion;
        float e = t * t * (3f - 2f * t);                  // smoothstep
        float inv = 1f - e;
        if (inv <= 0.001f) return 1f;
        HudMotion m = instance;
        Style st = m.reduced.get() ? Style.FADE : m.style.get();
        float k = m.intensity.asFloat();
        float dist = 28f * k;
        boolean fromLeft = b[0] + b[2] / 2 < mc.getWindow().getGuiScaledWidth() / 2;
        switch (st) {
            case SLIDE -> { dx = (fromLeft ? -dist : dist) * inv; return 1f; }
            case FADE -> { return e; }
            case SCALE -> { sc = 1f - 0.45f * Math.min(1.5f, k) * inv; return e; }
            default -> { dx = (fromLeft ? -dist : dist) * inv * 0.6f; return e; }
        }
    }
}
