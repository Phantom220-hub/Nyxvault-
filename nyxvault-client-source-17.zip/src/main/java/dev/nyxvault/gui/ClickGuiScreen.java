package dev.nyxvault.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.setting.Setting;
import dev.nyxvault.util.Lang;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * NYXVAULT Click GUI.
 *
 * Scrolling model: every scrollable panel has a target offset (set by wheel / scrollbar) and a
 * shown offset that eases toward it. Drawing, clipping (scissor) and hit-testing all use the SAME
 * rounded shown offset and the SAME viewport rectangle, so clicks always match what is visible.
 * The module list (index 0) and the settings panel (index 1) scroll independently.
 */
public final class ClickGuiScreen extends Screen {
    private static final int SIDEBAR = 112;
    private static final int CARD_H = 46;
    private static final int ROW_H = 24;
    private static final int GAP = 3;
    private static final int BAR_W = 5;
    private static final int MODULES = 0, SETTINGS = 1;

    private Category category = Category.COMBAT;
    private Module selected;      // module whose settings are shown
    private Module bindTarget;    // module waiting for a key press
    private String search = "";
    private boolean searchFocused;

    // Scroll state per panel (0 = module list, 1 = settings).
    private final float[] target = new float[2];
    private final float[] shown = new float[2];
    // Scrollbar geometry from the last drawn frame (used for mouse input).
    private final int[] barX = new int[2], barY = new int[2], barH = new int[2];
    private final int[] thumbY = new int[2], thumbH = new int[2];
    private final float[] barMax = new float[2];
    private int dragBar = -1;
    private float dragGrab;

    // Active slider drag (independent of scrollbar drag).
    private NumberSetting dragSlider;
    private int sliderX, sliderW;

    private float open;           // 0..1 open/close animation
    private float tabAnim = 1f;
    private float setAnim;
    private boolean closing;
    private long lastNanos = System.nanoTime();

    // Virtual (GUI scale adjusted) layout, recomputed every frame.
    private float s = 1f;
    private int x0, y0, pw, ph;

    public ClickGuiScreen() { super(Component.literal("NYXVAULT")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() { closing = true; }

    @Override public void removed() {
        ConfigManager.save();
        super.removed();
    }

    // ------------------------------------------------------------------ layout

    private void layout() {
        s = Math.max(0.5f, UiSettings.guiScale);
        float vw = width / s, vh = height / s;
        pw = (int) Math.min(520, vw - 12);
        ph = (int) Math.min(320, vh - 12);
        x0 = (int) ((vw - pw) / 2);
        y0 = (int) ((vh - ph) / 2);
    }

    private int contentX() { return x0 + SIDEBAR + 8; }
    private int contentY() { return y0 + 34; }
    private int contentW() { return pw - SIDEBAR - 16; }
    private int contentH() { return ph - 42; }
    private int catH() { return Math.max(14, Math.min(22, (ph - 76) / Category.values().length)); }

    /** Module card list viewport. */
    private int listW() { return contentW() - BAR_W - 6; }
    private int colW() { return (listW() - 8) / 2; }
    /** Settings rows viewport (below the header line). */
    private int setTop() { return contentY() + 14; }
    private int setH() { return contentH() - 14; }
    private int rowW() { return contentW() - BAR_W - 6; }

    private List<Module> visibleModules() {
        return search.isEmpty() ? NyxvaultClient.modules().inCategory(category) : NyxvaultClient.modules().search(search);
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void smooth(int i, float max, float dt) {
        target[i] = clamp(target[i], 0, max);
        shown[i] = clamp(shown[i], 0, max);
        if (UiSettings.animationIntensity <= 0f) {
            shown[i] = target[i];
        } else {
            shown[i] = Draw.approach(shown[i], target[i], 18f * Math.max(0.25f, UiSettings.animationSpeed), dt);
            if (Math.abs(shown[i] - target[i]) < 0.25f) shown[i] = target[i];
        }
        barMax[i] = max;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float speed = 12f * Math.max(0.25f, UiSettings.animationIntensity) * Math.max(0.25f, UiSettings.animationSpeed);
        if (UiSettings.animationIntensity <= 0f) open = closing ? 0f : 1f;
        else open = Draw.approach(open, closing ? 0f : 1f, speed, dt);
        if (closing && open < 0.03f) { minecraft.setScreen(null); return; }
        tabAnim = Draw.approach(tabAnim, 1f, 14f, dt);
        setAnim = Draw.approach(setAnim, selected != null ? 1f : 0f, 16f, dt);

        layout();
        float mx = mouseX / s, my = mouseY / s;
        int accent = UiSettings.accent();
        float fade = open;

        g.fill(0, 0, width, height, Draw.alpha(0xFF000000, 0.45f * fade));
        g.pose().pushMatrix();
        g.pose().scale(s, s);
        g.pose().translate(0f, (1f - open) * 12f);

        if (UiSettings.glowEnabled()) {
            Draw.border(g, x0 - 2, y0 - 2, pw + 4, ph + 4, Draw.alpha(accent, 0.18f * fade));
            Draw.border(g, x0 - 1, y0 - 1, pw + 2, ph + 2, Draw.alpha(accent, 0.35f * fade));
        }
        Draw.round(g, x0, y0, pw, ph, Draw.alpha(UiSettings.theme.background, fade));
        Draw.border(g, x0, y0, pw, ph, Draw.alpha(accent, 0.9f * fade));
        Draw.round(g, x0, y0, SIDEBAR, ph, Draw.alpha(UiSettings.theme.panel, fade));

        drawSidebar(g, mx, my, fade);
        drawHeader(g, mx, my, fade);
        if (selected != null) drawSettings(g, mx, my, fade, dt); else drawCards(g, mx, my, fade, dt);
        drawNotifications(g, fade);

        g.pose().popMatrix();
    }

    private void drawSidebar(GuiGraphics g, float mx, float my, float fade) {
        int accent = UiSettings.accent();
        // Original logo: a violet "vault" diamond with a notch + wordmark.
        int lx = x0 + 12, ly = y0 + 10;
        for (int i = 0; i < 7; i++) {
            int half = i < 4 ? i : 6 - i;
            g.fill(lx + 7 - half, ly + i * 2, lx + 8 + half, ly + i * 2 + 2, Draw.alpha(accent, fade));
        }
        g.fill(lx + 6, ly + 5, lx + 9, ly + 9, Draw.alpha(UiSettings.theme.background, fade));
        g.drawString(font, "NYXVAULT", x0 + 32, y0 + 8, Draw.alpha(0xFFFFFFFF, fade), true);
        g.drawString(font, "CLIENT", x0 + 32, y0 + 18, Draw.alpha(UiSettings.secondary(), fade), true);

        Category[] cats = Category.values();
        int ch = catH();
        for (int i = 0; i < cats.length; i++) {
            int cy = y0 + 36 + i * ch;
            boolean sel = cats[i] == category && search.isEmpty();
            boolean hov = hit(mx, my, x0 + 6, cy, SIDEBAR - 12, ch - 2);
            if (sel) {
                Draw.round(g, x0 + 6, cy, SIDEBAR - 12, ch - 2, Draw.alpha(accent, 0.22f * fade));
                g.fill(x0 + 6, cy + 3, x0 + 8, cy + ch - 5, Draw.alpha(accent, fade));
            } else if (hov) {
                Draw.round(g, x0 + 6, cy, SIDEBAR - 12, ch - 2, Draw.alpha(0xFFFFFFFF, 0.06f * fade));
            }
            g.drawString(font, Lang.category(cats[i]), x0 + 16, cy + (ch - 10) / 2, Draw.alpha(sel ? 0xFFFFFFFF : 0xFF9CA3AF, fade), true);
        }
        String user = dev.nyxvault.module.misc.NickHider.map(minecraft.getUser().getName());
        Draw.round(g, x0 + 6, y0 + ph - 28, SIDEBAR - 12, 22, Draw.alpha(0xFF000000, 0.35f * fade));
        g.fill(x0 + 10, y0 + ph - 24, x0 + 24, y0 + ph - 10, Draw.alpha(accent, 0.8f * fade));
        g.drawString(font, trim(user, SIDEBAR - 42), x0 + 28, y0 + ph - 20, Draw.alpha(0xFFFFFFFF, fade), true);
    }

    private static final int WP_BTN_W = 74;

    private void drawHeader(GuiGraphics g, float mx, float my, float fade) {
        int sx = contentX(), sw = contentW() - WP_BTN_W - 6;
        Draw.round(g, sx, y0 + 8, sw, 18, Draw.alpha(0xFF000000, 0.4f * fade));
        Draw.border(g, sx, y0 + 8, sw, 18, Draw.alpha(searchFocused ? UiSettings.accent() : 0xFF374151, fade));
        boolean caret = searchFocused && (System.currentTimeMillis() / 500) % 2 == 0;
        String text = search.isEmpty() && !searchFocused ? Lang.t("Search modules...") : search + (caret ? "_" : "");
        g.drawString(font, text, sx + 6, y0 + 13, Draw.alpha(search.isEmpty() ? 0xFF6B7280 : 0xFFFFFFFF, fade), true);
        // Waypoints button
        int bx = contentX() + contentW() - WP_BTN_W;
        boolean hov = hit(mx, my, bx, y0 + 8, WP_BTN_W, 18);
        Draw.round(g, bx, y0 + 8, WP_BTN_W, 18, Draw.alpha(hov ? 0xFF1B1B3A : UiSettings.theme.panel, fade));
        Draw.border(g, bx, y0 + 8, WP_BTN_W, 18, Draw.alpha(UiSettings.accent(), fade));
        String label = Lang.t("Marks");
        g.drawString(font, label, bx + (WP_BTN_W - font.width(label)) / 2, y0 + 13, Draw.alpha(0xFFFFFFFF, fade), true);
    }

    private void drawCards(GuiGraphics g, float mx, float my, float fade, float dt) {
        List<Module> mods = visibleModules();
        int vx = contentX(), vy = contentY(), vh = contentH();
        int cw = colW();
        int rows = (mods.size() + 1) / 2;
        int content = rows * (CARD_H + GAP + 3);
        smooth(MODULES, Math.max(0, content - vh), dt);
        int off = Math.round(shown[MODULES]);
        int accent = UiSettings.accent();
        float f = fade * tabAnim;

        g.enableScissor(vx, vy, vx + listW(), vy + vh);
        if (mods.isEmpty()) {
            g.drawString(font, Lang.t("No modules found"), vx + 4, vy + 4, Draw.alpha(0xFF6B7280, fade), true);
        }
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int px = vx + (i % 2) * (cw + 8);
            int py = vy + (i / 2) * (CARD_H + GAP + 3) - off;
            if (py + CARD_H < vy || py > vy + vh) continue; // fully outside the viewport
            boolean hov = hit(mx, my, px, py, cw, CARD_H) && my >= vy && my < vy + vh && dragBar < 0;
            m.anim = Draw.approach(m.anim, m.enabled() ? 1f : 0f, 16f, dt);
            Draw.round(g, px, py, cw, CARD_H, Draw.alpha(hov ? 0xFF1B1B3A : UiSettings.theme.panel, f));
            Draw.border(g, px, py, cw, CARD_H, Draw.alpha(Draw.mix(0xFF2A2A4A, accent, m.anim), f));
            g.drawString(font, trim(Lang.module(m), cw - 50), px + 8, py + 7, Draw.alpha(0xFFFFFFFF, f), true);
            g.drawString(font, trim(Lang.desc(m), cw - 16), px + 8, py + 19, Draw.alpha(0xFF9CA3AF, f), true);
            String key = m.key() < 0 ? "[-]" : "[" + keyName(m.key()) + "]";
            g.drawString(font, key, px + 8, py + 33, Draw.alpha(0xFF6B7280, f), true);
            if (!m.settings().isEmpty()) {
                g.drawString(font, Lang.t("RMB: settings"), px + 8 + font.width(key) + 8, py + 33, Draw.alpha(0xFF4B5563, f), true);
            }
            int sx = px + cw - 32, sy = py + 8;
            Draw.round(g, sx, sy, 24, 12, Draw.alpha(Draw.mix(0xFF374151, accent, m.anim), f));
            int knob = sx + 2 + Math.round(m.anim * 12);
            g.fill(knob, sy + 2, knob + 8, sy + 10, Draw.alpha(0xFFFFFFFF, f));
        }
        g.disableScissor();
        drawBar(g, MODULES, vx + listW() + 6, vy, vh, content, vh, mx, my, fade);
    }

    private void drawSettings(GuiGraphics g, float mx, float my, float fade, float dt) {
        int cx = contentX(), cy = contentY(), cw = contentW();
        int accent = UiSettings.accent();
        float f = fade * setAnim;

        g.drawString(font, Lang.t("< Back"), cx, cy - 2, Draw.alpha(accent, fade), true);
        g.drawString(font, trim(Lang.module(selected), 120), cx + 50, cy - 2, Draw.alpha(0xFFFFFFFF, fade), true);
        String reset = "[" + Lang.t("Reset") + "]";
        g.drawString(font, reset, cx + cw - font.width(reset), cy - 2, Draw.alpha(0xFFEF4444, fade), true);
        String bind = bindTarget == selected ? (Lang.russian ? "[нажмите клавишу...]" : "[press a key...]") : "[" + Lang.t("Key") + ": " + (selected.key() < 0 ? (Lang.russian ? "нет" : "none") : keyName(selected.key())) + "]";
        g.drawString(font, bind, cx + cw - font.width(reset) - font.width(bind) - 10, cy - 2, Draw.alpha(0xFF9CA3AF, fade), true);

        List<Setting<?>> list = selected.settings();
        int top = setTop(), vh = setH(), rw = rowW();
        int content = list.size() * (ROW_H + GAP);
        smooth(SETTINGS, Math.max(0, content - vh), dt);
        int off = Math.round(shown[SETTINGS]);

        g.enableScissor(cx, top, cx + rw, top + vh);
        for (int i = 0; i < list.size(); i++) {
            Setting<?> st = list.get(i);
            int py = top + i * (ROW_H + GAP) - off;
            if (py + ROW_H < top || py > top + vh) continue;
            boolean hov = hit(mx, my, cx, py, rw, ROW_H) && my >= top && my < top + vh && dragBar < 0;
            Draw.round(g, cx, py, rw, ROW_H, Draw.alpha(hov ? 0xFF1B1B3A : UiSettings.theme.panel, f));
            g.drawString(font, trim(Lang.setting(st.name()), rw - 100), cx + 8, py + 5, Draw.alpha(0xFFFFFFFF, f), true);
            String v = Lang.value(st.name(), st.display());
            int vw = font.width(v);
            if (st instanceof ColorSetting c) {
                g.fill(cx + rw - vw - 28, py + 4, cx + rw - vw - 14, py + 14, c.get());
            }
            g.drawString(font, v, cx + rw - vw - 8, py + 5, Draw.alpha(accent, f), true);
            if (st instanceof NumberSetting n) { // slider track
                float ratio = (float) ((n.get() - n.min()) / Math.max(1e-9, n.max() - n.min()));
                int tx = cx + 8, tw = rw - 16;
                g.fill(tx, py + 17, tx + tw, py + 20, Draw.alpha(0xFF1F2937, f));
                g.fill(tx, py + 17, tx + Math.round(tw * clamp(ratio, 0, 1)), py + 20, Draw.alpha(accent, f));
            }
        }
        g.disableScissor();
        if (list.isEmpty()) g.drawString(font, Lang.t("This module has no settings."), cx + 4, top + 4, Draw.alpha(0xFF6B7280, fade), true);
        drawBar(g, SETTINGS, cx + rw + 6, top, vh, content, vh, mx, my, fade);
    }

    private void drawBar(GuiGraphics g, int i, int x, int y, int h, int content, int view, float mx, float my, float fade) {
        barX[i] = x; barY[i] = y; barH[i] = h;
        if (barMax[i] <= 0f) { thumbH[i] = 0; return; }
        int th = Math.max(20, Math.round(h * (view / (float) Math.max(content, 1))));
        th = Math.min(th, h);
        int ty = y + Math.round((h - th) * (shown[i] / barMax[i]));
        thumbH[i] = th; thumbY[i] = ty;
        boolean active = dragBar == i;
        boolean hover = hit(mx, my, x - 3, ty, BAR_W + 6, th);
        int accent = UiSettings.accent();
        Draw.round(g, x, y, BAR_W, h, Draw.alpha(0xFF000000, 0.35f * fade));
        int col = active ? accent : hover ? Draw.mix(accent, 0xFFFFFFFF, 0.35f) : Draw.alpha(accent, 0.6f);
        Draw.round(g, x, ty, BAR_W, th, Draw.alpha(col, fade));
    }

    private void drawNotifications(GuiGraphics g, float fade) {
        Notifications.prune();
        List<Notifications.Entry> list = Notifications.active();
        int y = y0 + ph - 20 - list.size() * 18;
        for (Notifications.Entry e : list) {
            long age = System.currentTimeMillis() - e.createdMs();
            float a = Math.min(1f, age / 200f) * Math.min(1f, (Notifications.lifetimeMs() - age) / 300f);
            a = Math.max(0f, a);
            int w = font.width(e.text()) + 14;
            int x = x0 + pw - w - 8;
            Draw.round(g, x, y, w, 15, Draw.alpha(UiSettings.theme.panel, a * fade));
            Draw.border(g, x, y, w, 15, Draw.alpha(UiSettings.accent(), a * fade));
            g.drawString(font, e.text(), x + 7, y + 4, Draw.alpha(0xFFFFFFFF, a * fade), true);
            y += 18;
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = (float) (event.x() / s), my = (float) (event.y() / s);
        int btn = event.button();

        // Search box
        if (hit(mx, my, contentX() + contentW() - WP_BTN_W, y0 + 8, WP_BTN_W, 18)) {
            click();
            minecraft.setScreen(new WaypointScreen(this));
            return true;
        }
        if (hit(mx, my, contentX(), y0 + 8, contentW() - WP_BTN_W - 6, 18)) {
            searchFocused = true;
            click();
            return true;
        }
        searchFocused = false;

        // Sidebar
        Category[] cats = Category.values();
        int ch = catH();
        for (int i = 0; i < cats.length; i++) {
            if (hit(mx, my, x0 + 6, y0 + 36 + i * ch, SIDEBAR - 12, ch - 2)) {
                category = cats[i];
                search = "";
                selected = null;
                bindTarget = null;
                target[MODULES] = 0; shown[MODULES] = 0;
                tabAnim = 0f;
                click();
                return true;
            }
        }

        // Scrollbar of the active panel (checked before content so it never activates a module).
        int b = selected != null ? SETTINGS : MODULES;
        if (btn == 0 && barMax[b] > 0f && thumbH[b] > 0
                && mx >= barX[b] - 3 && mx <= barX[b] + BAR_W + 3 && my >= barY[b] && my <= barY[b] + barH[b]) {
            if (my >= thumbY[b] && my <= thumbY[b] + thumbH[b]) {
                dragGrab = my - thumbY[b];
            } else {
                dragGrab = thumbH[b] / 2f; // click on the track: jump there and keep dragging
                dragTo(b, my);
            }
            dragBar = b;
            return true;
        }

        if (selected != null) return clickSettings(mx, my, btn);

        List<Module> mods = visibleModules();
        int vx = contentX(), vy = contentY(), vh = contentH(), cw = colW();
        int off = Math.round(shown[MODULES]);
        if (my < vy || my >= vy + vh) return super.mouseClicked(event, doubleClick);
        for (int i = 0; i < mods.size(); i++) {
            int px = vx + (i % 2) * (cw + 8);
            int py = vy + (i / 2) * (CARD_H + GAP + 3) - off;
            if (!hit(mx, my, px, py, cw, CARD_H)) continue;
            Module m = mods.get(i);
            if (btn == 0) { m.toggle(); ConfigManager.requestSave(); }
            else if (btn == 1) { selected = m; target[SETTINGS] = 0; shown[SETTINGS] = 0; setAnim = 0f; }
            else if (btn == 2) { bindTarget = m; }
            click();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    private boolean clickSettings(float mx, float my, int btn) {
        int cx = contentX(), cy = contentY(), cw = contentW();
        if (hit(mx, my, cx, cy - 4, 46, 12)) {
            selected = null; bindTarget = null; click(); return true;
        }
        if (hit(mx, my, cx + cw - 46, cy - 4, 46, 12)) {
            selected.resetSettings(); ConfigManager.requestSave(); click(); return true;
        }
        if (hit(mx, my, cx + 50, cy - 4, cw - 100, 12) && my < cy + 10) {
            bindTarget = selected; click(); return true;
        }
        List<Setting<?>> list = selected.settings();
        int top = setTop(), vh = setH(), rw = rowW();
        int off = Math.round(shown[SETTINGS]);
        if (my < top || my >= top + vh || mx < cx || mx >= cx + rw) return false;
        for (int i = 0; i < list.size(); i++) {
            int py = top + i * (ROW_H + GAP) - off;
            if (!hit(mx, my, cx, py, rw, ROW_H)) continue;
            Setting<?> st = list.get(i);
            if (st instanceof NumberSetting n) {
                if (btn == 1) { n.reset(); } else {
                    dragSlider = n; sliderX = cx + 8; sliderW = rw - 16;
                    applySlider(mx);
                }
            } else {
                st.interact(btn == 1 ? -1 : 1);
            }
            ConfigManager.requestSave();
            click();
            return true;
        }
        return false;
    }

    private void applySlider(float mx) {
        if (dragSlider == null) return;
        float ratio = clamp((mx - sliderX) / Math.max(1, sliderW), 0f, 1f);
        dragSlider.set(dragSlider.min() + ratio * (dragSlider.max() - dragSlider.min()));
    }

    private void dragTo(int b, float my) {
        float track = Math.max(1, barH[b] - thumbH[b]);
        float ratio = clamp((my - dragGrab - barY[b]) / track, 0f, 1f);
        target[b] = ratio * barMax[b];
        shown[b] = target[b];
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        float mx = (float) (event.x() / s), my = (float) (event.y() / s);
        if (dragBar >= 0) { dragTo(dragBar, my); return true; }
        if (dragSlider != null) { applySlider(mx); ConfigManager.requestSave(); return true; }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean was = dragBar >= 0 || dragSlider != null;
        dragBar = -1;
        dragSlider = null;
        if (was) { ConfigManager.requestSave(); return true; }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        int b = selected != null ? SETTINGS : MODULES;
        target[b] = clamp(target[b] - (float) scrollY * 28f, 0f, barMax[b]);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (bindTarget != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE) {
                bindTarget.setKey(-1);
            } else {
                Module other = NyxvaultClient.modules().keyConflict(bindTarget, key);
                if (other != null) Notifications.push(Lang.t("Key in use by ") + Lang.module(other));
                else bindTarget.setKey(key);
            }
            bindTarget = null;
            ConfigManager.requestSave();
            return true;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                target[MODULES] = 0; shown[MODULES] = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER) { searchFocused = false; return true; }
        }
        int b = selected != null ? SETTINGS : MODULES;
        if (key == GLFW.GLFW_KEY_DOWN) { target[b] = clamp(target[b] + 30f, 0f, barMax[b]); return true; }
        if (key == GLFW.GLFW_KEY_UP) { target[b] = clamp(target[b] - 30f, 0f, barMax[b]); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_DOWN) { target[b] = clamp(target[b] + 150f, 0f, barMax[b]); return true; }
        if (key == GLFW.GLFW_KEY_PAGE_UP) { target[b] = clamp(target[b] - 150f, 0f, barMax[b]); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!searchFocused) return false;
        int cp = event.codepoint();
        if (cp >= 32 && search.length() < 24) {
            search += new String(Character.toChars(cp));
            target[MODULES] = 0; shown[MODULES] = 0;
            selected = null;
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ helpers

    private static boolean hit(float mx, float my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private String trim(String text, int maxW) {
        if (font.width(text) <= maxW) return text;
        String t = text;
        while (t.length() > 1 && font.width(t + "..") > maxW) t = t.substring(0, t.length() - 1);
        return t + "..";
    }

    private static String keyName(int key) {
        return InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString().toUpperCase();
    }

    private void click() {
        if (UiSettings.guiSounds && minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, UiSettings.soundVolume));
        }
    }
}
