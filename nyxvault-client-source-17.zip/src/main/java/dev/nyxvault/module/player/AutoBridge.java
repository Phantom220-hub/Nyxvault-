package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Places a block under your feet with a normal "use item on block" action, so you can bridge or
 * jump-bridge without precise clicking. It only uses the block you already hold (main hand, else
 * offhand); it never switches slots, never changes velocity, jump height or gravity, and never
 * jumps for you (for a jump bridge you press jump yourself and it fills the block below you).
 * The block is attached to a real neighboring block face within normal reach. Servers may forbid
 * automatic placing; use it only where that is allowed.
 */
public final class AutoBridge extends Module {
    private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 2, 1, 10));
    private final BoolSetting onlyMoving = add(new BoolSetting("Only While Moving", true));
    private final BoolSetting pauseSneak = add(new BoolSetting("Pause While Sneaking", false));

    private int cooldown;

    public AutoBridge() {
        super("Auto Bridge", "Places the held block under your feet for bridging and jump-bridging. Check server rules.", Category.MOVEMENT);
    }

    @Override protected void onEnable() { cooldown = 0; }
    @Override protected void onDisable() { cooldown = 0; }
    @Override public void onWorldChange() { cooldown = 0; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        if (cooldown > 0) { cooldown--; return; }
        if (p.isUsingItem() || p.isPassenger() || p.isSwimming() || p.getAbilities().flying) return;
        if (pauseSneak.get() && p.isShiftKeyDown()) return;
        if (onlyMoving.get() && p.getDeltaMovement().horizontalDistanceSqr() < 1.0E-4 && p.onGround()) return;

        InteractionHand hand;
        if (p.getMainHandItem().getItem() instanceof BlockItem) hand = InteractionHand.MAIN_HAND;
        else if (p.getOffhandItem().getItem() instanceof BlockItem) hand = InteractionHand.OFF_HAND;
        else return;

        BlockPos target = BlockPos.containing(p.getX(), p.getY() - 0.5, p.getZ());
        if (!mc.level.getBlockState(target).canBeReplaced()) return;

        // Click a solid neighbor's face that points at the target. Below first, then the sides.
        Direction[] order = { Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST };
        for (Direction d : order) {
            BlockPos nb = target.relative(d);
            if (mc.level.getBlockState(nb).canBeReplaced()) continue; // air/water/grass cannot be clicked against
            Direction face = d.getOpposite();
            Vec3 hit = Vec3.atCenterOf(nb).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            mc.gameMode.useItemOn(p, hand, new BlockHitResult(hit, face, nb, false));
            p.swing(hand);
            cooldown = delay.asInt();
            return;
        }
    }
}
