package dev.nyxvault.visual;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;

/**
 * Per-effect ring/sphere appearance settings. Every effect module creates its OWN instance, so the
 * settings (and their saved values) are independent: changing Target Circle never changes Jump Circle.
 * Not every effect gets every slider; flags choose the ones that make sense for that effect.
 * The module's own "Reset" button in the GUI restores all of them.
 */
public final class RingFx {
    public static final int RADIUS_LIMITS = 1, HEIGHT = 2, INNER = 4, SPHERE = 8, VERTICAL = 16, HORIZONTAL = 32;

    private NumberSetting minRadius, maxRadius, height, hScale, vScale, inner, sphereOpacity;
    private final NumberSetting ringOpacity, glow, animIntensity, rgbSpeed, smooth;
    private final BoolSetting rgb;

    public RingFx(Module m, int flags) {
        if ((flags & RADIUS_LIMITS) != 0) {
            minRadius = m.addSetting(NumberSetting.decimal("Min Radius", 0.2, 0.1, 2.0, 0.1));
            maxRadius = m.addSetting(NumberSetting.decimal("Max Radius", 6.0, 1.0, 12.0, 0.5));
        }
        if ((flags & HEIGHT) != 0) height = m.addSetting(NumberSetting.decimal("Height Offset", 0.0, -1.0, 3.0, 0.1));
        if ((flags & HORIZONTAL) != 0) hScale = m.addSetting(NumberSetting.decimal("Horizontal Scale", 1.0, 0.5, 2.5, 0.1));
        if ((flags & VERTICAL) != 0) vScale = m.addSetting(NumberSetting.decimal("Vertical Scale", 1.0, 0.5, 2.5, 0.1));
        if ((flags & INNER) != 0) inner = m.addSetting(NumberSetting.integer("Inner Radius (%)", 70, 30, 95));
        ringOpacity = m.addSetting(NumberSetting.decimal("Ring Opacity", 1.0, 0.1, 1.0, 0.05));
        if ((flags & SPHERE) != 0) sphereOpacity = m.addSetting(NumberSetting.decimal("Sphere Opacity", 1.0, 0.1, 1.0, 0.05));
        rgb = m.addSetting(new BoolSetting("RGB Animation", false));
        rgbSpeed = m.addSetting(NumberSetting.decimal("RGB Speed", 1.0, 0.1, 5.0, 0.1));
        animIntensity = m.addSetting(NumberSetting.decimal("Animation Intensity", 1.0, 0.0, 2.0, 0.1));
        smooth = m.addSetting(NumberSetting.integer("Smoothness", 2, 1, 3));
        glow = m.addSetting(NumberSetting.decimal("Glow Intensity", 1.0, 0.0, 2.0, 0.1));
    }

    /** Ring radius after horizontal scale and min/max limits. */
    public float radius(float r) {
        float v = hScale == null ? r : r * hScale.asFloat();
        if (minRadius != null) v = Math.max(minRadius.asFloat(), Math.min(maxRadius.asFloat(), v));
        return v;
    }

    public float hScale() { return hScale == null ? 1f : hScale.asFloat(); }
    public float vScale() { return vScale == null ? 1f : vScale.asFloat(); }
    public double heightOffset() { return height == null ? 0.0 : height.get(); }
    public float innerRatio() { return inner == null ? 0.7f : inner.asInt() / 100f; }
    public float ringOpacity() { return ringOpacity.asFloat(); }
    public float sphereOpacity() { return sphereOpacity == null ? 1f : sphereOpacity.asFloat(); }
    public float anim() { return UiSettings.reducedEffects ? Math.min(0.5f, animIntensity.asFloat()) : animIntensity.asFloat(); }
    public float glow() { return glow.asFloat(); }
    public boolean glowOn() { return glow.asFloat() > 0.01f; }

    /** Segment count (16 / 32 / 64) from Smoothness, lowered by performance mode and the preset. */
    public int segments(boolean performanceMode) {
        if (performanceMode || UiSettings.reducedEffects || UiSettings.preset == UiSettings.Preset.LOW) return 16;
        return switch (smooth.asInt()) { case 1 -> 16; case 3 -> 64; default -> 32; };
    }

    private static int hsv(float h, float alphaSrcColor) {
        float r, g, b;
        float x = (h - (float) Math.floor(h)) * 6f;
        int i = (int) x;
        float f = x - i, q = 1f - f;
        switch (i) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }

    /** Applies the RGB animation to a color (keeps its alpha); returns it unchanged when RGB is off. */
    public int tint(int argb) { return tint(argb, 0f); }

    public int tint(int argb, float hueShift) {
        if (!rgb.get()) return argb;
        float h = (System.currentTimeMillis() % 100000L) / 10000f * rgbSpeed.asFloat() + hueShift;
        return (argb & 0xFF000000) | hsv(h, 0f);
    }

    public int withAlpha(int argb, float a) { return Draw.alpha(argb, a); }
}
