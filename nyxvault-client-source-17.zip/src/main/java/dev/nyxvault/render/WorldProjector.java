package dev.nyxvault.render;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/**
 * Projects world coordinates to GUI-scaled screen coordinates using the main camera.
 * Used for waypoint labels, TNT countdowns and motion trails (all drawn on the HUD layer, so they
 * are NOT depth-tested and can appear through blocks). All camera access is isolated here.
 */
public final class WorldProjector {
    /** Result of the last successful {@link #project}: x, y in GUI pixels. */
    public static final float[] out = new float[2];
    public static int sw, sh;
    private static double cx, cy, cz, fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect;

    private WorldProjector() { }

    /** False when the view is not first person; world overlays are skipped then (see below). */
    public static boolean valid;

    /**
     * Call once per frame before projecting. The view is derived from the local player's eyes, so
     * it is exact in first person only. In third person the real camera sits elsewhere, so
     * projection is disabled instead of drawing misplaced labels.
     */
    public static void update(Minecraft mc) {
        valid = false;
        if (mc.player == null || !mc.options.getCameraType().isFirstPerson()) return;
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        Vec3 p = mc.player.getEyePosition(pt);
        cx = p.x; cy = p.y; cz = p.z;
        double yaw = Math.toRadians(mc.player.getViewYRot(pt));
        double pitch = Math.toRadians(mc.player.getViewXRot(pt));
        double sy = Math.sin(yaw), cyw = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        fx = -sy * cp; fy = -sp; fz = cyw * cp;      // forward
        rx = -cyw; rz = -sy;                         // right (horizontal)
        ux = -sy * sp; uy = cp; uz = cyw * sp;       // up
        sw = mc.getWindow().getGuiScaledWidth();
        sh = mc.getWindow().getGuiScaledHeight();
        tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        aspect = sw / (double) Math.max(1, sh);
        valid = true;
    }

    /** @return true when the point is in front of the camera; result in {@link #out} (may be off-screen). */
    public static boolean project(double x, double y, double z) {
        if (!valid) return false;
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) return false;
        double xr = dx * rx + dz * rz;
        double yr = dx * ux + dy * uy + dz * uz;
        double nx = xr / (depth * tanHalf * aspect);
        double ny = yr / (depth * tanHalf);
        if (Math.abs(nx) > 25 || Math.abs(ny) > 25) return false;
        out[0] = (float) ((nx * 0.5 + 0.5) * sw);
        out[1] = (float) ((0.5 - ny * 0.5) * sh);
        return true;
    }

    public static boolean onScreen(float margin) {
        return out[0] >= -margin && out[1] >= -margin && out[0] <= sw + margin && out[1] <= sh + margin;
    }
}
