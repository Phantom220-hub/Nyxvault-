package dev.nyxvault.render;

import net.minecraft.client.gui.GuiGraphics;

/** Horizontal rings in world space, projected to the screen and drawn as a closed polyline. */
public final class Rings {
    private Rings() { }

    /** Vertex count for ring-like effects: 16 / 32 / 64 depending on preset and performance mode. */
    public static int quality(boolean performanceMode) {
        if (performanceMode || dev.nyxvault.config.UiSettings.reducedEffects) return 16;
        return switch (dev.nyxvault.config.UiSettings.preset) {
            case LOW -> 16;
            case BALANCED -> 32;
            case HIGH -> 64;
        };
    }

    /** Soft halo under a ring: two wider, faint strokes. {@code c} already carries the ring's alpha. */
    public static void glow(GuiGraphics g, double cx, double cy, double cz, float radius, float rot, float thick,
                            int c, int n) {
        glow(g, cx, cy, cz, radius, rot, thick, c, n, 1f);
    }

    /** {@code strength} scales the halo alpha (0 = none, 1 = default, 2 = strong). */
    public static void glow(GuiGraphics g, double cx, double cy, double cz, float radius, float rot, float thick,
                            int c, int n, float strength) {
        if (strength <= 0.01f) return;
        ring(g, cx, cy, cz, radius, rot, thick * 4.0f, Draw.alpha(c, Math.min(1f, 0.12f * strength)), 0, false, false, n, 0);
        ring(g, cx, cy, cz, radius, rot, thick * 2.2f, Draw.alpha(c, Math.min(1f, 0.22f * strength)), 0, false, false, n, 0);
    }

    /**
     * @param n       vertices (16, 32 or 64)
     * @param c1      stroke color (alpha already applied)
     * @param c2      second color used when {@code gradient} is true
     * @param dashed  draw only alternating 45 degree arcs
     * @param phase   gradient animation offset (0..63)
     */
    public static void ring(GuiGraphics g, double cx, double cy, double cz, float radius, float rot, float thick,
                            int c1, int c2, boolean gradient, boolean dashed, int n, int phase) {
        float cr = (float) Math.cos(rot), sr = (float) Math.sin(rot);
        int step = Lines.TABLE / n;
        boolean have = false;
        float px = 0, py = 0;
        for (int i = 0; i <= n; i++) {
            int k = (i * step) % Lines.TABLE;
            float c = Lines.COS[k] * cr - Lines.SIN[k] * sr;
            float s = Lines.SIN[k] * cr + Lines.COS[k] * sr;
            boolean ok = WorldProjector.project(cx + radius * c, cy, cz + radius * s);
            float x = WorldProjector.out[0], y = WorldProjector.out[1];
            if (ok && have) {
                boolean draw = !dashed || (((i - 1) * 8 / n) & 1) == 0;
                if (draw) {
                    int col = gradient ? Draw.mix(c1, c2, 0.5f + 0.5f * Lines.SIN[(k + phase) & 63]) : c1;
                    Lines.segment(g, px, py, x, y, thick, col);
                }
            }
            have = ok; px = x; py = y;
        }
    }
}
