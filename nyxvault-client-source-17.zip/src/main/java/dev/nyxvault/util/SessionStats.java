package dev.nyxvault.util;

import net.minecraft.client.Minecraft;

/** Real, locally recorded session statistics. Updated once per client tick. */
public final class SessionStats {
    private static long start = System.currentTimeMillis();
    public static double distance;
    public static int swings, hits, pops, maxCombo;
    private static double lastX, lastZ, speed;
    private static boolean has;
    private static String lastDim = "";

    private SessionStats() { }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) { has = false; speed = 0; return; }
        String dim = mc.level.dimension().toString();
        double x = mc.player.getX(), z = mc.player.getZ();
        if (has && dim.equals(lastDim)) {
            double d = Math.sqrt((x - lastX) * (x - lastX) + (z - lastZ) * (z - lastZ));
            if (d < 20) { // ignore teleports
                distance += d;
                speed = speed * 0.8 + (d * 20.0) * 0.2;
            }
        }
        lastX = x; lastZ = z; lastDim = dim; has = true;
    }

    public static long elapsedSeconds() { return (System.currentTimeMillis() - start) / 1000; }
    /** Horizontal speed in blocks per second (smoothed, measured). */
    public static double speed() { return speed; }

    public static void reset() {
        start = System.currentTimeMillis();
        distance = 0; swings = 0; hits = 0; pops = 0; maxCombo = 0;
    }

    /** Short dimension name such as "overworld". */
    public static String dimName(Minecraft mc) {
        if (mc.level == null) return "-";
        String d = mc.level.dimension().toString();
        int i = d.lastIndexOf(" / ");
        if (i >= 0) d = d.substring(i + 3);
        return d.replace("]", "").replace("minecraft:", "");
    }
}
