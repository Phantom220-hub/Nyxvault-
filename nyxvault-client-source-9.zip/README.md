# NYXVAULT CLIENT 1.0.0

Client-side Fabric mod for **Minecraft Java Edition 1.21.11** (Java 21): Click GUI, draggable HUD, PvP feedback, visual trails, waypoints.

> **Honest status.** Version 1.0 compiled on GitHub Actions and launched. Everything added since then
> (scrolling fix, trails, Auto Totem, and the third update: Target Circle, Target Effects, Hit Effects, Jump Circle,
> Weapon Trail, Target HUD, Russian localization, "Метки мира" screen) was written without a local compiler and has
> **not** been compiled, launched in Minecraft, or tested on any server. Verify the first GitHub Actions run and report errors.

## Build the JAR (GitHub Actions)
1. Push the project (or upload `nyxvault-client-source-*.zip` and let the workflow unpack it).
2. **Actions** tab → latest run → when green, download **nyxvault-client-jar** under *Artifacts*.
3. Red run: open the **Build** step and read the lines containing `error:`.

Local build: JDK 21 + Gradle 9.2+, `gradle build` → `build/libs/nyxvault-client-1.0.0.jar`.

## Install
Fabric Loader ≥ 0.18, **Fabric API 0.141.3+1.21.11**, Minecraft 1.21.11. Put the JAR in `mods`.

## Controls
- **Right Shift**: Click GUI (rebind in Controls → NYXVAULT). LMB toggle · RMB settings · MMB set key.
- Click GUI scrolling: mouse wheel, draggable scrollbar, Up/Down/PageUp/PageDown. Sliders: click or drag a number row; RMB resets it.
- HUD Editor / Panic key: unbound by default, bind in Controls. HUD editor: drag (snaps to edges/centers/other elements), wheel = scale, RMB = on/off, R = reset.
- Commands: `/nyx wp add|addat|list|select|remove|toggle|group|export|import`, `/nyx coords` (copies coordinates).
- Config: `config/nyxvault/config.json` (corrupted files are moved aside, old configs still load).

## Added in this update
**Click GUI:** viewport clipping (scissor), visible scrollbars for module list and settings (independent), smooth wheel scrolling, drag scrollbar, search results scroll too, slider dragging that cannot grab the scrollbar, compact sidebar on small screens.
**Visuals:** Motion Trail (LINE / DOUBLE / RIBBON / GRADIENT / MINIMAL; color, gradient, length, width, opacity, fade, first/third person, performance mode), Combat Trail (separate, only for 3 s after you attack), Damage Flash, Performance Preset (LOW/BALANCED/HIGH, affects only this mod's visuals), Animation Speed, Notification Duration.
**Combat:** Auto Totem (simple), Totem HUD, Totem Pop Counter, Combat HUD (cooldown, confirmed hits, combo, CPS), dynamic crosshair (target color, cooldown/sprint gap), notifications merged and prioritized.
**Alerts:** Resource Alerts (low totems, armor durability, golden apples, ender pearls; one warning per crossing), Low Health Alert.
**World:** Waypoint Markers (diamond + name + distance, same dimension), TNT Countdown, Death Waypoint, Module List with smooth enter/exit and alignment.
**Extra HUD:** Player Info, Session Stats (reset toggle), Compass, Clock (real + in-game), Target Block, Light Level, Nearby Players, Item Counter.

## Ten additional features (beyond the request list)
Compass, Clock (real + MC time), Target Block, Light Level, Nearby Players, Item Counter, Death Waypoint, Low Health Alert, HUD-editor snapping guides, `/nyx coords`.
None changes physics, movement, knockback, particles or combat mechanics.

## Limitations (please read)
- **Trails, waypoint markers and TNT labels are drawn on the HUD layer from projected world positions and only work in first person (third person is skipped).** They are not depth-tested, so they can show through blocks. Projection uses the vanilla FOV option and ignores temporary FOV effects (sprint/speed), so labels can be off by a few pixels while sprinting.
- **Auto Totem** uses a normal inventory swap click. It swaps out whatever is in the offhand. Servers/anti-cheats may forbid or flag it. Not tested anywhere.
- **Totem pop counter** only detects your own pops by heuristic (totem vanished while hurt, no screen open); it cannot see other players' pops.
- **TNT countdown** shows the client's fuse value; it can differ slightly from the server during lag.
- **Hit direction indicator: not implemented.** The client does not reliably expose the direction of incoming damage, and I will not fake it.
- **Not implemented:** vertical waypoint beams, off-screen waypoint arrows, configuration profiles UI, waypoint management GUI (commands only), HolyWorld-specific features (no verified public API).
- Falling Blocks Optimizer and Explosion Effects Reducer were deliberately not added; no particle or physics code exists in this mod.

## Rules notice
AutoClicker and Auto Totem are automation and may violate server rules, including HolyWorld's. Nothing here is claimed to be permitted on any server. No anti-cheat bypasses are included.

## Third update (Russian localization, target visuals, waypoint screen)
- **Russian UI:** all module names/descriptions/settings/values, categories, HUD labels, notifications, commands, keybinds (`ru_ru.json`). Central map in `util/Lang.java`; config keys stay English. Search works in Russian and English.
- **New modules:** Target Circle, Target Effects, Hit Effects, Jump Circle, Weapon Trail (replaces Combat Trail); Motion Trail rebuilt (smooth segments instead of squares).
- **Target HUD:** compact/expanded layout, smooth health bar, hides when the target is gone.
- **Метки мира:** button in the Click GUI, `/nyx wp gui`, or an unbound key. Edit name, X/Y/Z, color; "Моя позиция"; delete confirmation; per-waypoint auto-remove (off by default; also needs the global toggle).
- **Auto Totem:** one swap click, waits while any screen/container is open, 5 s pause after 3 failed attempts.
- Target Circle/Effects need line of sight and first person (HUD-layer projection, no depth test).
- **Reference-style visuals (v6):** Motion Trail style DOTS (glowing dots, default cyan), Weapon Trail style FILLED (translucent pink swing sheet), soft Glow on Jump Circle / Target Circle rings, 14 color presets (click a color row to cycle; any `#RRGGBB` can also be set in `config.json`).
