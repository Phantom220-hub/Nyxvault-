package dev.nyxvault.hud;

import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Draggable HUD element with position, scale and opacity settings. */
public abstract class HudModule extends OverlayModule {
    /** True while the HUD editor is open, so empty elements can draw a placeholder. */
    public static boolean editing;

    public final NumberSetting x;
    public final NumberSetting y;
    public final NumberSetting scale = add(NumberSetting.decimal("Scale", 1.0, 0.5, 3.0, 0.1));
    public final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 1.0, 0.1, 1.0, 0.05));

    protected HudModule(String name, String description, Category category, int defX, int defY) {
        super(name, description, category);
        this.x = add(NumberSetting.integer("X", defX, 0, 10000));
        this.y = add(NumberSetting.integer("Y", defY, 0, 10000));
    }

    /** Content size in unscaled pixels. */
    public abstract int width(Minecraft mc);
    public abstract int height(Minecraft mc);
    /** Draw content with its top-left corner at (0,0). */
    protected abstract void draw(GuiGraphics g, Minecraft mc);

    protected final int a(int argb) { return Draw.alpha(argb, opacity.asFloat()); }

    /** Screen-space bounds after scale and clamping to the visible area. */
    public int[] bounds(Minecraft mc) {
        float s = scale.asFloat();
        int w = Math.max(1, Math.round(width(mc) * s));
        int h = Math.max(1, Math.round(height(mc) * s));
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int px = Math.max(0, Math.min(Math.max(0, sw - w), x.asInt()));
        int py = Math.max(0, Math.min(Math.max(0, sh - h), y.asInt()));
        return new int[]{px, py, w, h};
    }

    public void moveTo(Minecraft mc, int nx, int ny) {
        float s = scale.asFloat();
        int w = Math.round(width(mc) * s), h = Math.round(height(mc) * s);
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        x.set((double) Math.max(0, Math.min(Math.max(0, sw - w), nx)));
        y.set((double) Math.max(0, Math.min(Math.max(0, sh - h), ny)));
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (mc.player == null) return;
        int[] b = bounds(mc);
        float s = scale.asFloat();
        g.pose().pushMatrix();
        g.pose().translate((float) b[0], (float) b[1]);
        g.pose().scale(s, s);
        try {
            draw(g, mc);
        } finally {
            g.pose().popMatrix();
        }
    }
}
