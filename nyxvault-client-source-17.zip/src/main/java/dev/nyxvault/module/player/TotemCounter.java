package dev.nyxvault.module.player;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Counts totems in YOUR OWN inventory (hotbar, main inventory and offhand). Other players are never inspected. */
public final class TotemCounter extends HudModule {
    private final BoolSetting compact = add(new BoolSetting("Compact Layout", false));
    private final BoolSetting breakdown = add(new BoolSetting("Show Breakdown", true));
    private final BoolSetting smooth = add(new BoolSetting("Smooth Counter", true));
    private final NumberSetting threshold = add(NumberSetting.integer("Warning Threshold", 2, 0, 36));
    private final BoolSetting warnSound = add(new BoolSetting("Warning Sound", false));

    private final ItemStack icon = new ItemStack(Items.TOTEM_OF_UNDYING);
    private int total, hotbar, offhand;
    private float shown = -1f;
    private long lastNs;
    private boolean warned;

    public TotemCounter() {
        super("Totem Counter", "Counts totems in your own inventory with a low-stock warning.", Category.PLAYER, 130, 60);
    }

    @Override protected void onEnable() { shown = -1f; warned = false; }
    @Override public void onWorldChange() { shown = -1f; warned = false; }

    private void recount(Minecraft mc) {
        Player p = mc.player;
        if (p == null) { total = hotbar = offhand = 0; return; }
        Inventory inv = p.getInventory();
        int t = 0, hb = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() == Items.TOTEM_OF_UNDYING) { t += s.getCount(); if (i < 9) hb += s.getCount(); }
        }
        ItemStack off = p.getOffhandItem();
        offhand = off.getItem() == Items.TOTEM_OF_UNDYING ? off.getCount() : 0;
        total = t + offhand;
        hotbar = hb;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        recount(mc);
        boolean low = total <= threshold.asInt();
        if (low && !warned) {
            warned = true;
            Notifications.push("Мало тотемов: " + total, 1);
            if (warnSound.get() && mc.player != null) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.6f));
        } else if (!low) warned = false;
    }

    @Override public int width(Minecraft mc) { return compact.get() ? 40 : (breakdown.get() ? 110 : 64); }
    @Override public int height(Minecraft mc) { return compact.get() ? 18 : 22; }

    @Override protected void draw(GuiGraphics g, Minecraft mc) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.25f, (now - lastNs) / 1e9f);
        lastNs = now;
        if (shown < 0f || !smooth.get() || UiSettings.animationIntensity <= 0f) shown = total;
        else shown = Draw.approach(shown, total, 14f, dt);
        boolean low = total <= threshold.asInt();
        int col = low ? 0xFFEF4444 : 0xFFFFFFFF;
        int w = width(mc), h = height(mc);
        Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
        Draw.border(g, 0, 0, w, h, a(low ? 0xFFEF4444 : UiSettings.accent()));
        g.renderItem(icon, 2, (h - 16) / 2);
        g.drawString(mc.font, "x" + Math.round(shown), 22, (h - 8) / 2, a(col), true);
        if (!compact.get() && breakdown.get()) {
            g.drawString(mc.font, "пояс " + hotbar + "  рука " + offhand, 46, (h - 8) / 2, a(0xFF9CA3AF), true);
        }
    }
}
