package dev.nyxvault.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.Setting;
import dev.nyxvault.waypoint.Waypoint;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * JSON persistence. Loading is tolerant: unknown/invalid entries are skipped and a corrupted
 * file is moved aside (never silently deleted). Saving is debounced and atomic.
 */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int VERSION = 1;
    private static volatile boolean dirty;
    private static long lastSaveMs;

    private ConfigManager() { }

    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("nyxvault"); }
    public static Path file() { return dir().resolve("config.json"); }

    public static void requestSave() { dirty = true; }

    /** Called from the client tick: writes at most once every 2 seconds when something changed. */
    public static void tickSave() {
        if (dirty && System.currentTimeMillis() - lastSaveMs > 2000) save();
    }

    public static synchronized void save() {
        dirty = false;
        lastSaveMs = System.currentTimeMillis();
        try {
            Files.createDirectories(dir());
            JsonObject root = new JsonObject();
            root.addProperty("version", VERSION);

            JsonObject mods = new JsonObject();
            for (Module m : NyxvaultClient.modules().all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled());
                o.addProperty("key", m.key());
                JsonObject s = new JsonObject();
                for (Setting<?> st : m.settings()) s.add(st.name(), st.toJson());
                o.add("settings", s);
                mods.add(m.name(), o);
            }
            root.add("modules", mods);

            JsonArray wps = new JsonArray();
            for (Waypoint w : NyxvaultClient.waypoints().all()) wps.add(GSON.toJsonTree(w));
            root.add("waypoints", wps);
            String active = NyxvaultClient.waypoints().activeId();
            if (active != null) root.addProperty("activeWaypoint", active);

            Path tmp = dir().resolve("config.json.tmp");
            Files.writeString(tmp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, file(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, file(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Throwable t) {
            NyxvaultClient.LOGGER.error("Failed to save config", t);
        }
    }

    public static synchronized void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        JsonObject root;
        try {
            JsonElement e = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), JsonElement.class);
            if (e == null || !e.isJsonObject()) throw new IllegalStateException("root is not an object");
            root = e.getAsJsonObject();
        } catch (Throwable t) {
            NyxvaultClient.LOGGER.error("Config is corrupted; moving it aside and using defaults", t);
            try {
                Files.move(f, dir().resolve("config.corrupt-" + System.currentTimeMillis() + ".json"));
            } catch (IOException ignored) { }
            return;
        }

        try {
            if (root.has("modules") && root.get("modules").isJsonObject()) {
                JsonObject mods = root.getAsJsonObject("modules");
                for (Module m : NyxvaultClient.modules().all()) {
                    JsonElement me = mods.get(m.name());
                    if (me == null || !me.isJsonObject()) continue;
                    JsonObject o = me.getAsJsonObject();
                    if (o.has("key") && o.get("key").isJsonPrimitive() && o.get("key").getAsJsonPrimitive().isNumber()) {
                        m.setKey(o.get("key").getAsInt());
                    }
                    if (o.has("settings") && o.get("settings").isJsonObject()) {
                        JsonObject s = o.getAsJsonObject("settings");
                        for (Setting<?> st : m.settings()) if (s.has(st.name())) st.fromJson(s.get(st.name()));
                    }
                    if (o.has("enabled") && o.get("enabled").isJsonPrimitive()) m.restoreEnabled(o.get("enabled").getAsBoolean());
                }
            }
            List<Waypoint> list = new ArrayList<>();
            if (root.has("waypoints") && root.get("waypoints").isJsonArray()) {
                for (JsonElement we : root.getAsJsonArray("waypoints")) {
                    try {
                        Waypoint w = GSON.fromJson(we, Waypoint.class);
                        if (w != null && w.valid()) list.add(w);
                        else NyxvaultClient.LOGGER.warn("Skipped invalid waypoint entry");
                    } catch (Throwable t) {
                        NyxvaultClient.LOGGER.warn("Skipped unreadable waypoint entry", t);
                    }
                }
            }
            String active = root.has("activeWaypoint") ? root.get("activeWaypoint").getAsString() : null;
            NyxvaultClient.waypoints().replaceAll(list, active);
        } catch (Throwable t) {
            NyxvaultClient.LOGGER.error("Error while applying config; remaining defaults kept", t);
        }
    }
}
