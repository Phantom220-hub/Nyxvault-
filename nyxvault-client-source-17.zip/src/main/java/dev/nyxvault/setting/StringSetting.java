package dev.nyxvault.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.gui.TextInputScreen;
import net.minecraft.client.Minecraft;

/** Free text setting. Clicking it in the GUI opens a small input window. */
public final class StringSetting extends Setting<String> {
    private final int maxLength;
    private final String prompt;

    public StringSetting(String name, String def, int maxLength, String prompt) {
        super(name, def);
        this.maxLength = maxLength;
        this.prompt = prompt;
    }

    @Override public void set(String v) {
        String s = v == null ? "" : v.trim();
        value = s.length() > maxLength ? s.substring(0, maxLength) : s;
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) set(e.getAsString());
    }

    @Override public String display() { return value.isEmpty() ? "-" : value; }

    @Override public void interact(int direction) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new TextInputScreen(prompt, value, maxLength, mc.screen, v -> { set(v); ConfigManager.requestSave(); }));
    }
}
