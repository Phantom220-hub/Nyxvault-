package dev.nyxvault.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.Setting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** NYXVAULT Click GUI: sidebar, search, module cards and per-module settings. */
public final class ClickGuiScreen extends Screen {
    private static final int SIDEBAR = 112;
    private static final int CARD_H = 46;

    private Category category = Category.COMBAT;
    private Module selected;      // module whose settings are shown
    private Module bindTarget;    // module waiting for a key press
    private String search = "";
    private boolean searchFocused;
    private float scroll;
    private float open;           // 0..1 open/close animation
    private boolean closing;
    private long lastNanos = System.nanoTime();
    private float tabAnim = 1f;

    // Virtual (GUI scale adjusted) layout, recomputed every frame.
    private float s = 1f;
    private int x0, y0, pw, ph;

    public ClickGuiScreen() { super(Component.literal("NYXVAULT")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() { closing = true; }

    @Override public void removed() {
        ConfigManager.save();
        super.removed();
    }

    // ---------------------------------------------------------------- layout / render

    private void layout() {
        s = Math.max(0.5f, UiSettings.guiScale);
        float vw = width / s, vh = height / s;
        pw = (int) Math.min(520, vw - 12);
        ph = (int) Math.min(320, vh - 12);
        x0 = (int) ((vw - pw) / 2);
        y0 = (int) ((vh - ph) / 2);
    }

    private int contentX() { return x0 + SIDEBAR + 8; }
    private int contentY() { return y0 + 34; }
    private int contentW() { return pw - SIDEBAR - 16; }
    private int contentH() { return ph - 42; }

    private List<Module> visibleModules() {
        return search.isEmpty() ? NyxvaultClient.modules().inCategory(category) : NyxvaultClient.modules().search(search);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float speed = 12f * Math.max(0.25f, UiSettings.animationIntensity);
        if (UiSettings.animationIntensity <= 0f) open = closing ? 0f : 1f;
        else open = Draw.approach(open, closing ? 0f : 1f, speed, dt);
        if (closing && open < 0.03f) { minecraft.setScreen(null); return; }
        tabAnim = Draw.approach(tabAnim, 1f, 14f, dt);

        layout();
        float mx = mouseX / s, my = mouseY / s;
        int accent = UiSettings.accent();
        float fade = open;

        g.fill(0, 0, width, height, Draw.alpha(0xFF000000, 0.45f * fade));
        g.pose().pushMatrix();
        g.pose().scale(s, s);
        g.pose().translate(0f, (1f - open) * 12f);

        if (UiSettings.glow && !UiSettings.reducedEffects) {
            Draw.border(g, x0 - 2, y0 - 2, pw + 4, ph + 4, Draw.alpha(accent, 0.18f * fade));
            Draw.border(g, x0 - 1, y0 - 1, pw + 2, ph + 2, Draw.alpha(accent, 0.35f * fade));
        }
        Draw.round(g, x0, y0, pw, ph, Draw.alpha(UiSettings.theme.background, fade));
        Draw.border(g, x0, y0, pw, ph, Draw.alpha(accent, 0.9f * fade));
        Draw.round(g, x0, y0, SIDEBAR, ph, Draw.alpha(UiSettings.theme.panel, fade));

        drawSidebar(g, mx, my, fade);
        drawHeader(g, mx, my, fade);
        if (selected != null) drawSettings(g, mx, my, fade); else drawCards(g, mx, my, fade);
        drawNotifications(g, fade);

        g.pose().popMatrix();
    }

    private void drawSidebar(GuiGraphics g, float mx, float my, float fade) {
        int accent = UiSettings.accent();
        // Original logo: a violet "vault" diamond with a crescent notch + wordmark.
        int lx = x0 + 12, ly = y0 + 10;
        for (int i = 0; i < 7; i++) {
            int half = i < 4 ? i : 6 - i;
            g.fill(lx + 7 - half, ly + i * 2, lx + 8 + half, ly + i * 2 + 2, Draw.alpha(accent, fade));
        }
        g.fill(lx + 6, ly + 5, lx + 9, ly + 9, Draw.alpha(UiSettings.theme.background, fade));
        g.drawString(font, "NYXVAULT", x0 + 32, y0 + 8, Draw.alpha(0xFFFFFFFF, fade), true);
        g.drawString(font, "CLIENT", x0 + 32, y0 + 18, Draw.alpha(UiSettings.secondary(), fade), true);

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int cy = y0 + 40 + i * 22;
            boolean sel = cats[i] == category && search.isEmpty();
            boolean hov = hit(mx, my, x0 + 6, cy, SIDEBAR - 12, 20);
            if (sel) {
                Draw.round(g, x0 + 6, cy, SIDEBAR - 12, 20, Draw.alpha(accent, 0.22f * fade));
                g.fill(x0 + 6, cy + 3, x0 + 8, cy + 17, Draw.alpha(accent, fade));
            } else if (hov) {
                Draw.round(g, x0 + 6, cy, SIDEBAR - 12, 20, Draw.alpha(0xFFFFFFFF, 0.06f * fade));
            }
            g.drawString(font, cats[i].title, x0 + 16, cy + 6, Draw.alpha(sel ? 0xFFFFFFFF : 0xFF9CA3AF, fade), true);
        }
        // Profile area
        String user = minecraft.getUser().getName();
        Draw.round(g, x0 + 6, y0 + ph - 28, SIDEBAR - 12, 22, Draw.alpha(0xFF000000, 0.35f * fade));
        g.fill(x0 + 10, y0 + ph - 24, x0 + 24, y0 + ph - 10, Draw.alpha(accent, 0.8f * fade));
        g.drawString(font, user, x0 + 28, y0 + ph - 20, Draw.alpha(0xFFFFFFFF, fade), true);
    }

    private void drawHeader(GuiGraphics g, float mx, float my, float fade) {
        int sx = contentX(), sw = contentW();
        Draw.round(g, sx, y0 + 8, sw, 18, Draw.alpha(0xFF000000, 0.4f * fade));
        Draw.border(g, sx, y0 + 8, sw, 18, Draw.alpha(searchFocused ? UiSettings.accent() : 0xFF374151, fade));
        String text = search.isEmpty() && !searchFocused ? "Search modules..." : search + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.drawString(font, text, sx + 6, y0 + 13, Draw.alpha(search.isEmpty() ? 0xFF6B7280 : 0xFFFFFFFF, fade), true);
    }

    private void drawCards(GuiGraphics g, float mx, float my, float fade) {
        List<Module> mods = visibleModules();
        int cx = contentX(), cy = contentY(), cw = contentW(), ch = contentH();
        int colW = (cw - 8) / 2;
        int rows = (mods.size() + 1) / 2;
        float maxScroll = Math.max(0, rows * (CARD_H + 6) - ch);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        if (mods.isEmpty()) {
            g.drawString(font, "No modules found", cx + 4, cy + 4, Draw.alpha(0xFF6B7280, fade), true);
            return;
        }
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int px = cx + (i % 2) * (colW + 8);
            int py = cy + (i / 2) * (CARD_H + 6) - (int) scroll;
            if (py + CARD_H < cy || py > cy + ch) continue;
            boolean hov = hit(mx, my, px, py, colW, CARD_H) && my >= cy && my <= cy + ch;
            m.anim = Draw.approach(m.anim, m.enabled() ? 1f : 0f, 16f, 0.016f);
            int accent = UiSettings.accent();
            float f = fade * tabAnim;
            Draw.round(g, px, py, colW, CARD_H, Draw.alpha(hov ? 0xFF1B1B3A : UiSettings.theme.panel, f));
            Draw.border(g, px, py, colW, CARD_H, Draw.alpha(Draw.mix(0xFF2A2A4A, accent, m.anim), f));
            g.drawString(font, m.name(), px + 8, py + 7, Draw.alpha(0xFFFFFFFF, f), true);
            String desc = trim(m.description(), colW - 16);
            g.drawString(font, desc, px + 8, py + 19, Draw.alpha(0xFF9CA3AF, f), true);
            String key = m.key() < 0 ? "[-]" : "[" + keyName(m.key()) + "]";
            g.drawString(font, key, px + 8, py + 33, Draw.alpha(0xFF6B7280, f), true);
            if (!m.settings().isEmpty()) {
                g.drawString(font, "RMB: settings", px + 8 + font.width(key) + 8, py + 33, Draw.alpha(0xFF4B5563, f), true);
            }
            // switch
            int sx = px + colW - 32, sy = py + 8;
            Draw.round(g, sx, sy, 24, 12, Draw.alpha(Draw.mix(0xFF374151, accent, m.anim), f));
            int knob = sx + 2 + Math.round(m.anim * 12);
            g.fill(knob, sy + 2, knob + 8, sy + 10, Draw.alpha(0xFFFFFFFF, f));
        }
    }

    private void drawSettings(GuiGraphics g, float mx, float my, float fade) {
        int cx = contentX(), cy = contentY(), cw = contentW(), ch = contentH();
        int accent = UiSettings.accent();
        g.drawString(font, "< Back", cx, cy - 2, Draw.alpha(accent, fade), true);
        g.drawString(font, selected.name(), cx + 50, cy - 2, Draw.alpha(0xFFFFFFFF, fade), true);
        String reset = "[Reset]";
        g.drawString(font, reset, cx + cw - font.width(reset), cy - 2, Draw.alpha(0xFFEF4444, fade), true);
        String bind = bindTarget == selected ? "[press a key...]" : "[Key: " + (selected.key() < 0 ? "none" : keyName(selected.key())) + "]";
        g.drawString(font, bind, cx + cw - font.width(reset) - font.width(bind) - 10, cy - 2, Draw.alpha(0xFF9CA3AF, fade), true);

        List<Setting<?>> list = selected.settings();
        int top = cy + 14, rowH = 22;
        float maxScroll = Math.max(0, list.size() * (rowH + 3) - (ch - 14));
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        for (int i = 0; i < list.size(); i++) {
            Setting<?> st = list.get(i);
            int py = top + i * (rowH + 3) - (int) scroll;
            if (py + rowH < top || py > cy + ch) continue;
            boolean hov = hit(mx, my, cx, py, cw, rowH);
            Draw.round(g, cx, py, cw, rowH, Draw.alpha(hov ? 0xFF1B1B3A : UiSettings.theme.panel, fade));
            g.drawString(font, st.name(), cx + 8, py + 7, Draw.alpha(0xFFFFFFFF, fade), true);
            String v = st.display();
            int vw = font.width(v);
            if (st instanceof dev.nyxvault.setting.ColorSetting c) {
                g.fill(cx + cw - vw - 28, py + 5, cx + cw - vw - 14, py + 17, c.get());
            }
            g.drawString(font, v, cx + cw - vw - 8, py + 7, Draw.alpha(accent, fade), true);
        }
        if (list.isEmpty()) g.drawString(font, "This module has no settings.", cx + 4, top + 4, Draw.alpha(0xFF6B7280, fade), true);
    }

    private void drawNotifications(GuiGraphics g, float fade) {
        Notifications.prune();
        List<Notifications.Entry> list = Notifications.active();
        int y = y0 + ph - 20 - list.size() * 18;
        for (Notifications.Entry e : list) {
            long age = System.currentTimeMillis() - e.createdMs();
            float a = Math.min(1f, age / 200f) * Math.min(1f, (Notifications.lifetimeMs() - age) / 300f);
            int w = font.width(e.text()) + 14;
            int x = x0 + pw - w - 8;
            Draw.round(g, x, y, w, 15, Draw.alpha(UiSettings.theme.panel, a * fade));
            Draw.border(g, x, y, w, 15, Draw.alpha(UiSettings.accent(), a * fade));
            g.drawString(font, e.text(), x + 7, y + 4, Draw.alpha(0xFFFFFFFF, a * fade), true);
            y += 18;
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = (float) (event.x() / s), my = (float) (event.y() / s);
        int btn = event.button();

        // Search box
        if (hit(mx, my, contentX(), y0 + 8, contentW(), 18)) {
            searchFocused = true;
            click();
            return true;
        }
        searchFocused = false;

        // Sidebar
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (hit(mx, my, x0 + 6, y0 + 40 + i * 22, SIDEBAR - 12, 20)) {
                category = cats[i];
                search = "";
                selected = null;
                bindTarget = null;
                scroll = 0;
                tabAnim = 0f;
                click();
                return true;
            }
        }

        int cx = contentX(), cy = contentY(), cw = contentW(), ch = contentH();
        if (selected != null) return clickSettings(mx, my, btn, cx, cy, cw, ch);

        List<Module> mods = visibleModules();
        int colW = (cw - 8) / 2;
        for (int i = 0; i < mods.size(); i++) {
            int px = cx + (i % 2) * (colW + 8);
            int py = cy + (i / 2) * (CARD_H + 6) - (int) scroll;
            if (my < cy || my > cy + ch || !hit(mx, my, px, py, colW, CARD_H)) continue;
            Module m = mods.get(i);
            if (btn == 0) { m.toggle(); ConfigManager.requestSave(); }
            else if (btn == 1) { selected = m; scroll = 0; }
            else if (btn == 2) { bindTarget = m; }
            click();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    private boolean clickSettings(float mx, float my, int btn, int cx, int cy, int cw, int ch) {
        if (hit(mx, my, cx, cy - 4, 46, 12)) { selected = null; bindTarget = null; scroll = 0; click(); return true; }
        if (hit(mx, my, cx + cw - 46, cy - 4, 46, 12)) { selected.resetSettings(); ConfigManager.requestSave(); click(); return true; }
        if (hit(mx, my, cx + 80, cy - 4, cw - 130, 12) && my < cy + 10) { bindTarget = selected; click(); return true; }
        List<Setting<?>> list = selected.settings();
        int top = cy + 14, rowH = 22;
        for (int i = 0; i < list.size(); i++) {
            int py = top + i * (rowH + 3) - (int) scroll;
            if (py < top - rowH || py > cy + ch) continue;
            if (hit(mx, my, cx, py, cw, rowH) && my >= top && my <= cy + ch) {
                list.get(i).interact(btn == 1 ? -1 : 1);
                ConfigManager.requestSave();
                click();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (bindTarget != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE) {
                bindTarget.setKey(-1);
            } else {
                Module other = NyxvaultClient.modules().keyConflict(bindTarget, key);
                if (other != null) Notifications.push("Key in use by " + other.name());
                else bindTarget.setKey(key);
            }
            bindTarget = null;
            ConfigManager.requestSave();
            return true;
        }
        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); scroll = 0; return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE) { searchFocused = false; return true; }
            if (key == GLFW.GLFW_KEY_ENTER) { searchFocused = false; return true; }
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!searchFocused) return false;
        int cp = event.codepoint();
        if (cp >= 32 && search.length() < 24) {
            search += new String(Character.toChars(cp));
            scroll = 0;
            selected = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scroll -= (float) scrollY * 20f;
        if (scroll < 0) scroll = 0;
        return true;
    }

    // ---------------------------------------------------------------- helpers

    private static boolean hit(float mx, float my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private String trim(String text, int maxW) {
        if (font.width(text) <= maxW) return text;
        String t = text;
        while (t.length() > 1 && font.width(t + "..") > maxW) t = t.substring(0, t.length() - 1);
        return t + "..";
    }

    private static String keyName(int key) {
        return InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString().toUpperCase();
    }

    private void click() {
        if (UiSettings.guiSounds && minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f, UiSettings.soundVolume));
        }
    }
}
