package dev.nyxvault.setting;

import com.google.gson.JsonElement;

/** Base class for a typed, persistable module setting. */
public abstract class Setting<T> {
    private final String name;
    private final T defaultValue;
    protected T value;

    protected Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String name() { return name; }
    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public void reset() { this.value = defaultValue; }

    public abstract JsonElement toJson();
    /** Must ignore invalid input and keep the current value. */
    public abstract void fromJson(JsonElement e);
    public abstract String display();
    /** Primary click action in the GUI; {@code direction} is +1 (left click) or -1 (right click). */
    public abstract void interact(int direction);
}
