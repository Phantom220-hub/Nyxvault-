package dev.nyxvault.module.player;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.InventoryUtil;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Compact PvP panel with only information the local client has: your health, gear durability and resources. */
public final class PvpResourceHud extends HudModule {
    public enum Layout { VERTICAL, HORIZONTAL, COMPACT }

    private static final int MAX = 10;
    private static final EquipmentSlot[] ARMOR = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    private static final String[] ARMOR_NAMES = { "Шлем", "Нагрудник", "Поножи", "Ботинки" };

    private final EnumSetting<Layout> layout = add(new EnumSetting<>("Layout", Layout.VERTICAL));
    private final BoolSetting icons = add(new BoolSetting("Show Icons", true));
    private final BoolSetting health = add(new BoolSetting("Show Health", true));
    private final BoolSetting absorption = add(new BoolSetting("Show Absorption", true));
    private final BoolSetting armor = add(new BoolSetting("Show Armor", true));
    private final BoolSetting mainHand = add(new BoolSetting("Show Main Hand", true));
    private final BoolSetting totems = add(new BoolSetting("Show Totems", true));
    private final BoolSetting pearls = add(new BoolSetting("Show Pearls", true));
    private final NumberSetting durabilityWarn = add(NumberSetting.integer("Durability Warning (%)", 20, 5, 60));
    private final NumberSetting totemWarn = add(NumberSetting.integer("Totem Warning", 2, 0, 36));
    private final NumberSetting pearlWarn = add(NumberSetting.integer("Pearl Warning", 2, 0, 16));
    private final ColorSetting normal = add(new ColorSetting("Text Color", 0xFFFFFFFF));
    private final ColorSetting danger = add(new ColorSetting("Danger Color", 0xFFEF4444));

    private final String[] label = new String[MAX];
    private final boolean[] bad = new boolean[MAX];
    private final ItemStack[] icon = new ItemStack[MAX];
    private int n;
    private final boolean[] warnedDur = new boolean[5];
    private boolean warnedTotem, warnedPearl;
    private final ItemStack totemIcon = new ItemStack(Items.TOTEM_OF_UNDYING);
    private final ItemStack pearlIcon = new ItemStack(Items.ENDER_PEARL);

    public PvpResourceHud() {
        super("PVP Resource HUD", "Health, absorption, armor and weapon durability, totems and pearls with low-resource warnings.", Category.HUD, 4, 170);
    }

    @Override protected void onEnable() { java.util.Arrays.fill(warnedDur, false); warnedTotem = false; warnedPearl = false; }

    private static int pct(ItemStack s) {
        if (s.isEmpty() || !s.isDamageableItem()) return -1;
        return Math.round(100f * (s.getMaxDamage() - s.getDamageValue()) / s.getMaxDamage());
    }

    private void row(String text, boolean low, ItemStack ic) {
        if (n >= MAX) return;
        label[n] = text; bad[n] = low; icon[n] = ic; n++;
    }

    private void build(Minecraft mc) {
        n = 0;
        Player p = mc.player;
        if (p == null) return;
        int warn = durabilityWarn.asInt();
        if (health.get()) row(String.format("Здор. %.1f", p.getHealth()), p.getHealth() <= 6f, null);
        if (absorption.get() && p.getAbsorptionAmount() > 0f) row(String.format("Погл. %.1f", p.getAbsorptionAmount()), false, null);
        if (armor.get()) {
            for (int i = 0; i < 4; i++) {
                ItemStack s = p.getItemBySlot(ARMOR[i]);
                int pc = pct(s);
                if (pc >= 0) row(ARMOR_NAMES[i] + " " + pc + "%", pc <= warn, icons.get() ? s : null);
            }
        }
        if (mainHand.get()) {
            ItemStack s = p.getMainHandItem();
            int pc = pct(s);
            if (pc >= 0) row("В руке " + pc + "%", pc <= warn, icons.get() ? s : null);
        }
        if (totems.get()) { int c = InventoryUtil.count(p, Items.TOTEM_OF_UNDYING); row("Тотемы " + c, c <= totemWarn.asInt(), icons.get() ? totemIcon : null); }
        if (pearls.get()) { int c = InventoryUtil.count(p, Items.ENDER_PEARL); row("Жемчуг " + c, c <= pearlWarn.asInt(), icons.get() ? pearlIcon : null); }
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null) return;
        int warn = durabilityWarn.asInt();
        for (int i = 0; i < 4; i++) {
            int pc = pct(p.getItemBySlot(ARMOR[i]));
            boolean low = pc >= 0 && pc <= warn;
            if (low && !warnedDur[i]) { Notifications.push(ARMOR_NAMES[i] + ": прочность " + pc + "%", 1); warnedDur[i] = true; }
            else if (!low) warnedDur[i] = false;
        }
        int pc = pct(p.getMainHandItem());
        boolean lowHand = pc >= 0 && pc <= warn;
        if (lowHand && !warnedDur[4]) { Notifications.push("Предмет в руке: прочность " + pc + "%", 1); warnedDur[4] = true; }
        else if (!lowHand) warnedDur[4] = false;
        int t = InventoryUtil.count(p, Items.TOTEM_OF_UNDYING);
        if (totems.get()) {
            if (t <= totemWarn.asInt() && !warnedTotem) { Notifications.push("Мало тотемов: " + t, 1); warnedTotem = true; }
            else if (t > totemWarn.asInt()) warnedTotem = false;
        }
        int e = InventoryUtil.count(p, Items.ENDER_PEARL);
        if (pearls.get()) {
            if (e <= pearlWarn.asInt() && !warnedPearl) { Notifications.push("Мало жемчуга: " + e); warnedPearl = true; }
            else if (e > pearlWarn.asInt()) warnedPearl = false;
        }
    }

    private int rowW(Minecraft mc, int i) {
        return mc.font.width(label[i]) + (icon[i] != null && layout.get() != Layout.COMPACT ? 18 : 0) + 8;
    }

    @Override public int width(Minecraft mc) {
        build(mc);
        if (n == 0) return 60;
        if (layout.get() == Layout.HORIZONTAL) { int w = 2; for (int i = 0; i < n; i++) w += rowW(mc, i) + 2; return w; }
        int w = 60;
        for (int i = 0; i < n; i++) w = Math.max(w, rowW(mc, i));
        return w;
    }

    private int rowH() { return layout.get() == Layout.COMPACT || !icons.get() ? 11 : 17; }

    @Override public int height(Minecraft mc) {
        build(mc);
        if (n == 0) return 14;
        return layout.get() == Layout.HORIZONTAL ? rowH() + 4 : n * rowH() + 4;
    }

    @Override protected void draw(GuiGraphics g, Minecraft mc) {
        build(mc);
        int w = width(mc), h = height(mc);
        Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
        g.fill(0, 2, 2, h - 2, a(UiSettings.accent()));
        if (n == 0) { g.drawString(mc.font, "Нет данных", 6, 3, a(0xFF9CA3AF), true); return; }
        int x = 4, y = 2, rh = rowH();
        boolean withIcons = layout.get() != Layout.COMPACT;
        for (int i = 0; i < n; i++) {
            int tx = x;
            if (withIcons && icon[i] != null) { g.renderItem(icon[i], x, y); tx += 18; }
            g.drawString(mc.font, label[i], tx + 1, y + (rh - 8) / 2, a(bad[i] ? danger.get() : normal.get()), true);
            if (layout.get() == Layout.HORIZONTAL) x += rowW(mc, i) + 2; else y += rh;
        }
    }
}
