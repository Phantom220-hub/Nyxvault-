package dev.nyxvault.module.misc;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * HW Helper: a configurable, honest notification framework for server messages.
 *
 * What it really does: it watches the "game"/system messages your client receives and raises a
 * notification (on-screen, optional sound, history) when one contains a keyword YOU configured.
 * It does NOT detect HolyWorld events by itself, uses no private APIs and sends nothing to the
 * server. Keywords are stored per server (file hw-&lt;server&gt;.txt in the config folder).
 * Limit: messages that arrive as vanilla signed player chat are not seen by this hook.
 */
public final class HwHelper extends HudModule {
    public enum Profile { GENERIC, HOLYWORLD, CUSTOM }
    public enum Alert { NONE, ORB, CLICK }

    private static HwHelper instance;

    private final EnumSetting<Profile> profile = add(new EnumSetting<>("Server Profile", Profile.GENERIC));
    private final BoolSetting keywordAlerts = add(new BoolSetting("Keyword Alerts", true));
    private final BoolSetting keepHistory = add(new BoolSetting("Notification History", true));
    private final NumberSetting maxHistory = add(NumberSetting.integer("Max History", 20, 5, 50));
    private final NumberSetting panelLines = add(NumberSetting.integer("Panel Lines", 4, 1, 8));
    private final EnumSetting<Alert> alertSound = add(new EnumSetting<>("Alert Sound", Alert.ORB));
    private final NumberSetting volume = add(NumberSetting.decimal("Sound Volume", 0.7, 0.1, 1.0, 0.1));
    private final BoolSetting showStatus = add(new BoolSetting("Show Status", true));
    private final BoolSetting testNow = add(new BoolSetting("Test Notification", false));
    private final BoolSetting clearNow = add(new BoolSetting("Clear History", false));

    private final List<String> keywords = new ArrayList<>();
    private final List<String> history = new ArrayList<>();
    private String loadedFor = "";
    private String lastText = "";
    private long lastMs;

    public HwHelper() {
        super("HW Helper", "Keyword notifications for server messages with history and per-server settings. Does not detect server events by itself.", Category.UTILITIES, 4, 200);
        instance = this;
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            HwHelper h = instance;
            if (h != null && h.enabled() && !overlay) h.onMessage(message.getString());
        });
    }

    // ------------------------------------------------------------------ server key / files

    private static String serverKey() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getCurrentServer() == null) return "singleplayer";
        String ip = mc.getCurrentServer().ip;
        return ip == null || ip.isBlank() ? "unknown" : ip.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]", "_");
    }

    private Path file(String key) { return ConfigManager.dir().resolve("hw-" + key + ".txt"); }

    private void load() {
        String key = serverKey();
        keywords.clear();
        try {
            Path f = file(key);
            if (Files.exists(f)) {
                for (String line : Files.readAllLines(f, StandardCharsets.UTF_8)) {
                    String k = line.trim().toLowerCase(Locale.ROOT);
                    if (!k.isEmpty() && keywords.size() < 50 && !keywords.contains(k)) keywords.add(k);
                }
            }
        } catch (Exception e) {
            NyxvaultClient.LOGGER.warn("HW Helper: could not read keywords for {}", key, e);
        }
        loadedFor = key;
    }

    private void save() {
        try {
            Files.createDirectories(ConfigManager.dir());
            Files.write(file(loadedFor.isEmpty() ? serverKey() : loadedFor), keywords, StandardCharsets.UTF_8);
        } catch (Exception e) {
            NyxvaultClient.LOGGER.warn("HW Helper: could not save keywords", e);
        }
    }

    @Override protected void onEnable() { load(); }
    @Override public void onWorldChange() { load(); history.clear(); }

    // ------------------------------------------------------------------ events

    private void play(Minecraft mc) {
        if (mc.player == null) return;
        switch (alertSound.get()) {
            case ORB -> mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, volume.asFloat()));
            case CLICK -> mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, volume.asFloat()));
            default -> { }
        }
    }

    private void record(String text) {
        if (!keepHistory.get()) return;
        history.add(String.format("%02d:%02d ", LocalTime.now().getHour(), LocalTime.now().getMinute()) + text);
        while (history.size() > maxHistory.asInt()) history.remove(0);
    }

    private void fire(Minecraft mc, String shown) {
        Notifications.push("[HW] " + shown, 1);
        record(shown);
        play(mc);
    }

    private void onMessage(String raw) {
        if (!keywordAlerts.get() || keywords.isEmpty() || raw == null) return;
        String low = raw.toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        if (raw.equals(lastText) && now - lastMs < 2000) return; // duplicate burst
        for (String k : keywords) {
            if (low.contains(k)) {
                lastText = raw; lastMs = now;
                String shown = raw.length() > 70 ? raw.substring(0, 70) + "..." : raw;
                fire(Minecraft.getInstance(), shown);
                return;
            }
        }
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (!loadedFor.equals(serverKey())) load();
        if (testNow.get()) { testNow.set(false); fire(mc, "Тестовое уведомление"); }
        if (clearNow.get()) { clearNow.set(false); history.clear(); Notifications.push("[HW] История очищена"); }
    }

    // ------------------------------------------------------------------ HUD

    private String status() {
        if (profile.get() == Profile.HOLYWORLD) return "HolyWorld: события не распознаются, только ваши слова";
        if (profile.get() == Profile.CUSTOM) return "Свой профиль: ваши ключевые слова";
        return "Общий профиль: ваши ключевые слова";
    }

    private int lines() { return Math.min(panelLines.asInt(), history.size()); }

    @Override public int width(Minecraft mc) { return 190; }
    @Override public int height(Minecraft mc) { return 14 + (showStatus.get() ? 11 : 0) + Math.max(1, lines()) * 11; }

    @Override protected void draw(GuiGraphics g, Minecraft mc) {
        int w = width(mc), h = height(mc);
        Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
        g.fill(0, 2, 2, h - 2, a(UiSettings.accent()));
        g.drawString(mc.font, "HW Helper  слов: " + keywords.size(), 6, 3, a(0xFFFFFFFF), true);
        int y = 14;
        if (showStatus.get()) { g.drawString(mc.font, mc.font.plainSubstrByWidth(status(), w - 10), 6, y, a(0xFFEAB308), true); y += 11; }
        int n = lines();
        if (n == 0) { g.drawString(mc.font, keywords.isEmpty() ? "Нет слов: /nyx hw add <слово>" : "Событий нет", 6, y, a(0xFF9CA3AF), true); return; }
        for (int i = 0; i < n; i++) {
            String s = history.get(history.size() - 1 - i);
            g.drawString(mc.font, mc.font.plainSubstrByWidth(s, w - 10), 6, y, a(0xFFD1D5DB), true);
            y += 11;
        }
    }

    // ------------------------------------------------------------------ commands

    private static void say(FabricClientCommandSource src, String msg) { src.sendFeedback(Component.literal("[HW] " + msg)); }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        var hw = ClientCommandManager.literal("hw")
                .then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("word", StringArgumentType.greedyString()).executes(c -> {
                    HwHelper h = instance;
                    if (h == null) return 0;
                    String k = StringArgumentType.getString(c, "word").trim().toLowerCase(Locale.ROOT);
                    if (k.isEmpty() || h.keywords.size() >= 50) { say(c.getSource(), "Нельзя добавить (пусто или больше 50 слов)."); return 0; }
                    if (!h.keywords.contains(k)) h.keywords.add(k);
                    h.save();
                    say(c.getSource(), "Добавлено: " + k);
                    return 1;
                })))
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("word", StringArgumentType.greedyString()).executes(c -> {
                    HwHelper h = instance;
                    if (h == null) return 0;
                    boolean ok = h.keywords.remove(StringArgumentType.getString(c, "word").trim().toLowerCase(Locale.ROOT));
                    h.save();
                    say(c.getSource(), ok ? "Удалено." : "Такого слова нет.");
                    return ok ? 1 : 0;
                })))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    HwHelper h = instance;
                    say(c.getSource(), h == null || h.keywords.isEmpty() ? "Слов нет." : String.join(", ", h.keywords));
                    return 1;
                }))
                .then(ClientCommandManager.literal("clear").executes(c -> {
                    HwHelper h = instance;
                    if (h != null) { h.keywords.clear(); h.save(); }
                    say(c.getSource(), "Слова очищены.");
                    return 1;
                }))
                .then(ClientCommandManager.literal("history").executes(c -> {
                    HwHelper h = instance;
                    if (h == null || h.history.isEmpty()) { say(c.getSource(), "История пуста."); return 1; }
                    for (String s : h.history) say(c.getSource(), s);
                    return 1;
                }))
                .then(ClientCommandManager.literal("test").executes(c -> {
                    HwHelper h = instance;
                    if (h != null) h.fire(Minecraft.getInstance(), "Тестовое уведомление");
                    return 1;
                }));
        d.register(ClientCommandManager.literal("nyx").then(hw));
    }
}
