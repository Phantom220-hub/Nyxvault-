package dev.nyxvault.util;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Central Russian localization. Internal identifiers (module names, setting names, enum constants,
 * config keys) stay English so saved configs keep working; only text that is SHOWN passes through here.
 * Anything without a translation falls back to the English original, so nothing ever shows blank.
 */
public final class Lang {
    private static final Map<String, String> UI = new HashMap<>();
    private static final Map<String, String> MODULE = new HashMap<>();
    private static final Map<String, String> DESC = new HashMap<>();
    private static final Map<String, String> SETTING = new HashMap<>();
    private static final Map<String, String> VALUE = new HashMap<>();
    /** Set false to see the original English text everywhere (debugging). */
    public static boolean russian = true;

    private Lang() { }

    private static void ui(String en, String ru) { UI.put(en, ru); }
    private static void m(String en, String ru, String desc) { MODULE.put(en, ru); DESC.put(en, desc); }
    private static void s(String en, String ru) { SETTING.put(en, ru); }
    private static void v(String en, String ru) { VALUE.put(en, ru); }

    // ------------------------------------------------------------------ lookup

    /** Generic phrase (HUD labels, notifications, GUI text). */
    public static String t(String en) {
        if (!russian) return en;
        String r = UI.get(en);
        return r != null ? r : en;
    }

    public static String module(Module mod) { return module(mod.name()); }
    public static String module(String en) {
        if (!russian) return en;
        String r = MODULE.get(en);
        return r != null ? r : en;
    }

    public static String desc(Module mod) {
        if (!russian) return mod.description();
        String r = DESC.get(mod.name());
        return r != null ? r : mod.description();
    }

    public static String setting(String en) {
        if (!russian) return en;
        String r = SETTING.get(en);
        return r != null ? r : en;
    }

    /** Displayed value of a setting (enum constant, ON/OFF). Numbers and colors pass through. */
    public static String value(String en) {
        if (!russian) return en;
        String r = VALUE.get(en);
        return r != null ? r : en;
    }

    /** Value of the named setting; the mouse "Button" setting needs different words than the HUD "Alignment". */
    public static String value(String settingName, String en) {
        if (russian && "Button".equals(settingName)) {
            if ("LEFT".equals(en)) return "Левая";
            if ("RIGHT".equals(en)) return "Правая";
        }
        return value(en);
    }

    public static String category(Category c) {
        if (!russian) return c.title;
        String r = UI.get("cat." + c.name());
        return r != null ? r : c.title;
    }

    /** True when the module matches the search text in Russian or English. */
    public static boolean matches(Module mod, String queryLower) {
        if (queryLower.isEmpty()) return true;
        return mod.name().toLowerCase(Locale.ROOT).contains(queryLower)
                || mod.description().toLowerCase(Locale.ROOT).contains(queryLower)
                || module(mod).toLowerCase(Locale.ROOT).contains(queryLower)
                || desc(mod).toLowerCase(Locale.ROOT).contains(queryLower);
    }

    public static boolean hasModule(String en) { return MODULE.containsKey(en); }
    public static boolean hasSetting(String en) { return SETTING.containsKey(en); }
    public static boolean hasValue(String en) { return VALUE.containsKey(en); }
    public static boolean hasDesc(String en) { return DESC.containsKey(en); }

    // ------------------------------------------------------------------ data

    static {
        // categories
        ui("cat.COMBAT", "Бой"); ui("cat.VISUALS", "Визуалы"); ui("cat.MOVEMENT", "Движение");
        ui("cat.PLAYER", "Игрок"); ui("cat.HUD", "HUD"); ui("cat.WORLD", "Мир");
        ui("cat.UTILITIES", "Утилиты"); ui("cat.MISC", "Прочее"); ui("cat.SETTINGS", "Настройки");

        // GUI
        ui("Search modules...", "Поиск модулей...");
        ui("No modules found", "Модули не найдены");
        ui("This module has no settings.", "У этого модуля нет настроек.");
        ui("< Back", "< Назад");
        ui("RMB: settings", "ПКМ: настройки");
        ui("Reset", "Сброс");
        ui("Key", "Клавиша");
        ui("Key: none", "Клавиша: нет");
        ui("Waypoints screen", "Метки мира");
        ui("Marks", "Метки");
        ui("HUD editor", "Редактор HUD");
        ui("(off)", "(выкл.)");
        ui("Drag elements. Esc to save and close.", "Перетаскивайте элементы. Esc: сохранить и выйти.");

        // HUD labels
        ui("No target", "Нет цели");
        ui("Auction", "Аукцион"); ui("Idle", "Ожидание"); ui("Price", "Ввод цены"); ui("Selling", "Продаёт"); ui("Waiting", "Лимит, ждёт");
        ui("Sold", "Продано"); ui("Earned", "Выручка"); ui("Retry in", "Повтор через");
        ui("Armor", "Броня");
        ui("m", "м");
        ui("s", "с");
        ui("north", "С"); ui("south", "Ю"); ui("east", "В"); ui("west", "З");
        ui("FPS", "FPS");
        ui("ms", "мс");
        ui("Ping: n/a", "Пинг: н/д");
        ui("Ping", "Пинг");
        ui("Session", "Сессия");
        ui("No active waypoint", "Нет активной метки");
        ui(": other dimension", ": другое измерение");
        ui("No effects", "Нет эффектов");
        ui("inf", "беск.");
        ui("Pops", "Потеряно тотемов");
        ui("Cooldown", "Перезарядка");
        ui("Hits", "Попад.");
        ui("Combo", "Комбо");
        ui("best", "рекорд");
        ui("Food", "Сытость");
        ui("Speed", "Скорость");
        ui("b/s", "бл/с");
        ui("Dim", "Мир");
        ui("Time", "Время");
        ui("Distance", "Дистанция");
        ui("Swings", "Взмахи");
        ui("Best combo", "Лучшее комбо");
        ui("No block targeted", "Нет блока под прицелом");
        ui("Light", "Свет");
        ui("block", "блок");
        ui("sky", "небо");
        ui("No players nearby", "Нет игроков рядом");
        ui("Totems", "Тотемы");
        ui("Golden Apples", "Золотые яблоки");
        ui("Ender Pearls", "Жемчуг Края");
        ui("Arrows", "Стрелы");
        ui("XP Bottles", "Пузырьки опыта");
        ui("No items selected", "Предметы не выбраны");
        ui("SPACE", "ПРОБ");
        ui("LMB", "ЛКМ");
        ui("RMB", "ПКМ");
        ui("ON", "ВКЛ");
        ui("OFF", "ВЫКЛ");
        ui("Player nearby: ", "Игрок рядом: "); ui("Overworld", "Верхний мир"); ui("Nether", "Незер"); ui("No conversion here", "Здесь нет пересчёта");
        ui("Preview", "Образец");

        // notifications
        ui("PANIC: ", "ПАНИКА: ");
        ui(" module(s) disabled", " мод. выключено");
        ui("Key in use by ", "Клавиша занята: ");
        ui("LOW TOTEMS: ", "МАЛО ТОТЕМОВ: ");
        ui("durability", "прочность");
        ui("Golden apples low: ", "Мало золотых яблок: ");
        ui("Ender pearls low: ", "Мало жемчуга Края: ");
        ui("LOW HEALTH: ", "МАЛО ЗДОРОВЬЯ: ");
        ui("hearts", "сердец");
        ui("Death point saved: ", "Точка смерти сохранена: ");
        ui("WAYPOINT REACHED: ", "МЕТКА ДОСТИГНУТА: ");
        ui("Helmet", "Шлем"); ui("Chestplate", "Нагрудник"); ui("Leggings", "Поножи"); ui("Boots", "Ботинки");
        ui("Auto Totem: totem equipped", "Авто-тотем: тотем в левой руке");
        ui("Auto Totem: no totems left", "Авто-тотем: тотемов нет");
        ui("Auto Totem: paused (too many attempts)", "Авто-тотем: пауза (много попыток)");
        ui("Waypoint saved", "Метка сохранена");
        ui("Waypoint deleted", "Метка удалена");
        ui("Waypoint removed (auto)", "Метка удалена автоматически");

        // modules: name, Russian name, Russian description
        m("Armor HUD", "HUD брони", "Надетая броня с прочностью.");
        m("Player Alert", "Оповещение об игроках", "Один раз предупреждает, когда рядом появляется новый игрок (только загруженные у вас игроки).");
        m("Nether Coords", "Координаты Незера", "Координаты в другом измерении (Верхний мир / 8, Незер x 8).");
        m("Auto Bridge", "Авто-мост", "Ставит блок из руки под ноги для моста и джамп-моста. Прыгаете вы сами. Проверьте правила сервера.");
        m("Nick Hider", "Скрытие ника", "Показывает другое имя вместо вашего, только на вашем экране. Другие видят настоящий ник.");
        m("Combat Awareness", "Боевая осведомлённость", "Информация об игроке, на которого вы смотрите: дистанция, здоровье, движение, стрелка за экраном. Без наведения и атак.");
        m("HUD Motion", "Анимация HUD", "Плавное появление и исчезновение элементов HUD: сдвиг, затухание, масштаб.");
        m("HW Helper", "HW помощник", "Уведомления по вашим ключевым словам из сообщений сервера, история и настройки для каждого сервера. Сам события сервера не распознаёт.");
        m("HolyWorld Helper", "HolyWorld помощник", "Метка над невидимыми игроками, о которых клиент уже знает. По умолчанию выключен; проверьте правила сервера.");
        m("PVP Resource HUD", "PvP-ресурсы", "Здоровье, поглощение, прочность брони и оружия, тотемы и жемчуг с предупреждениями.");
        m("Pearl Assistant", "Помощник жемчуга", "Количество жемчуга, слот и перезарядка. Ничего не бросает и не целится; клавиша только выбирает слот.");
        m("Player ESP", "ESP игроков", "Рамки, контур, трассеры и подписи игроков. Режим «сквозь стены» выключен по умолчанию; проверьте правила сервера.");
        m("Totem Counter", "Счётчик тотемов", "Считает тотемы в вашем инвентаре с предупреждением о малом запасе.");
        m("Trap Warning", "Предупреждение о блоках", "Предупреждает о выбранных блоках рядом (загруженные открытые блоки). Только информация, без автоматических действий.");
        m("Auction Seller", "Автопродажа на аукционе", "Сам раскладывает предмет из руки по одной штуке и продаёт командой /ah sell. При включении спрашивает цену. При лимите ждёт и повторяет. Проверьте правила сервера.");
        m("Auction Stats", "Статистика аукциона", "Статус автопродажи: продано, примерная выручка и таймер повтора.");
        m("Hotbar Fill", "Заполнение панели", "Раскладывает предмет из руки по одному в пустые ячейки панели. Включите, чтобы выполнить один раз. Проверьте правила сервера.");
        m("Auto Attack", "Авто-удар", "Бьёт моба под прицелом, когда оружие перезарядилось, по желанию только критами. Для ферм мобов. Проверьте правила сервера.");
        m("Auto Totem", "Авто-тотем", "Кладёт тотем в левую руку, если она пуста. Проверьте правила сервера!");
        m("AutoClicker", "Автокликер", "Повторяет клик, пока зажата кнопка мыши. Может нарушать правила сервера!");
        m("Brightness", "Яркость", "Меняет обычную настройку яркости (возвращается при выключении).");
        m("CPS", "CPS", "Клики в секунду (реальные нажатия мыши).");
        m("Clock", "Часы", "Реальное и игровое время.");
        m("Combat HUD", "Боевой HUD", "Перезарядка атаки, попадания, комбо и CPS.");
        m("Compass", "Компас", "Полоса направления со сторонами света.");
        m("Coordinates", "Координаты", "Координаты и направление взгляда.");
        m("Custom Crosshair", "Свой прицел", "Дополнительный настраиваемый прицел (обычный остаётся).");
        m("Damage Flash", "Вспышка урона", "Короткая красная вспышка по краям экрана при уроне.");
        m("Death Waypoint", "Метка смерти", "Сохраняет метку в месте вашей смерти.");
        m("FPS", "FPS", "FPS и примерное время кадра.");
        m("Hit Effects", "Эффекты попадания", "Короткая геометрическая вспышка при подтверждённом попадании (определяется на клиенте).");
        m("Hit Marker", "Маркер попадания", "Четырёхсегментный маркер, когда клиент видит урон по цели.");
        m("Interface", "Интерфейс", "Тема, цвет акцента, анимации, звуки и масштаб GUI.");
        m("Item Counter", "Счётчик предметов", "Количество выбранных предметов в инвентаре.");
        m("Jump Circle", "Круг прыжка", "Расширяющееся кольцо под ногами при прыжке и приземлении. Только визуал.");
        m("Keystrokes", "Клавиши", "WASD, прыжок и кнопки мыши.");
        m("Light Level", "Уровень света", "Блочный и небесный свет в вашей позиции.");
        m("Low Health Alert", "Предупреждение о здоровье", "Один раз предупреждает, когда здоровье падает до выбранного числа сердец.");
        m("Module List", "Список модулей", "Список включённых модулей с плавными переходами.");
        m("Motion Trail", "След движения", "Плавная затухающая линия за вами. Только визуал, движение не меняется.");
        m("Nearby Players", "Игроки рядом", "Игроки, загруженные у вас, в радиусе (ник, дистанция, здоровье).");
        m("Ping", "Пинг", "Задержка, сообщаемая сервером.");
        m("Player Info", "Инфо об игроке", "Здоровье, сытость, измеренная скорость и измерение.");
        m("Potion HUD", "HUD эффектов", "Активные эффекты зелий с таймерами.");
        m("Resource Alerts", "Оповещения о ресурсах", "Один раз предупреждает, когда мало тотемов, прочности брони или выбранных предметов.");
        m("Session Stats", "Статистика сессии", "Время, дистанция, взмахи, попадания и потери тотемов. Включите «Сбросить сейчас», чтобы очистить.");
        m("Session Timer", "Таймер сессии", "Время с запуска игры.");
        m("TNT Countdown", "Таймер TNT", "Таймер запала над активированным TNT (значение клиента).");
        m("Target Block", "Блок под прицелом", "Название и расстояние до блока, на который вы смотрите.");
        m("Target Circle", "Круг цели", "Анимированное кольцо под врагом, с которым вы сражаетесь (нужна линия видимости, вид от первого лица).");
        m("Target Effects", "Эффекты цели", "Сферы и орбитальные кольца вокруг врага (нужна линия видимости, вид от первого лица).");
        m("Target HUD", "HUD цели", "Имя, плавная полоса здоровья, дистанция и броня последней атакованной цели. Скрывается, когда цели нет.");
        m("Toggle Sprint", "Авто-спринт", "Бежит автоматически, пока вы зажимаете «вперёд».");
        m("Totem HUD", "HUD тотемов", "Тотем в левой руке и общее число тотемов.");
        m("Totem Pop Counter", "Счётчик потерь тотемов", "Сколько ваших тотемов сработало за сессию (определяется на клиенте).");
        m("Watermark", "Водяной знак", "Показывает водяной знак NYXVAULT.");
        m("Waypoint HUD", "HUD метки", "Дистанция, координаты и направление активной метки.");
        m("Waypoint Markers", "Маркеры меток", "Рисует метки в мире с названием и расстоянием.");
        m("Waypoints", "Метки мира", "Настройки меток. Управление: экран «Метки мира» или /nyx wp ...");
        m("Weapon Trail", "След оружия", "Лента за взмахом меча (приближение дуги удара, а не реальная модель).");

        // settings
        s("Accent Bar", "Полоса акцента"); s("Accent Color", "Цвет акцента");
        s("Active Waypoint Only", "Только активная метка"); s("Alignment", "Выравнивание");
        s("Animation Intensity", "Сила анимации"); s("Animation Speed", "Скорость анимации");
        s("Armor Durability Warning", "Предупреждение о броне"); s("Armor Threshold (%)", "Порог брони (%)");
        s("Arrival Radius", "Радиус прибытия"); s("Arrows", "Стрелы");
        s("Auto-Remove on Arrival", "Удалять при прибытии"); s("Button", "Кнопка");
        s("CPS", "CPS"); s("Color", "Цвет"); s("Compact Layout", "Компактный вид");
        s("Custom Accent", "Свой акцент"); s("Custom Color", "Свой цвет"); s("Custom Radius", "Свой радиус");
        s("Danger Color", "Цвет опасности"); s("Duration (ms)", "Длительность (мс)");
        s("Dynamic States", "Динамические состояния"); s("Ender Pearl Alert", "Оповещение о жемчуге");
        s("Ender Pearl Threshold", "Порог жемчуга"); s("Ender Pearls", "Жемчуг Края");
        s("Expanding Ring", "Расширяющееся кольцо"); s("Expansion Speed", "Скорость расширения");
        s("Fade Duration (ms)", "Время затухания (мс)"); s("Fade Start (%)", "Начало затухания (%)");
        s("Follow Target", "Следовать за целью"); s("GUI Scale", "Масштаб GUI"); s("GUI Sounds", "Звуки GUI");
        s("Gap", "Зазор"); s("Glow", "Свечение"); s("Golden Apple Alert", "Оповещение о яблоках");
        s("Golden Apple Threshold", "Порог яблок"); s("Golden Apples", "Золотые яблоки");
        s("Gradient Color", "Цвет градиента"); s("Health Colors", "Цвета здоровья");
        s("Health Smoothing", "Плавность здоровья"); s("Hide Delay (s)", "Скрыть через (с)");
        s("Intensity", "Интенсивность"); s("Label Scale", "Масштаб подписи"); s("Landing Color", "Цвет приземления");
        s("Landing Ring", "Кольцо приземления"); s("Length", "Длина"); s("Level", "Уровень");
        s("Lifetime (ms)", "Время жизни (мс)"); s("Low Totem Alert", "Оповещение о тотемах");
        s("Marker Size", "Размер маркера"); s("Max Distance", "Макс. дистанция"); s("Max Players", "Макс. игроков");
        s("Max Radius", "Макс. радиус"); s("Notification", "Уведомление");
        s("Notification Duration (s)", "Длительность уведомлений (с)"); s("Opacity", "Прозрачность");
        s("Orb Color", "Цвет сфер"); s("Orb Count", "Число сфер"); s("Orb Size", "Размер сфер");
        s("Orbit Radius", "Радиус орбиты"); s("Performance Mode", "Режим производительности");
        s("Performance Preset", "Пресет производительности"); s("Primary Color", "Основной цвет");
        s("Radius", "Радиус"); s("Reduced Effects", "Меньше эффектов");
        s("Reduced Effects (no ring)", "Меньше эффектов (без кольца)"); s("Removal Mode", "Режим удаления");
        s("Reset Now", "Сбросить сейчас"); s("Reverse Direction", "Обратное направление");
        s("Ring Color", "Цвет колец"); s("Ring Thickness", "Толщина колец"); s("Rotation Speed", "Скорость вращения");
        s("Scale", "Масштаб"); s("Secondary Color", "Второй цвет"); s("Select As Active", "Сделать активной");
        s("Show Accent Ring", "Показывать кольцо у ног"); s("Show Armor", "Показывать броню");
        s("Show Distance", "Показывать дистанцию"); s("Show Durability", "Показывать прочность");
        s("Show Names", "Показывать названия"); s("Show Orbit Lines", "Показывать линии орбит");
        s("Show Orbs", "Показывать сферы"); s("Show Rings", "Показывать кольца"); s("Size", "Размер");
        s("Smoothing Quality", "Качество сглаживания"); s("Sound", "Звук"); s("Sound Volume", "Громкость звуков");
        s("Spacing", "Интервал"); s("Speed", "Скорость"); s("Style", "Стиль"); s("Target Color", "Цвет цели");
        s("Theme", "Тема"); s("Thickness", "Толщина"); s("Threshold (hearts)", "Порог (сердца)");
        s("Timing Variation", "Разброс времени"); s("Totem Threshold", "Порог тотемов"); s("Totems", "Тотемы");
        s("Width", "Ширина"); s("X", "X"); s("Y", "Y");
        // settings added later (also listed so the verifier finds them)
        s("Auto Remove (s)", "Автоудаление (с)");
        s("XP Bottles", "Пузырьки опыта");
        s("Only Crits", "Только криты");
        s("Target Filter", "Кого бить"); s("Min Cooldown (%)", "Мин. перезарядка (%)"); s("Pause While Using Item", "Пауза при использовании предмета");
        s("Only While Moving", "Только в движении"); s("Pause While Sneaking", "Пауза при приседании");
        s("Fake Name", "Подменное имя");
        s("Custom", "Свой");
        s("Fill Delay (ticks)", "Задержка раскладки (тики)"); s("Max Items", "Макс. штук (0 - без лимита)");
        s("Ask Price On Start", "Спрашивать цену при старте"); s("Stop On Damage", "Стоп при уроне"); s("Finish Sound", "Звук по окончании");
        s("Price", "Цена"); s("Command", "Команда"); s("Retry (sec)", "Повтор (сек)");
        s("Items Per Slot", "Штук в ячейку");
        s("Delay (ticks)", "Задержка (тики)");
        s("Enabled", "Включено"); s("Name", "Название");

        // phase 5/6 settings
        s("Alert Sound", "Звук оповещения");
        s("Anvil", "Наковальня");
        s("Box Style", "Стиль рамки");
        s("Boxes", "Рамки");
        s("Clear History", "Очистить историю");
        s("Cobweb", "Паутина");
        s("Detection Radius", "Радиус обнаружения");
        s("Direction Indicator", "Указатель направления");
        s("Distance Gradient", "Градиент по дистанции");
        s("Durability Warning (%)", "Порог прочности (%)");
        s("Exposed Blocks Only", "Только открытые блоки");
        s("Fade Distant", "Затухание вдали");
        s("Far Color", "Цвет вдали");
        s("Fill", "Заливка");
        s("Fill Opacity", "Прозрачность заливки");
        s("Fire", "Огонь");
        s("Glow Intensity", "Сила свечения");
        s("Height Offset", "Смещение по высоте");
        s("Hold Time (s)", "Время удержания (с)");
        s("Horizontal Scale", "Горизонтальный масштаб");
        s("Indicator Size", "Размер указателя");
        s("Inner Radius (%)", "Внутренний радиус (%)");
        s("Invisible Indicator", "Метка невидимых");
        s("Keyword Alerts", "Оповещения по словам");
        s("Labels", "Подписи");
        s("Lava", "Лава");
        s("Layout", "Раскладка");
        s("Max History", "Размер истории");
        s("Min Radius", "Мин. радиус");
        s("Near Color", "Цвет вблизи");
        s("Notification History", "История уведомлений");
        s("Obsidian", "Обсидиан");
        s("Off-screen Indicator", "Стрелка за экраном");
        s("Outline Thickness", "Толщина контура");
        s("Panel Lines", "Строк в панели");
        s("Pearl Warning", "Порог жемчуга");
        s("Pointed Dripstone", "Капельник");
        s("Preferred Slot (0 = auto)", "Нужный слот (0 = авто)");
        s("RGB Animation", "RGB-анимация");
        s("RGB Speed", "Скорость RGB");
        s("Ready Reminder", "Напоминание о готовности");
        s("Ready Sound", "Звук готовности");
        s("Reduced Motion", "Меньше движения");
        s("Ring Opacity", "Прозрачность колец");
        s("Rounded Corners", "Скруглённые углы");
        s("Server Profile", "Профиль сервера");
        s("Shape", "Форма");
        s("Show Absorption", "Показывать поглощение");
        s("Show Breakdown", "Показывать пояс и руку");
        s("Show Cooldown", "Показывать перезарядку");
        s("Show Health", "Показывать здоровье");
        s("Show Icons", "Показывать значки");
        s("Show Main Hand", "Показывать предмет в руке");
        s("Show Movement", "Показывать движение");
        s("Show Name", "Показывать ник");
        s("Show Pearls", "Показывать жемчуг");
        s("Show Slot", "Показывать слот");
        s("Show Status", "Показывать статус");
        s("Show Totems", "Показывать тотемы");
        s("Smooth Counter", "Плавный счётчик");
        s("Smoothness", "Плавность");
        s("Sphere Opacity", "Прозрачность сфер");
        s("TNT", "TNT");
        s("Test Notification", "Тестовое уведомление");
        s("Text Color", "Цвет текста");
        s("Text Opacity", "Прозрачность текста");
        s("Text Scale", "Размер текста");
        s("Through Walls", "Сквозь стены");
        s("Totem Warning", "Порог тотемов");
        s("Tracer Origin", "Начало трассера");
        s("Tracer Target", "Конец трассера");
        s("Tracer Thickness", "Толщина трассера");
        s("Tracers", "Трассеры");
        s("Vertical Scale", "Вертикальный масштаб");
        s("Warning Color", "Цвет предупреждения");
        s("Warning Opacity", "Прозрачность предупреждения");
        s("Warning Sound", "Звук предупреждения");
        s("Warning Threshold", "Порог предупреждения");

        // values
        v("AH_SELL", "/ah sell"); v("AUCTION_SELL", "/auction sell");
        v("ON", "ВКЛ"); v("OFF", "ВЫКЛ");
        v("ACTIVE_ONLY", "Только активная"); v("ALL_REACHED", "Все достигнутые");
        v("LOW", "Низкий"); v("BALANCED", "Баланс"); v("HIGH", "Высокий");
        v("DOTS", "Точки"); v("FILLED", "Заливка");
        v("HOSTILE_MOBS", "Враждебные мобы"); v("CREEPERS_ONLY", "Только криперы"); v("ALL_LIVING", "Все живые (включая игроков)");
        v("ANONYMOUS", "Аноним"); v("PLAYER", "Player"); v("STEVE", "Steve"); v("ALEX", "Alex"); v("NYXVAULT", "NYXVAULT");
        v("BODY", "Тело");
        v("BOTTOM", "Снизу");
        v("BOX_2D", "Рамка 2D");
        v("BOX_3D", "Рамка 3D");
        v("CENTER", "Центр");
        v("CLICK", "Щелчок");
        v("COMPACT", "Компактно");
        v("CORNERS", "Уголки");
        v("DIAMOND", "Ромб");
        v("FADE", "Затухание");
        v("FEET", "Ноги");
        v("GENERIC", "Общий");
        v("HEAD", "Голова");
        v("HOLYWORLD", "HolyWorld");
        v("HORIZONTAL", "Горизонтально");
        v("NONE", "Нет");
        v("ORB", "Звон");
        v("OUTLINE", "Контур");
        v("RING", "Кольцо");
        v("SCALE", "Масштаб");
        v("SLIDE", "Сдвиг");
        v("SLIDE_FADE", "Сдвиг и затухание");
        v("TOP", "Сверху");
        v("TRIANGLE", "Треугольник");
        v("VERTICAL", "Вертикально");
        v("BURST", "Взрыв"); v("CIRCLE", "Круг"); v("CLEAN", "Чистый"); v("CROSS", "Крест");
        v("CUSTOM", "Свой"); v("CYAN_FLASH", "Голубая вспышка"); v("DOT", "Точка"); v("DOUBLE", "Двойной");
        v("GRADIENT", "Градиент"); v("LINE", "Линия"); v("MINIMAL", "Минимал"); v("MULTI_ORB", "Несколько сфер");
        v("ORBIT_RINGS", "Орбитальные кольца"); v("PINK_STREAK", "Розовый росчерк"); v("PLUS_DOT", "Плюс и точка");
        v("PULSE", "Пульс"); v("PURPLE_RING", "Фиолетовое кольцо"); v("RIBBON", "Лента");
        v("SEGMENTS", "Сегменты"); v("SINGLE_ORB", "Одна сфера"); v("WHITE_FLASH", "Белая вспышка");
        v("LEFT", "Слева"); v("RIGHT", "Справа");
        v("BLOCKS_1", "1 блок"); v("BLOCKS_2", "2 блока"); v("BLOCKS_3", "3 блока");
        v("BLOCKS_5", "5 блоков"); v("BLOCKS_10", "10 блоков");
        v("NYXVAULT_SIGNATURE", "NYXVAULT (фирменная)"); v("DARK_PURPLE", "Тёмно-фиолетовая");
        v("CYBERPUNK_BLUE", "Киберпанк-синяя"); v("MINIMAL_DARK", "Минимал тёмная");
    }
}
