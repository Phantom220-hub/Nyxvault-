package dev.nyxvault.gui;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.player.AuctionFlipper;
import dev.nyxvault.render.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Start dialog for Auction Flipper: what to buy, max price per piece, resale price per piece. */
public final class FlipSetupScreen extends Screen {
    private static final int PW = 320, PH = 190;
    private static final String[] LABELS = { "Название предмета (для /ah search)", "Макс. цена покупки за 1 шт.", "Цена продажи за 1 шт." };

    private final AuctionFlipper module;
    private final StringBuilder[] f = { new StringBuilder(), new StringBuilder(), new StringBuilder() };
    private int focus;
    private boolean done;
    private float s = 1f, ox, oy;

    public FlipSetupScreen(AuctionFlipper module, String filter, int maxUnit, int resell) {
        super(Component.literal("Авто-перекуп"));
        this.module = module;
        f[0].append(filter);
        f[1].append(maxUnit);
        f[2].append(resell);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        if (!done) { done = true; module.cancelSetup(); }
        minecraft.setScreen(null);
    }

    private static int num(StringBuilder b) {
        if (b.length() == 0) return 0;
        try { return (int) Math.min(2_000_000_000L, Long.parseLong(b.toString())); } catch (NumberFormatException e) { return 2_000_000_000; }
    }

    private void confirm() {
        int a = num(f[1]), b = num(f[2]);
        if (a < 1 || b < 1) return;
        done = true;
        module.confirmSetup(f[0].toString().trim(), a, b);
        minecraft.setScreen(null);
    }

    private void layout() {
        s = Math.max(0.5f, Math.min(2.5f, Math.min(width / (PW + 16f), height / (PH + 16f))));
        ox = (width - PW * s) / 2f;
        oy = (height - PH * s) / 2f;
    }

    private static boolean in(float mx, float my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void button(GuiGraphics g, float mx, float my, int x, int y, int w, int h, String label, int accent) {
        boolean hov = in(mx, my, x, y, w, h);
        Draw.round(g, x, y, w, h, hov ? 0xFF1B1B3A : UiSettings.theme.panel);
        Draw.border(g, x, y, w, h, accent);
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        layout();
        float mx = (float) ((mouseX - ox) / s), my = (float) ((mouseY - oy) / s);
        g.fill(0, 0, width, height, 0xAA000000);
        g.pose().pushMatrix();
        g.pose().translate(ox, oy);
        g.pose().scale(s, s);
        int accent = UiSettings.accent();
        Draw.round(g, 0, 0, PW, PH, UiSettings.theme.background);
        Draw.border(g, 0, 0, PW, PH, accent);
        g.drawString(font, "Авто-перекуп", 12, 8, 0xFFFFFFFF, true);
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        for (int i = 0; i < 3; i++) {
            int y = 24 + i * 40;
            g.drawString(font, LABELS[i], 12, y, 0xFF9CA3AF, true);
            Draw.round(g, 12, y + 11, PW - 24, 20, 0xFF0B0B1A);
            Draw.border(g, 12, y + 11, PW - 24, 20, i == focus ? accent : 0xFF374151);
            g.drawString(font, f[i] + (i == focus && caret ? "_" : ""), 18, y + 17, 0xFFFFFFFF, true);
        }
        g.drawString(font, "Tab - след. поле, Enter - старт, Esc - отмена", 12, 146, 0xFF6B7280, true);
        button(g, mx, my, 12, 160, 140, 22, "Старт", accent);
        button(g, mx, my, PW - 12 - 140, 160, 140, 22, "Отмена", 0xFF6B7280);
        g.pose().popMatrix();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = (float) ((event.x() - ox) / s), my = (float) ((event.y() - oy) / s);
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        for (int i = 0; i < 3; i++) if (in(mx, my, 12, 35 + i * 40, PW - 24, 20)) { focus = i; return true; }
        if (in(mx, my, 12, 160, 140, 22)) { confirm(); return true; }
        if (in(mx, my, PW - 12 - 140, 160, 140, 22)) { onClose(); return true; }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { confirm(); return true; }
        if (key == GLFW.GLFW_KEY_TAB) { focus = (focus + 1) % 3; return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (f[focus].length() > 0) f[focus].setLength(f[focus].length() - 1);
            return true;
        }
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if (cp < 32 || cp == 127) return true;
        if (focus == 0) { if (f[0].length() < 24) f[0].appendCodePoint(cp); }
        else if (cp >= '0' && cp <= '9' && f[focus].length() < 10) f[focus].append((char) cp);
        return true;
    }
}
