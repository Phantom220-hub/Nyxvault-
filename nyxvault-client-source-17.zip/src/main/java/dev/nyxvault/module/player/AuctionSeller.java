package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.gui.AuctionPriceScreen;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;

/**
 * Sells the item type you hold, one piece at a time (and first spreads a big stack into single
 * pieces across the empty hotbar slots by itself), with the server's own auction command
 * ("/ah sell PRICE"). Only stacks of exactly 1 are sold, so a bigger stack is never sold whole.
 * If a sale does not go through (the item is still there after a short wait, e.g. the listing
 * limit is reached) it waits "Retry (sec)" seconds and tries again. One command per cycle, no
 * packets other than normal commands and inventory clicks. Servers may forbid auto-selling.
 */
public final class AuctionSeller extends Module {
    public enum Cmd { AH_SELL, AUCTION_SELL }

    private final NumberSetting price = add(NumberSetting.integer("Price", 9000, 1, 2000000000));
    private final EnumSetting<Cmd> cmd = add(new EnumSetting<>("Command", Cmd.AH_SELL));
    private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 20, 5, 100));
    private final NumberSetting retry = add(NumberSetting.integer("Retry (sec)", 30, 5, 300));
    private final NumberSetting fillDelay = add(NumberSetting.integer("Fill Delay (ticks)", 2, 1, 10));
    private final NumberSetting maxItems = add(NumberSetting.integer("Max Items", 0, 0, 10000));
    private final BoolSetting askPrice = add(new BoolSetting("Ask Price On Start", true));
    private final BoolSetting stopOnDamage = add(new BoolSetting("Stop On Damage", true));
    private final BoolSetting finishSound = add(new BoolSetting("Finish Sound", true));

    /** Read by the Auction Stats HUD. */
    public static volatile boolean active;
    public static volatile int soldCount;
    public static volatile long earned;
    public static volatile int retryLeft; // seconds, 0 when not waiting
    public static volatile String status = "Idle";

    private boolean awaitingPrice;
    private float lastHealth;

    private Item item;
    private final int[] opSlot = new int[64];
    private final int[] opBtn = new int[64];
    private int n, idx2, fillCd;
    private int wait, checkSlot = -1, checkCount, checkWait, sold;

    public AuctionSeller() {
        super("Auction Seller", "Splits the held item into single pieces and sells them one by one via /ah sell. Retries when the listing limit is hit. Check server rules.", Category.PLAYER);
    }

    @Override protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        item = null; n = 0; idx2 = 0; fillCd = 0; wait = 0; checkSlot = -1; sold = 0;
        soldCount = 0; earned = 0; retryLeft = 0; awaitingPrice = false; status = "Idle";
        if (p == null) { setEnabled(false); return; }
        if (p.getMainHandItem().isEmpty()) { Notifications.push("Возьмите предмет в руку"); setEnabled(false); return; }
        item = p.getMainHandItem().getItem();
        lastHealth = p.getHealth();
        if (askPrice.get()) {
            awaitingPrice = true;
            status = "Price";
            mc.setScreen(new AuctionPriceScreen(this, p.getMainHandItem().getHoverName().getString(), price.asInt()));
        } else {
            begin(p);
        }
    }

    private void begin(Player p) {
        active = true;
        status = "Selling";
        Notifications.push("Автопродажа: " + p.getMainHandItem().getHoverName().getString() + " по " + price.asInt());
    }

    /** Called by the price screen. */
    public void confirmPrice(int value) {
        price.set((double) value);
        awaitingPrice = false;
        Player p = Minecraft.getInstance().player;
        if (p == null) { setEnabled(false); return; }
        begin(p);
    }

    /** Called by the price screen when it is cancelled. */
    public void cancelPrice() {
        awaitingPrice = false;
        setEnabled(false);
    }

    private void finish(String why, boolean sound) {
        Notifications.push(why + " Продано: " + sold);
        if (sound && finishSound.get()) {
            Minecraft mc = Minecraft.getInstance();
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f));
        }
        setEnabled(false);
    }

    @Override public void onWorldChange() {
        if (enabled()) finish("Смена мира, автопродажа остановлена.", false);
    }

    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (n > 0 && p != null && mc.gameMode != null && p.containerMenu == p.inventoryMenu
                && !p.containerMenu.getCarried().isEmpty()) { // stopped mid-fill: drop the cursor stack back
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, opSlot[0], 0, ClickType.PICKUP, p);
        }
        n = 0; checkSlot = -1; active = false; retryLeft = 0; awaitingPrice = false;
        if (status.equals("Selling") || status.equals("Waiting") || status.equals("Price")) status = "Idle";
    }

    private void op(int slot, int button) {
        if (n < opSlot.length) { opSlot[n] = slot; opBtn[n] = button; n++; }
    }

    /** Plans: pick up the biggest stack, put 1 into each empty hotbar slot, put the rest back. */
    private boolean planFill(Player p) {
        Inventory inv = p.getInventory();
        int best = -1, cnt = 0;
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).getItem() == item && inv.getItem(i).getCount() > cnt) { best = i; cnt = inv.getItem(i).getCount(); }
        }
        if (best < 0 || cnt < 2) return false;
        int src = best < 9 ? 36 + best : best;
        n = 0; idx2 = 0;
        op(src, 0);
        int remaining = cnt, filled = 0;
        for (int h = 0; h < 9 && remaining > 0; h++) {
            if (h == best || inv.getItem(h).isEmpty()) { op(36 + h, 1); remaining--; filled++; }
        }
        if (filled == 0) { n = 0; return false; }
        if (remaining > 0) op(src, 0);
        return true;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null || mc.getConnection() == null || item == null) return;
        if (awaitingPrice) return;
        if (stopOnDamage.get()) {
            float hp = p.getHealth();
            if (hp < lastHealth - 0.01f) { finish("Получен урон, автопродажа остановлена.", false); return; }
            lastHealth = hp;
        }
        if (mc.screen != null || p.containerMenu != p.inventoryMenu) return;
        if (maxItems.asInt() > 0 && sold >= maxItems.asInt()) { finish("Достигнут лимит.", true); return; }

        if (n > 0) { // spreading a stack into single pieces
            if (p.containerMenu != p.inventoryMenu) { n = 0; return; }
            if (fillCd > 0) { fillCd--; return; }
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, opSlot[idx2], opBtn[idx2], ClickType.PICKUP, p);
            fillCd = fillDelay.asInt() - 1;
            if (++idx2 >= n) { n = 0; wait = 3; }
            return;
        }
        if (checkSlot >= 0) { // waiting to see whether the sale went through
            if (--checkWait > 0) return;
            Inventory inv = p.getInventory();
            boolean still = inv.getItem(checkSlot).getItem() == item && inv.getItem(checkSlot).getCount() == checkCount;
            checkSlot = -1;
            if (still) { wait = retry.asInt() * 20; status = "Waiting"; Notifications.push("Лимит/отказ, повтор через " + retry.asInt() + " с"); }
            else { sold++; soldCount = sold; earned += price.asInt(); wait = delay.asInt(); status = "Selling"; }
            return;
        }
        if (wait > 0) {
            wait--;
            retryLeft = status.equals("Waiting") ? (wait + 19) / 20 : 0;
            return;
        }
        retryLeft = 0;
        status = "Selling";

        Inventory inv = p.getInventory();
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).getItem() == item && inv.getItem(i).getCount() == 1) { idx = i; break; }
        }
        if (idx < 0 && planFill(p)) return; // no single pieces left: make some
        if (idx < 0) { finish("Автопродажа закончена.", true); return; }

        int hot = idx < 9 ? idx : inv.getSelectedSlot();
        if (idx >= 9) { // bring it to the selected hotbar slot with one normal swap click
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, idx, hot, ClickType.SWAP, p);
            wait = 3; // sell on a later tick, after the server confirms the swap
            return;
        }
        if (inv.getSelectedSlot() != hot) { inv.setSelectedSlot(hot); wait = 3; return; }
        mc.getConnection().sendCommand((cmd.get() == Cmd.AH_SELL ? "ah sell " : "auction sell ") + price.asInt());
        checkSlot = hot; checkCount = 1; checkWait = 12;
    }
}
