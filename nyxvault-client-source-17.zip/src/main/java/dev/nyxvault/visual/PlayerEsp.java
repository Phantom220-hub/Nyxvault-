package dev.nyxvault.visual;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Lines;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;

/**
 * Visual-only player ESP (boxes, outline, tracers, labels). It never aims, attacks or selects
 * targets. By default it shows only players you have a line of sight to; the "Through Walls"
 * option draws players behind blocks too and may violate server rules, so it is OFF by default.
 * Invisible players are skipped. Drawn on the HUD layer in first person only (not depth-tested).
 * The "Outline" mode is an approximation built from head/body/legs boxes, not the real model silhouette.
 */
public final class PlayerEsp extends OverlayModule {
    public enum BoxStyle { BOX_2D, BOX_3D, CORNERS, OUTLINE }
    public enum Origin { BOTTOM, CENTER, TOP }
    public enum Target { FEET, BODY, HEAD }

    // modes
    private final BoolSetting boxes = add(new BoolSetting("Boxes", true));
    private final EnumSetting<BoxStyle> boxStyle = add(new EnumSetting<>("Box Style", BoxStyle.CORNERS));
    private final BoolSetting fill = add(new BoolSetting("Fill", false));
    private final NumberSetting fillOpacity = add(NumberSetting.decimal("Fill Opacity", 0.15, 0.02, 0.6, 0.01));
    private final NumberSetting thickness = add(NumberSetting.decimal("Outline Thickness", 1.5, 1.0, 4.0, 0.5));
    private final BoolSetting rounded = add(new BoolSetting("Rounded Corners", false));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", false));
    private final EnumSetting<Origin> origin = add(new EnumSetting<>("Tracer Origin", Origin.BOTTOM));
    private final EnumSetting<Target> target = add(new EnumSetting<>("Tracer Target", Target.FEET));
    private final NumberSetting tracerThickness = add(NumberSetting.decimal("Tracer Thickness", 1.0, 1.0, 4.0, 0.5));
    private final BoolSetting gradient = add(new BoolSetting("Distance Gradient", true));
    private final BoolSetting labels = add(new BoolSetting("Labels", true));
    private final BoolSetting showName = add(new BoolSetting("Show Name", true));
    private final BoolSetting showDistance = add(new BoolSetting("Show Distance", true));
    private final BoolSetting showHealth = add(new BoolSetting("Show Health", true));
    private final NumberSetting textScale = add(NumberSetting.decimal("Text Scale", 0.8, 0.5, 1.5, 0.1));
    private final NumberSetting textOpacity = add(NumberSetting.decimal("Text Opacity", 1.0, 0.2, 1.0, 0.05));
    // look
    private final ColorSetting color = add(new ColorSetting("Near Color", 0xFFEF4444));
    private final ColorSetting farColor = add(new ColorSetting("Far Color", 0xFF22D3EE));
    private final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
    private final NumberSetting maxDistance = add(NumberSetting.integer("Max Distance", 64, 8, 160));
    private final BoolSetting fade = add(new BoolSetting("Fade Distant", true));
    private final BoolSetting throughWalls = add(new BoolSetting("Through Walls", false));

    private final float[] sx = new float[8], sy = new float[8];
    private float minX, minY, maxX, maxY;
    private final Map<Integer, Boolean> los = new HashMap<>();
    private int frame;

    private static final int[][] EDGES = { {0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7} };

    public PlayerEsp() {
        super("Player ESP", "Boxes, outline, tracers and labels for players. Through-walls mode is off by default; check server rules.", Category.VISUALS);
    }

    @Override protected void onDisable() { los.clear(); }
    @Override public void onWorldChange() { los.clear(); }

    private boolean project(double x0, double y0, double z0, double x1, double y1, double z1) {
        minX = Float.MAX_VALUE; minY = Float.MAX_VALUE; maxX = -Float.MAX_VALUE; maxY = -Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? x0 : x1, y = (i & 2) == 0 ? y0 : y1, z = (i & 4) == 0 ? z0 : z1;
            if (!WorldProjector.project(x, y, z)) return false;
            sx[i] = WorldProjector.out[0]; sy[i] = WorldProjector.out[1];
            minX = Math.min(minX, sx[i]); maxX = Math.max(maxX, sx[i]);
            minY = Math.min(minY, sy[i]); maxY = Math.max(maxY, sy[i]);
        }
        return maxX - minX < 4000f && maxY - minY < 4000f;
    }

    private boolean visible(Minecraft mc, Player p) {
        if (throughWalls.get()) return true;
        Boolean v = los.get(p.getId());
        if (v == null || frame % 6 == 0) { v = mc.player.hasLineOfSight(p); los.put(p.getId(), v); }
        return v;
    }

    private void rect(GuiGraphics g, float x0, float y0, float x1, float y1, float w, int c, boolean round) {
        float r = round ? Math.min(5f, Math.min(x1 - x0, y1 - y0) * 0.25f) : 0f;
        Lines.segment(g, x0 + r, y0, x1 - r, y0, w, c);
        Lines.segment(g, x1, y0 + r, x1, y1 - r, w, c);
        Lines.segment(g, x1 - r, y1, x0 + r, y1, w, c);
        Lines.segment(g, x0, y1 - r, x0, y0 + r, w, c);
        if (round && r > 0.5f) {
            Lines.segment(g, x0, y0 + r, x0 + r, y0, w, c);
            Lines.segment(g, x1 - r, y0, x1, y0 + r, w, c);
            Lines.segment(g, x1, y1 - r, x1 - r, y1, w, c);
            Lines.segment(g, x0 + r, y1, x0, y1 - r, w, c);
        }
    }

    private void corners(GuiGraphics g, float x0, float y0, float x1, float y1, float w, int c) {
        float lx = Math.max(3f, (x1 - x0) * 0.28f), ly = Math.max(3f, (y1 - y0) * 0.22f);
        Lines.segment(g, x0, y0, x0 + lx, y0, w, c); Lines.segment(g, x0, y0, x0, y0 + ly, w, c);
        Lines.segment(g, x1, y0, x1 - lx, y0, w, c); Lines.segment(g, x1, y0, x1, y0 + ly, w, c);
        Lines.segment(g, x0, y1, x0 + lx, y1, w, c); Lines.segment(g, x0, y1, x0, y1 - ly, w, c);
        Lines.segment(g, x1, y1, x1 - lx, y1, w, c); Lines.segment(g, x1, y1, x1, y1 - ly, w, c);
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (!WorldProjector.valid || mc.level == null || mc.player == null) return;
        frame++;
        if (los.size() > 128) los.clear();
        float pt = delta.getGameTimeDeltaPartialTick(true);
        double max = maxDistance.asInt();
        float th = thickness.asFloat();
        int sw = WorldProjector.sw, sh = WorldProjector.sh;
        int drawn = 0;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            double dist = mc.player.distanceTo(p);
            if (dist > max || drawn >= 40) continue;
            if (!visible(mc, p)) continue;
            double x = Mth.lerp(pt, p.xo, p.getX()), y = Mth.lerp(pt, p.yo, p.getY()), z = Mth.lerp(pt, p.zo, p.getZ());
            double hw = p.getBbWidth() / 2.0, hh = p.getBbHeight();
            float t = (float) Math.min(1.0, dist / max);
            float a = opacity.asFloat();
            if (fade.get() && t > 0.7f) a *= Math.max(0.15f, 1f - (t - 0.7f) / 0.3f);
            int base = gradient.get() ? Draw.mix(color.get(), farColor.get(), t) : color.get();
            int col = Draw.alpha(base, a);

            boolean have = false;
            if (boxes.get()) {
                switch (boxStyle.get()) {
                    case OUTLINE -> {
                        // head, torso and legs as three boxes (approximation of the body shape)
                        double top = hh, torsoTop = hh * 0.82, legTop = hh * 0.42;
                        double[][] yy = { {torsoTop, top}, {legTop, torsoTop}, {0.0, legTop} };
                        double[] half = { 0.25, 0.3, 0.22 };
                        for (int i = 0; i < 3; i++) {
                            if (!project(x - half[i], y + yy[i][0], z - half[i], x + half[i], y + yy[i][1], z + half[i])) continue;
                            rect(g, minX, minY, maxX, maxY, th, col, rounded.get());
                            have = true;
                        }
                        project(x - hw, y, z - hw, x + hw, y + hh, z + hw); // bounds for labels
                    }
                    default -> {
                        if (!project(x - hw, y, z - hw, x + hw, y + hh, z + hw)) continue;
                        have = true;
                        if (fill.get()) g.fill(Math.round(minX), Math.round(minY), Math.round(maxX), Math.round(maxY), Draw.alpha(base, a * fillOpacity.asFloat()));
                        switch (boxStyle.get()) {
                            case BOX_3D -> {
                                for (int[] e : EDGES) Lines.segment(g, sx[e[0]], sy[e[0]], sx[e[1]], sy[e[1]], th, col);
                            }
                            case CORNERS -> corners(g, minX, minY, maxX, maxY, th, col);
                            default -> rect(g, minX, minY, maxX, maxY, th, col, rounded.get());
                        }
                    }
                }
            } else if (labels.get()) {
                have = project(x - hw, y, z - hw, x + hw, y + hh, z + hw);
            }
            drawn++;

            if (tracers.get()) {
                double ty = switch (target.get()) { case FEET -> y; case BODY -> y + hh * 0.5; case HEAD -> y + hh; };
                if (WorldProjector.project(x, ty, z)) {
                    float ox = sw / 2f, oy = switch (origin.get()) { case BOTTOM -> (float) sh; case CENTER -> sh / 2f; case TOP -> 0f; };
                    Lines.segment(g, ox, oy, WorldProjector.out[0], WorldProjector.out[1], tracerThickness.asFloat(), Draw.alpha(base, a * 0.85f));
                }
            }

            if (labels.get() && have) {
                StringBuilder sb = new StringBuilder();
                if (showName.get()) sb.append(p.getName().getString());
                if (showDistance.get()) { if (sb.length() > 0) sb.append(' '); sb.append(String.format("%.0f м", dist)); }
                if (showHealth.get()) { if (sb.length() > 0) sb.append(' '); sb.append(String.format("%.0f HP", p.getHealth() + p.getAbsorptionAmount())); }
                if (sb.length() > 0) {
                    float s = textScale.asFloat();
                    String text = sb.toString();
                    g.pose().pushMatrix();
                    g.pose().translate((minX + maxX) / 2f, minY - 3f - 9f * s);
                    g.pose().scale(s, s);
                    g.drawString(mc.font, text, -mc.font.width(text) / 2, 0, Draw.alpha(0xFFFFFFFF, a * textOpacity.asFloat()), true);
                    g.pose().popMatrix();
                }
            }
        }
    }
}
