package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.Items;

/**
 * Reels in when the bobber is pulled under (it drops sharply), then optionally casts again.
 * One use-item action per event with a pause in between; needs a fishing rod in the main hand.
 */
public final class AutoFish extends Module {
    private final BoolSetting recast = add(new BoolSetting("Auto Recast", true));
    private final NumberSetting reelDelay = add(NumberSetting.integer("Reel Delay (ticks)", 3, 1, 20));
    private final NumberSetting recastDelay = add(NumberSetting.integer("Recast Delay (ticks)", 20, 10, 100));

    private FishingHook hook;
    private double lastY;
    private int age, wait, pending;
    private boolean needRecast;

    public AutoFish() {
        super("Auto Fish", "Reels in the fish when the bobber dips and can cast again. Needs a fishing rod in hand.", Category.PLAYER);
    }

    @Override protected void onEnable() { hook = null; age = 0; wait = 0; pending = 0; needRecast = false; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (!p.getMainHandItem().is(Items.FISHING_ROD)) { hook = null; return; }
        if (wait > 0) { wait--; return; }

        FishingHook cur = p.fishing;
        if (cur == null) {
            hook = null;
            if (needRecast && recast.get()) {
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                needRecast = false;
                wait = 10;
            }
            return;
        }
        if (cur != hook) { hook = cur; age = 0; lastY = cur.getY(); pending = 0; return; }
        age++;
        double dy = cur.getY() - lastY;
        lastY = cur.getY();
        if (pending > 0) {
            if (--pending == 0) {
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND); // reel in
                needRecast = true;
                wait = recastDelay.asInt();
            }
            return;
        }
        if (age > 30 && dy < -0.12) pending = reelDelay.asInt();
    }
}
