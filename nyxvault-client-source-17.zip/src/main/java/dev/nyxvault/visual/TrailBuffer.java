package dev.nyxvault.visual;

/** Fixed-size ring buffer of timestamped samples with two world points each. No allocation after construction. */
public final class TrailBuffer {
    private final double[] xs, ys, zs, xs2, ys2, zs2;
    private final long[] ts;
    private final int cap;
    private int start, size;

    public TrailBuffer(int capacity) {
        this.cap = capacity;
        xs = new double[capacity]; ys = new double[capacity]; zs = new double[capacity];
        xs2 = new double[capacity]; ys2 = new double[capacity]; zs2 = new double[capacity];
        ts = new long[capacity];
    }

    public int size() { return size; }

    private int idx(int i) { return (start + i) % cap; }

    public void add(double x, double y, double z, double x2, double y2, double z2, long t) {
        if (size == cap) { start = (start + 1) % cap; size--; }
        int k = idx(size);
        xs[k] = x; ys[k] = y; zs[k] = z;
        xs2[k] = x2; ys2[k] = y2; zs2[k] = z2;
        ts[k] = t;
        size++;
    }

    /** Index 0 is the oldest sample, size()-1 the newest. */
    public double x(int i) { return xs[idx(i)]; }
    public double y(int i) { return ys[idx(i)]; }
    public double z(int i) { return zs[idx(i)]; }
    public double x2(int i) { return xs2[idx(i)]; }
    public double y2(int i) { return ys2[idx(i)]; }
    public double z2(int i) { return zs2[idx(i)]; }
    public long time(int i) { return ts[idx(i)]; }

    /** Drops samples older than {@code maxAgeMs}. */
    public void prune(long now, long maxAgeMs) {
        while (size > 0 && now - ts[start] > maxAgeMs) {
            start = (start + 1) % cap;
            size--;
        }
    }

    public void clear() { start = 0; size = 0; }
}
