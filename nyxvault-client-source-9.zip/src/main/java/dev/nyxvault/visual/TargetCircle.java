package dev.nyxvault.visual;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Rings;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Animated ring on the ground under your current target (see {@link TargetFocus}).
 * Drawn as a projected polyline (no particles). It is only drawn while you have a line of sight
 * to the target. The ring itself is not depth-tested, so parts of it can show through terrain
 * edges, and it is placed at the target's feet height (it does not follow uneven terrain).
 */
public final class TargetCircle extends OverlayModule {
    public enum Style { CLEAN, DOUBLE, SEGMENTS, PULSE, GRADIENT }

    private final EnumSetting<Style> style = add(new EnumSetting<>("Style", Style.CLEAN));
    private final ColorSetting primary = add(new ColorSetting("Primary Color", 0xFF22D3EE));
    private final ColorSetting secondary = add(new ColorSetting("Secondary Color", 0xFF3B82F6));
    private final NumberSetting radius = add(NumberSetting.decimal("Radius", 0.9, 0.4, 3.0, 0.1));
    private final NumberSetting thickness = add(NumberSetting.decimal("Thickness", 2.0, 1.0, 5.0, 0.5));
    private final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
    private final NumberSetting rotation = add(NumberSetting.integer("Rotation Speed", 90, 0, 360));
    private final NumberSetting animSpeed = add(NumberSetting.decimal("Animation Speed", 1.0, 0.25, 3.0, 0.25));
    private final NumberSetting fade = add(NumberSetting.integer("Fade Duration (ms)", 300, 100, 1500));
    private final BoolSetting glow = add(new BoolSetting("Glow", true));
    private final BoolSetting performance = add(new BoolSetting("Performance Mode", false));

    public TargetCircle() {
        super("Target Circle", "Animated ring under the enemy you are fighting (needs line of sight, first person).", Category.COMBAT);
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        float a = TargetFocus.alpha(fade.asInt());
        if (a <= 0.01f || !WorldProjector.valid) return;
        float op = a * opacity.asFloat();
        float anim = animSpeed.asFloat();
        double time = (System.currentTimeMillis() % 3600000L) / 1000.0;
        float rot = (float) Math.toRadians((time * rotation.asInt() * anim) % 360.0);
        float r = radius.asFloat();
        float th = thickness.asFloat();
        int n = Rings.quality(performance.get());
        double cx = TargetFocus.x, cy = TargetFocus.y + 0.02, cz = TargetFocus.z;
        int c1 = Draw.alpha(primary.get(), op);
        int c2 = Draw.alpha(secondary.get(), op);

        if (glow.get() && !performance.get()) Rings.glow(g, cx, cy, cz, r, rot, th, c1, n);
        switch (style.get()) {
            case DOUBLE -> {
                Rings.ring(g, cx, cy, cz, r, rot, th, c1, 0, false, false, n, 0);
                Rings.ring(g, cx, cy, cz, r * 0.72f, -rot * 1.3f, Math.max(1f, th * 0.7f), c2, 0, false, false, n, 0);
            }
            case SEGMENTS -> Rings.ring(g, cx, cy, cz, r, rot, th, c1, 0, false, true, n, 0);
            case PULSE -> {
                float pulse = (float) Math.sin(time * anim * 4.0);
                float rr = r * (1f + 0.15f * pulse);
                int pc = Draw.alpha(primary.get(), op * (0.75f + 0.25f * (float) Math.cos(time * anim * 4.0)));
                Rings.ring(g, cx, cy, cz, rr, rot, th, pc, 0, false, false, n, 0);
            }
            case GRADIENT -> Rings.ring(g, cx, cy, cz, r, rot, th, c1, c2, true, false, n, (int) (time * anim * 16.0));
            default -> Rings.ring(g, cx, cy, cz, r, rot, th, c1, 0, false, false, n, 0);
        }
    }
}
