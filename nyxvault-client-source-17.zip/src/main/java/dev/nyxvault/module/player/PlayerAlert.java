package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Lang;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Warns once when a new player comes within the radius. Only reads players your client already
 * has loaded (it cannot see further than the server sends), so it is not a radar.
 */
public final class PlayerAlert extends Module {
    private final NumberSetting radius = add(NumberSetting.integer("Radius", 64, 8, 256));
    private final BoolSetting sound = add(new BoolSetting("Sound", true));
    private final BoolSetting showDistance = add(new BoolSetting("Show Distance", true));

    private final Set<UUID> inside = new HashSet<>();
    private final Set<UUID> now = new HashSet<>();

    public PlayerAlert() {
        super("Player Alert", "Warns once when a new player comes within the radius (only players loaded on your client).", Category.PLAYER);
    }

    @Override protected void onEnable() { inside.clear(); }
    @Override protected void onDisable() { inside.clear(); }
    @Override public void onWorldChange() { inside.clear(); }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        double r2 = (double) radius.asInt() * radius.asInt();
        now.clear();
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            double d2 = mc.player.distanceToSqr(p);
            if (d2 > r2) continue;
            now.add(p.getUUID());
            if (inside.add(p.getUUID())) {
                String t = Lang.t("Player nearby: ") + p.getName().getString();
                if (showDistance.get()) t += String.format(" (%.0f %s)", Math.sqrt(d2), Lang.t("m"));
                Notifications.push(t, 1);
                if (sound.get()) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f));
            }
        }
        inside.retainAll(now); // players that left can trigger again when they return
    }
}
