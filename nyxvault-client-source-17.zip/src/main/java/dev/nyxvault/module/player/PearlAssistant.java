package dev.nyxvault.module.player;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Manual ender pearl helper: shows how many pearls you have, in which hotbar slot, and the vanilla
 * item cooldown. It never throws a pearl, never aims and never touches cooldowns. The optional key
 * only SELECTS the hotbar slot; you throw it yourself.
 */
public final class PearlAssistant extends HudModule {
    private final BoolSetting showSlot = add(new BoolSetting("Show Slot", true));
    private final BoolSetting showCooldown = add(new BoolSetting("Show Cooldown", true));
    private final BoolSetting reminder = add(new BoolSetting("Ready Reminder", false));
    private final BoolSetting reminderSound = add(new BoolSetting("Ready Sound", false));
    private final NumberSetting preferredSlot = add(NumberSetting.integer("Preferred Slot (0 = auto)", 0, 0, 9));
    private final BoolSetting compact = add(new BoolSetting("Compact Layout", false));

    private final ItemStack icon = new ItemStack(Items.ENDER_PEARL);
    private int count, slot = -1;
    private boolean cooling, wasCooling;

    public PearlAssistant() {
        super("Pearl Assistant", "Pearl count, hotbar slot and cooldown. Never throws or aims; the key only selects the slot.", Category.PLAYER, 130, 84);
    }

    @Override protected void onEnable() { wasCooling = false; }

    private void refresh(Minecraft mc) {
        Player p = mc.player;
        count = 0; slot = -1;
        if (p == null) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() == Items.ENDER_PEARL) {
                count += s.getCount();
                if (i < 9 && slot < 0) slot = i;
            }
        }
        ItemStack off = p.getOffhandItem();
        if (off.getItem() == Items.ENDER_PEARL) count += off.getCount();
        int pref = preferredSlot.asInt();
        if (pref > 0 && inv.getItem(pref - 1).getItem() == Items.ENDER_PEARL) slot = pref - 1;
        cooling = p.getCooldowns().isOnCooldown(icon);
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        refresh(mc);
        if (wasCooling && !cooling && count > 0 && reminder.get()) {
            Notifications.push("Жемчуг снова готов");
            if (reminderSound.get() && mc.player != null) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f));
        }
        wasCooling = cooling;
    }

    /** Selects the hotbar slot that holds pearls (called by the optional key). Does nothing else. */
    public void selectPearlSlot(Minecraft mc) {
        Player p = mc.player;
        if (p == null || mc.screen != null) return;
        refresh(mc);
        if (slot >= 0) p.getInventory().setSelectedSlot(slot);
        else Notifications.push("Жемчуга нет на панели быстрого доступа");
    }

    @Override public int width(Minecraft mc) { return compact.get() ? 44 : 112; }
    @Override public int height(Minecraft mc) { return compact.get() ? 18 : 22; }

    @Override protected void draw(GuiGraphics g, Minecraft mc) {
        int w = width(mc), h = height(mc);
        int edge = cooling ? 0xFFEAB308 : (count > 0 ? 0xFF22C55E : 0xFFEF4444);
        Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
        Draw.border(g, 0, 0, w, h, a(edge));
        g.renderItem(icon, 2, (h - 16) / 2);
        g.drawString(mc.font, "x" + count, 22, (h - 8) / 2, a(0xFFFFFFFF), true);
        if (compact.get()) return;
        StringBuilder sb = new StringBuilder();
        if (showSlot.get()) sb.append(slot >= 0 ? "слот " + (slot + 1) : "нет на панели");
        if (showCooldown.get()) { if (sb.length() > 0) sb.append("  "); sb.append(cooling ? "перезарядка" : "готов"); }
        g.drawString(mc.font, mc.font.plainSubstrByWidth(sb.toString(), w - 46), 44, (h - 8) / 2, a(0xFF9CA3AF), true);
    }
}
