package dev.nyxvault.module.combat;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Lines;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Short geometric effect when the client confirms a hit (the target started its hurt animation
 * right after your attack, see {@link CombatState}). Not a particle effect and it never touches
 * attacks, reach or damage. The effect is placed on the hit target in first person and at the
 * crosshair otherwise. Detection is a client-side heuristic; a swing that only looks like a hit
 * (for example during lag) can be missed or mistaken.
 */
public final class HitEffects extends OverlayModule {
    public enum Style {
        CYAN_FLASH(0xFF22D3EE), PURPLE_RING(0xFFA855F7), PINK_STREAK(0xFFEC4899),
        WHITE_FLASH(0xFFFFFFFF), CROSS(0xFFFFFFFF), BURST(0xFF3B82F6);
        final int color;
        Style(int c) { color = c; }
    }

    private final EnumSetting<Style> style = add(new EnumSetting<>("Style", Style.PURPLE_RING));
    private final BoolSetting custom = add(new BoolSetting("Custom Color", false));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFFA855F7));
    private final NumberSetting duration = add(NumberSetting.integer("Duration (ms)", 400, 150, 1500));
    private final NumberSetting size = add(NumberSetting.integer("Size", 14, 6, 40));
    private final NumberSetting intensity = add(NumberSetting.decimal("Intensity", 1.0, 0.3, 1.5, 0.1));
    private final NumberSetting fadeStart = add(NumberSetting.integer("Fade Start (%)", 30, 0, 90));
    private final BoolSetting follow = add(new BoolSetting("Follow Target", true));
    private final BoolSetting reduced = add(new BoolSetting("Reduced Effects", false));

    public HitEffects() {
        super("Hit Effects", "Short geometric flash on a confirmed hit (client-side detection).", Category.COMBAT);
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        long hit = CombatState.confirmedHitMs();
        if (hit == 0L) return;
        long age = System.currentTimeMillis() - hit;
        int dur = duration.asInt();
        if (age >= dur) return;
        float p = age / (float) dur;
        float fs = fadeStart.asInt() / 100f;
        float alpha = p < fs ? 1f : 1f - (p - fs) / (1f - fs);
        alpha = Math.max(0f, Math.min(1f, alpha * intensity.asFloat()));
        if (alpha <= 0.01f) return;
        boolean low = reduced.get() || UiSettings.reducedEffects;

        float cx = mc.getWindow().getGuiScaledWidth() / 2f, cy = mc.getWindow().getGuiScaledHeight() / 2f;
        if (follow.get() && WorldProjector.valid && WorldProjector.project(CombatState.hitX, CombatState.hitY, CombatState.hitZ)
                && WorldProjector.onScreen(0f)) {
            cx = WorldProjector.out[0]; cy = WorldProjector.out[1];
        }
        float e = 1f - (1f - p) * (1f - p);           // ease-out expansion
        float s = size.asInt() * (low ? 0.6f : 1f);
        int base = custom.get() ? color.get() : style.get().color;
        int col = Draw.alpha(base, alpha);
        int soft = Draw.alpha(base, alpha * 0.45f);
        int ic = Math.round(cx), jc = Math.round(cy);

        switch (style.get()) {
            case CYAN_FLASH -> {
                float r = s * (0.6f + 0.8f * e);
                diamond(g, cx, cy, r, 2f, col);
                Lines.disc(g, ic, jc, Math.max(1, Math.round(s * 0.35f * (1f - p))), soft);
            }
            case PURPLE_RING -> {
                Lines.circle(g, cx, cy, s * (0.3f + 1.2f * e), 2f, col, 32);
                if (!low) Lines.circle(g, cx, cy, s * (0.2f + 0.7f * e), 1f, soft, 16);
            }
            case PINK_STREAK -> {
                for (int k = 0; k < 4; k++) {
                    int a = 8 + k * 16; // 45, 135, 225, 315 degrees in the 64-entry table
                    float r0 = s * 0.3f + e * s * 0.8f, r1 = r0 + s * 0.6f * (1f - p * 0.5f);
                    Lines.segment(g, cx + Lines.COS[a] * r0, cy + Lines.SIN[a] * r0,
                            cx + Lines.COS[a] * r1, cy + Lines.SIN[a] * r1, 2f, col);
                }
            }
            case WHITE_FLASH -> {
                Lines.disc(g, ic, jc, Math.max(1, Math.round(s * (0.4f + 0.5f * e))), soft);
                Lines.disc(g, ic, jc, Math.max(1, Math.round(s * 0.25f * (1f - p))), col);
            }
            case CROSS -> {
                float gap = s * 0.3f + e * s * 0.3f, len = s * 0.7f;
                Lines.segment(g, cx - gap - len, cy, cx - gap, cy, 2f, col);
                Lines.segment(g, cx + gap, cy, cx + gap + len, cy, 2f, col);
                Lines.segment(g, cx, cy - gap - len, cx, cy - gap, 2f, col);
                Lines.segment(g, cx, cy + gap, cx, cy + gap + len, 2f, col);
            }
            case BURST -> {
                int rays = low ? 4 : 8;
                for (int k = 0; k < rays; k++) {
                    int a = k * (64 / rays);
                    float r0 = s * 0.35f + e * s * 0.7f;
                    float r1 = r0 + ((k & 1) == 0 ? s * 0.7f : s * 0.4f) * (1f - p * 0.6f);
                    Lines.segment(g, cx + Lines.COS[a] * r0, cy + Lines.SIN[a] * r0,
                            cx + Lines.COS[a] * r1, cy + Lines.SIN[a] * r1, 2f, col);
                }
            }
        }
    }

    private static void diamond(GuiGraphics g, float cx, float cy, float r, float w, int col) {
        Lines.segment(g, cx, cy - r, cx + r, cy, w, col);
        Lines.segment(g, cx + r, cy, cx, cy + r, w, col);
        Lines.segment(g, cx, cy + r, cx - r, cy, w, col);
        Lines.segment(g, cx - r, cy, cx, cy - r, w, col);
    }
}
