package dev.nyxvault.visual;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Rings;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

/**
 * Expanding ring at your feet when you jump, and (optionally) when you land from a fall.
 * Only READS onGround / motion / fall distance; it never changes movement or physics.
 * At most 4 rings exist at once. Drawn in first person only (see {@link WorldProjector}).
 */
public final class JumpCircle extends OverlayModule {
    private static final int MAX = 4;
    private static final double MIN_FALL = 2.0;

    private final ColorSetting color = add(new ColorSetting("Color", 0xFF22D3EE));
    private final ColorSetting color2 = add(new ColorSetting("Secondary Color", 0xFFA855F7));
    private final NumberSetting radius = add(NumberSetting.decimal("Radius", 0.3, 0.1, 3.0, 0.1));
    private final NumberSetting maxRadius = add(NumberSetting.decimal("Max Radius", 1.6, 0.5, 8.0, 0.1));
    private final NumberSetting thickness = add(NumberSetting.decimal("Thickness", 2.0, 1.0, 5.0, 0.5));
    private final NumberSetting lifetime = add(NumberSetting.integer("Lifetime (ms)", 600, 200, 2000));
    private final NumberSetting expansion = add(NumberSetting.decimal("Expansion Speed", 1.5, 0.5, 4.0, 0.25));
    private final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
    private final BoolSetting landing = add(new BoolSetting("Landing Ring", true));
    private final ColorSetting landingColor = add(new ColorSetting("Landing Color", 0xFFEC4899));
    private final BoolSetting glow = add(new BoolSetting("Glow", true));
    private final BoolSetting performance = add(new BoolSetting("Performance Mode", false));

    private final double[] rx = new double[MAX], ry = new double[MAX], rz = new double[MAX];
    private final long[] rt = new long[MAX];       // 0 = empty slot
    private final boolean[] rl = new boolean[MAX]; // landing ring?
    private boolean wasGround = true;
    private double maxFall;

    private final RingFx fx;

    public JumpCircle() {
        super("Jump Circle", "Expanding ring at your feet on jump and landing. Visual only.", Category.VISUALS);
        fx = new RingFx(this, RingFx.HEIGHT | RingFx.INNER | RingFx.HORIZONTAL);
    }

    private void clear() {
        java.util.Arrays.fill(rt, 0L);
        wasGround = true;
        maxFall = 0;
    }

    @Override protected void onEnable() { clear(); }
    @Override protected void onDisable() { clear(); }
    @Override public void onWorldChange() { clear(); }

    private void spawn(Player p, boolean land) {
        int slot = 0;
        long oldest = Long.MAX_VALUE;
        for (int i = 0; i < MAX; i++) {
            if (rt[i] == 0L) { slot = i; break; }
            if (rt[i] < oldest) { oldest = rt[i]; slot = i; }
        }
        rx[slot] = p.getX(); ry[slot] = p.getY() + 0.02; rz[slot] = p.getZ();
        rt[slot] = System.currentTimeMillis();
        rl[slot] = land;
    }

    @Override public void onTick() {
        Player p = Minecraft.getInstance().player;
        if (p == null || !p.isAlive()) { clear(); return; }
        boolean ground = p.onGround();
        if (!ground) maxFall = Math.max(maxFall, p.fallDistance);
        if (wasGround && !ground && p.getDeltaMovement().y > 0.1) {
            spawn(p, false);
        } else if (!wasGround && ground) {
            if (landing.get() && maxFall >= MIN_FALL) spawn(p, true);
            maxFall = 0;
        }
        wasGround = ground;
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (!WorldProjector.valid) return;
        long now = System.currentTimeMillis();
        long life = lifetime.asInt();
        int n = fx.segments(performance.get());
        float exp = expansion.asFloat() * Math.max(0.2f, fx.anim());
        for (int i = 0; i < MAX; i++) {
            if (rt[i] == 0L) continue;
            float age = (now - rt[i]) / (float) life;
            if (age >= 1f) { rt[i] = 0L; continue; }
            float ease = 1f - (float) Math.pow(1f - age, exp);
            float r = fx.radius(radius.asFloat() + (maxRadius.asFloat() - radius.asFloat()) * ease);
            float a = (1f - age) * opacity.asFloat() * fx.ringOpacity();
            int c = fx.tint(rl[i] ? landingColor.get() : color.get());
            double yy = ry[i] + fx.heightOffset();
            if (glow.get() && !performance.get()) Rings.glow(g, rx[i], yy, rz[i], r, 0f, thickness.asFloat(), Draw.alpha(c, a), n, fx.glow());
            Rings.ring(g, rx[i], yy, rz[i], r, 0f, thickness.asFloat(), Draw.alpha(c, a), 0, false, false, n, 0);
            if (!performance.get()) {
                Rings.ring(g, rx[i], yy, rz[i], r * fx.innerRatio(), 0f, Math.max(1f, thickness.asFloat() * 0.6f),
                        Draw.alpha(fx.tint(color2.get(), 0.33f), a * 0.7f), 0, false, false, n, 0);
            }
        }
    }
}
