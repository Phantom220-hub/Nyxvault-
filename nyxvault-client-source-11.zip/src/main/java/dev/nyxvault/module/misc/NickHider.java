package dev.nyxvault.module.misc;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.EnumSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.util.Optional;

/**
 * Shows another name instead of yours, ONLY ON YOUR OWN SCREEN: in server messages you receive and
 * in the NYXVAULT menu. The server and other players still see your real name and skin; nothing is
 * sent to the server. Limit: it rewrites "game" messages (most server and plugin chat). Messages
 * that arrive as vanilla signed player chat are not rewritten.
 */
public final class NickHider extends Module {
    public enum Fake {
        ANONYMOUS("Аноним"), PLAYER("Player"), STEVE("Steve"), ALEX("Alex"), NYXVAULT("NYXVAULT");
        final String text;
        Fake(String t) { text = t; }
    }

    private static NickHider instance;
    private final EnumSetting<Fake> fake = add(new EnumSetting<>("Fake Name", Fake.ANONYMOUS));

    public NickHider() {
        super("Nick Hider", "Shows another name instead of yours, only on your screen. Others still see your real name.", Category.MISC);
        instance = this;
        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> rewrite(message));
    }

    /** Name to show for {@code real} (your own name) in NYXVAULT screens; other names pass through. */
    public static String map(String real) {
        NickHider n = instance;
        if (n == null || !n.enabled()) return real;
        String own = Minecraft.getInstance().getUser().getName();
        return real != null && real.equals(own) ? n.fake.get().text : real;
    }

    private static Component rewrite(Component message) {
        NickHider n = instance;
        if (n == null || !n.enabled()) return message;
        String own = Minecraft.getInstance().getUser().getName();
        if (own == null || own.isEmpty() || !message.getString().contains(own)) return message;
        String repl = n.fake.get().text;
        MutableComponent out = Component.empty();
        message.visit((style, text) -> {
            out.append(Component.literal(text.replace(own, repl)).setStyle(style));
            return Optional.empty();
        }, Style.EMPTY);
        return out;
    }
}
