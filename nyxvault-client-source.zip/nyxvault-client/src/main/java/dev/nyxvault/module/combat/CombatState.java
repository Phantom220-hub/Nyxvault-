package dev.nyxvault.module.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tracks the local player's last attack target and whether the hit was confirmed by the client
 * (target started its hurt animation within a few ticks of our attack). It is a client-side
 * heuristic: the server decides actual damage.
 */
public final class CombatState {
    private static LivingEntity pending;
    private static int pendingAge;
    private static LivingEntity lastTarget;
    private static long lastTargetMs;
    private static long confirmedHitMs;

    private CombatState() { }

    public static void onAttack(LivingEntity target) {
        pending = target;
        pendingAge = 0;
        lastTarget = target;
        lastTargetMs = System.currentTimeMillis();
    }

    public static void tick(Minecraft mc) {
        if (pending == null) return;
        if (!pending.isAlive() && pending.getHealth() <= 0) confirmedHitMs = System.currentTimeMillis();
        if (pending.hurtTime > 0) {
            confirmedHitMs = System.currentTimeMillis();
            pending = null;
        } else if (++pendingAge > 3) {
            pending = null; // swing without a visible hit
        }
    }

    public static LivingEntity target(long maxAgeMs) {
        if (lastTarget == null || !lastTarget.isAlive()) return null;
        return System.currentTimeMillis() - lastTargetMs <= maxAgeMs ? lastTarget : null;
    }

    public static long confirmedHitMs() { return confirmedHitMs; }
}
