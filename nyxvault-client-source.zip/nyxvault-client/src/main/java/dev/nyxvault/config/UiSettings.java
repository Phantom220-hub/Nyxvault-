package dev.nyxvault.config;

import dev.nyxvault.render.Theme;

/** Global GUI/appearance settings (persisted by {@link ConfigManager}). */
public final class UiSettings {
    public static Theme theme = Theme.NYXVAULT_SIGNATURE;
    /** Custom accent override (ARGB) or 0 for the theme accent. */
    public static int customAccent = 0;
    public static boolean guiSounds = true;
    public static float soundVolume = 0.5f;
    public static boolean reducedEffects = false;
    public static boolean glow = true;
    /** 0 = animations off, 1 = normal, 2 = strong. */
    public static float animationIntensity = 1.0f;
    /** Extra GUI scale factor for the click GUI (accessibility / small screens). */
    public static float guiScale = 1.0f;
    public static int openKeyDefault = org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT;

    private UiSettings() { }

    public static int accent() { return customAccent != 0 ? customAccent : theme.accent; }
    public static int secondary() { return theme.secondary; }

    public static void reset() {
        theme = Theme.NYXVAULT_SIGNATURE;
        customAccent = 0;
        guiSounds = true;
        soundVolume = 0.5f;
        reducedEffects = false;
        glow = true;
        animationIntensity = 1.0f;
        guiScale = 1.0f;
    }
}
