package dev.nyxvault.module.combat;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.InventoryUtil;
import dev.nyxvault.util.Lang;
import dev.nyxvault.util.Notifications;
import dev.nyxvault.util.SessionStats;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public final class TotemModules {
    private TotemModules() { }

    /**
     * Shared totem bookkeeping, updated every tick.
     * Pop detection is a client-side heuristic: a totem disappeared from the inventory while the
     * player was taking damage and no screen was open. It only detects YOUR OWN pops.
     */
    public static final class Tracker {
        private static int count;
        private static int prev = -1;
        private static long lastPopMs;

        private Tracker() { }

        public static void tick(Minecraft mc) {
            Player p = mc.player;
            if (p == null) { prev = -1; count = 0; return; }
            count = InventoryUtil.count(p, Items.TOTEM_OF_UNDYING);
            if (prev >= 0 && count < prev && mc.screen == null && p.isAlive()
                    && (p.hurtTime > 0 || p.getHealth() <= 4.0f)) {
                SessionStats.pops += prev - count;
                lastPopMs = System.currentTimeMillis();
            }
            prev = count;
        }

        /** Total totems in inventory including the offhand. */
        public static int count() { return count; }
        public static boolean offhandHasTotem() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player != null && mc.player.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING;
        }
        public static long lastPopMs() { return lastPopMs; }
    }

    /**
     * Simple Auto Totem: when enabled, no screen is open and the offhand does not hold a totem,
     * swap one from the main inventory/hotbar into the offhand using ONE normal inventory click
     * (button 40 = swap with offhand). No loops, no packets of its own.
     * Safety: it does nothing while any screen is open or a container is open, waits a configurable
     * delay between clicks, and pauses for 5 s after 3 attempts within 3 s that did not put a totem
     * into the offhand (so a laggy or restricting server is never spammed).
     * Note: this swaps whatever is in the offhand (for example a shield) out of it. Servers and
     * anti-cheats may restrict automated inventory actions; use it only where allowed.
     */
    public static final class AutoTotem extends Module {
        private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 4, 1, 20));
        private final BoolSetting notify = add(new BoolSetting("Notification", true));

        private int cooldown;
        private int attempts;
        private long attemptsStartMs;
        private long pausedUntilMs;
        private boolean wasEmpty;
        private boolean warnedNone;

        public AutoTotem() {
            super("Auto Totem", "Moves a totem into the offhand when it is empty. Check server rules first.", Category.COMBAT);
        }

        private void reset() {
            cooldown = 0; attempts = 0; attemptsStartMs = 0; pausedUntilMs = 0; wasEmpty = false; warnedNone = false;
        }

        @Override protected void onEnable() { reset(); }
        @Override protected void onDisable() { reset(); }
        @Override public void onWorldChange() { reset(); }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null || mc.gameMode == null || !p.isAlive()) return;
            if (mc.screen != null || p.containerMenu != p.inventoryMenu) return; // never act while a screen/container is open

            boolean has = p.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING;
            if (has) {
                if (wasEmpty && notify.get()) Notifications.push(Lang.t("Auto Totem: totem equipped"));
                wasEmpty = false; attempts = 0; warnedNone = false;
                return;
            }
            wasEmpty = true;
            if (cooldown > 0) { cooldown--; return; }
            long now = System.currentTimeMillis();
            if (now < pausedUntilMs) return;

            Inventory inv = p.getInventory();
            int found = -1;
            for (int i = 0; i < 36; i++) { // main inventory + hotbar only
                if (inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) { found = i; break; }
            }
            if (found < 0) {
                if (!warnedNone && notify.get()) { Notifications.push(Lang.t("Auto Totem: no totems left")); }
                warnedNone = true;
                return;
            }

            if (attempts == 0 || now - attemptsStartMs > 3000) { attempts = 0; attemptsStartMs = now; }
            if (++attempts > 3) {
                pausedUntilMs = now + 5000;
                attempts = 0;
                if (notify.get()) Notifications.push(Lang.t("Auto Totem: paused (too many attempts)"));
                return;
            }
            // InventoryMenu slot ids: 9-35 main inventory, 36-44 hotbar.
            int slot = found < 9 ? 36 + found : found;
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
            cooldown = delay.asInt();
        }
    }
}
