package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;

/**
 * Sells the item type you hold, one piece at a time (and first spreads a big stack into single
 * pieces across the empty hotbar slots by itself), with the server's own auction command
 * ("/ah sell PRICE"). Only stacks of exactly 1 are sold, so a bigger stack is never sold whole.
 * If a sale does not go through (the item is still there after a short wait, e.g. the listing
 * limit is reached) it waits "Retry (sec)" seconds and tries again. One command per cycle, no
 * packets other than normal commands and inventory clicks. Servers may forbid auto-selling.
 */
public final class AuctionSeller extends Module {
    public enum Cmd { AH_SELL, AUCTION_SELL }

    private final NumberSetting price = add(NumberSetting.integer("Price", 9000, 1, 2000000000));
    private final EnumSetting<Cmd> cmd = add(new EnumSetting<>("Command", Cmd.AH_SELL));
    private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 20, 5, 100));
    private final NumberSetting retry = add(NumberSetting.integer("Retry (sec)", 30, 5, 300));

    private Item item;
    private final int[] opSlot = new int[64];
    private final int[] opBtn = new int[64];
    private int n, idx2, fillCd;
    private int wait, checkSlot = -1, checkCount, checkWait, sold;

    public AuctionSeller() {
        super("Auction Seller", "Splits the held item into single pieces and sells them one by one via /ah sell. Retries when the listing limit is hit. Check server rules.", Category.PLAYER);
    }

    @Override protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        item = null; n = 0; idx2 = 0; fillCd = 0; wait = 0; checkSlot = -1; sold = 0;
        if (p == null) { setEnabled(false); return; }
        if (p.getMainHandItem().isEmpty()) { Notifications.push("Возьмите предмет в руку"); setEnabled(false); return; }
        item = p.getMainHandItem().getItem();
        Notifications.push("Автопродажа: " + p.getMainHandItem().getHoverName().getString() + " по " + price.asInt());
    }

    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (n > 0 && p != null && mc.gameMode != null && p.containerMenu == p.inventoryMenu
                && !p.containerMenu.getCarried().isEmpty()) { // stopped mid-fill: drop the cursor stack back
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, opSlot[0], 0, ClickType.PICKUP, p);
        }
        n = 0; checkSlot = -1;
    }

    private void op(int slot, int button) {
        if (n < opSlot.length) { opSlot[n] = slot; opBtn[n] = button; n++; }
    }

    /** Plans: pick up the biggest stack, put 1 into each empty hotbar slot, put the rest back. */
    private boolean planFill(Player p) {
        Inventory inv = p.getInventory();
        int best = -1, cnt = 0;
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).getItem() == item && inv.getItem(i).getCount() > cnt) { best = i; cnt = inv.getItem(i).getCount(); }
        }
        if (best < 0 || cnt < 2) return false;
        int src = best < 9 ? 36 + best : best;
        n = 0; idx2 = 0;
        op(src, 0);
        int remaining = cnt, filled = 0;
        for (int h = 0; h < 9 && remaining > 0; h++) {
            if (h == best || inv.getItem(h).isEmpty()) { op(36 + h, 1); remaining--; filled++; }
        }
        if (filled == 0) { n = 0; return false; }
        if (remaining > 0) op(src, 0);
        return true;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null || p.connection == null || item == null) return;
        if (mc.screen != null || p.containerMenu != p.inventoryMenu) return;

        if (n > 0) { // spreading a stack into single pieces
            if (p.containerMenu != p.inventoryMenu) { n = 0; return; }
            if (fillCd > 0) { fillCd--; return; }
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, opSlot[idx2], opBtn[idx2], ClickType.PICKUP, p);
            fillCd = 1;
            if (++idx2 >= n) { n = 0; wait = 3; }
            return;
        }
        if (checkSlot >= 0) { // waiting to see whether the sale went through
            if (--checkWait > 0) return;
            Inventory inv = p.getInventory();
            boolean still = inv.getItem(checkSlot).getItem() == item && inv.getItem(checkSlot).getCount() == checkCount;
            checkSlot = -1;
            if (still) { wait = retry.asInt() * 20; Notifications.push("Лимит/отказ, повтор через " + retry.asInt() + " с"); }
            else { sold++; wait = delay.asInt(); }
            return;
        }
        if (wait > 0) { wait--; return; }

        Inventory inv = p.getInventory();
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).getItem() == item && inv.getItem(i).getCount() == 1) { idx = i; break; }
        }
        if (idx < 0 && planFill(p)) return; // no single pieces left: make some
        if (idx < 0) { Notifications.push("Автопродажа закончена, продано: " + sold); setEnabled(false); return; }

        int hot = idx < 9 ? idx : inv.getSelectedSlot();
        if (idx >= 9) { // bring it to the selected hotbar slot with one normal swap click
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, idx, hot, ClickType.SWAP, p);
            wait = 3; // sell on a later tick, after the server confirms the swap
            return;
        }
        if (inv.getSelectedSlot() != hot) { inv.setSelectedSlot(hot); wait = 3; return; }
        p.connection.sendCommand((cmd.get() == Cmd.AH_SELL ? "ah sell " : "auction sell ") + price.asInt());
        checkSlot = hot; checkCount = 1; checkWait = 12;
    }
}
