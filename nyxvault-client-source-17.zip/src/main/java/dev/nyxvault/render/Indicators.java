package dev.nyxvault.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Small reusable screen-space indicators. */
public final class Indicators {
    private Indicators() { }

    /** Arrow on the screen edge pointing toward a world offset (dx, dz) relative to the player's view. */
    public static void edge(GuiGraphics g, Minecraft mc, double dx, double dz, int color, int size) {
        if (mc.player == null) return;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        float deg = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float rel = (float) Math.toRadians(Mth.wrapDegrees(deg - mc.player.getYRot()));
        float dirx = (float) Math.sin(rel), diry = -(float) Math.cos(rel);
        float rx = sw / 2f - size * 2f, ry = sh / 2f - size * 2f;
        float px = sw / 2f + dirx * rx * 0.85f, py = sh / 2f + diry * ry * 0.85f;
        float perx = -diry, pery = dirx;
        float tx = px + dirx * size, ty = py + diry * size;
        float lx = px - dirx * size * 0.6f + perx * size * 0.6f, ly = py - diry * size * 0.6f + pery * size * 0.6f;
        float mx = px - dirx * size * 0.6f - perx * size * 0.6f, my = py - diry * size * 0.6f - pery * size * 0.6f;
        Lines.segment(g, tx, ty, lx, ly, 2f, color);
        Lines.segment(g, lx, ly, mx, my, 2f, color);
        Lines.segment(g, mx, my, tx, ty, 2f, color);
        Lines.disc(g, Math.round(px), Math.round(py), Math.max(1, size / 4), color);
    }

    /** Soft red-style border around the whole screen; {@code a} is 0..1 alpha multiplier. */
    public static void vignette(GuiGraphics g, Minecraft mc, int color, float a, int thickness) {
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        for (int i = 0; i < thickness; i++) {
            int c = Draw.alpha(color, a * (1f - i / (float) thickness) * 0.6f);
            g.fill(0, i, sw, i + 1, c);
            g.fill(0, sh - i - 1, sw, sh - i, c);
            g.fill(i, 0, i + 1, sh, c);
            g.fill(sw - i - 1, 0, sw - i, sh, c);
        }
    }
}
