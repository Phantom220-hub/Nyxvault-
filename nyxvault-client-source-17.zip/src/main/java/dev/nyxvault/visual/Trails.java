package dev.nyxvault.visual;

import dev.nyxvault.module.Category;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/** Concrete trails sharing one implementation ({@link TrailModule}). */
public final class Trails {
    private Trails() { }

    /** Follows normal movement; when you stop, new samples stop and the trail fades out. */
    public static final class MotionTrail extends TrailModule {
        private double lastX, lastY, lastZ;
        private boolean has;
        private long lastMoveMs;

        public MotionTrail() {
            super("Motion Trail", "Smooth fading line behind you. Visual only; does not touch movement.",
                    Category.VISUALS, Style.DOTS, 0xFF22D3EE, 0xFF3B82F6, 60, 3.0);
        }

        @Override public void onWorldChange() { super.onWorldChange(); has = false; }

        @Override protected boolean sampleHead(Minecraft mc, float pt, double[] out) {
            Player p = mc.player;
            double x = Mth.lerp(pt, p.xo, p.getX());
            double y = Mth.lerp(pt, p.yo, p.getY()) + 0.06;
            double z = Mth.lerp(pt, p.zo, p.getZ());
            long now = System.currentTimeMillis();
            if (has) {
                double ddx = x - lastX, ddy = y - lastY, ddz = z - lastZ;
                if (ddx * ddx + ddy * ddy + ddz * ddz > 1e-4) lastMoveMs = now;
            }
            lastX = x; lastY = y; lastZ = z; has = true;
            if (now - lastMoveMs > 120) return false;
            out[0] = x; out[1] = y; out[2] = z;
            out[3] = x; out[4] = y + 1.7; out[5] = z; // ribbon edge at head height
            return true;
        }
    }

    /**
     * Sword-swing trail. It is a stable approximation: the tip is placed on an arc in front of the
     * camera that follows the swing progress of your attack animation. It does NOT read the real
     * item model, so it will not match the model perfectly. First person only.
     */
    public static final class WeaponTrail extends TrailModule {
        public WeaponTrail() {
            super("Weapon Trail", "Ribbon behind a sword swing (approximation of the swing arc, not the real model).",
                    Category.COMBAT, Style.FILLED, 0xFFEC4899, 0xFFA855F7, 30, 3.0);
        }

        @Override protected double minStep() { return 0.05; }

        @Override protected boolean sampleHead(Minecraft mc, float pt, double[] out) {
            Player p = mc.player;
            if (!p.swinging || !mc.options.getCameraType().isFirstPerson()) return false;
            float prog = p.getAttackAnim(pt);               // 0 -> 1 over the swing
            double yaw = Math.toRadians(p.getViewYRot(pt));
            double pitch = Math.toRadians(p.getViewXRot(pt));
            double yawOff = Math.toRadians(38.0 - 76.0 * prog);     // right -> left
            double pitchOff = Math.toRadians(-28.0 + 52.0 * prog);  // up -> down
            double ay = yaw + yawOff, ap = pitch + pitchOff;
            double dxv = -Math.sin(ay) * Math.cos(ap), dyv = -Math.sin(ap), dzv = Math.cos(ay) * Math.cos(ap);
            var eye = p.getEyePosition(pt);
            double bx = eye.x + (-Math.cos(yaw)) * 0.35;
            double by = eye.y - 0.35;
            double bz = eye.z + (-Math.sin(yaw)) * 0.35;
            out[0] = bx + dxv * 2.3; out[1] = by + dyv * 2.3; out[2] = bz + dzv * 2.3;   // tip
            out[3] = bx + dxv * 1.0; out[4] = by + dyv * 1.0; out[5] = bz + dzv * 1.0;   // blade point
            return true;
        }
    }
}
