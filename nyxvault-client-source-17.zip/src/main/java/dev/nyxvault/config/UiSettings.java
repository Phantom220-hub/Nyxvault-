package dev.nyxvault.config;

import dev.nyxvault.render.Theme;

/** Global GUI/appearance settings, mirrored from the Interface module each tick. */
public final class UiSettings {
    /** Workload preset for THIS mod's own rendering only (never touches game physics or particles). */
    public enum Preset { LOW, BALANCED, HIGH }

    public static Theme theme = Theme.NYXVAULT_SIGNATURE;
    /** Custom accent override (ARGB) or 0 for the theme accent. */
    public static int customAccent = 0;
    public static boolean guiSounds = true;
    public static float soundVolume = 0.5f;
    public static boolean reducedEffects = false;
    public static boolean glow = true;
    /** 0 = animations off, 1 = normal, 2 = strong. */
    public static float animationIntensity = 1.0f;
    /** Speed multiplier for GUI/list animations. */
    public static float animationSpeed = 1.0f;
    /** Extra GUI scale factor for the click GUI (accessibility / small screens). */
    public static float guiScale = 1.0f;
    public static Preset preset = Preset.BALANCED;

    private UiSettings() { }

    public static int accent() { return customAccent != 0 ? customAccent : theme.accent; }
    public static int secondary() { return theme.secondary; }

    /** Multiplier for how much geometry optional effects (trails) may draw. */
    public static float perfFactor() {
        return switch (preset) {
            case LOW -> 0.5f;
            case BALANCED -> 1.0f;
            case HIGH -> 1.5f;
        };
    }

    public static boolean glowEnabled() { return glow && !reducedEffects && preset != Preset.LOW; }
}
