package dev.nyxvault.visual;

import dev.nyxvault.module.combat.CombatState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * The single "current target" shared by Target Circle and Target Effects.
 *
 * A target is valid only while it is the entity you last attacked (within 4 s), it is alive, in
 * your world, and you have a line of sight to it (so nothing is drawn around targets hidden behind
 * walls). When the target is lost the last position is kept only to fade the effect out.
 * No entities are created and nothing is sent to the server.
 */
public final class TargetFocus {
    private static final long TIMEOUT_MS = 4000;

    public static boolean valid;
    public static double x, y, z;       // smoothed feet position
    public static float height = 1.8f;
    private static long foundMs, lostMs;
    private static int frame;

    private TargetFocus() { }

    public static void update(Minecraft mc, float partialTick) {
        LivingEntity t = CombatState.target(TIMEOUT_MS);
        boolean ok = t != null && mc.player != null && mc.level != null && t != mc.player
                && t.level() == mc.level && t.isAlive();
        if (ok && (frame++ & 1) == 0) {
            ok = mc.player.hasLineOfSight(t);
            lastLos = ok;
        } else if (ok) {
            ok = lastLos;
        }
        long now = System.currentTimeMillis();
        if (ok) {
            if (!valid) foundMs = now;
            valid = true;
            x = Mth.lerp(partialTick, t.xo, t.getX());
            y = Mth.lerp(partialTick, t.yo, t.getY());
            z = Mth.lerp(partialTick, t.zo, t.getZ());
            height = t.getBbHeight();
        } else if (valid) {
            valid = false;
            lostMs = now;
        }
    }

    private static boolean lastLos;

    /** 0..1 fade factor: ramps up after a target is found and down after it is lost. */
    public static float alpha(long fadeMs) {
        long now = System.currentTimeMillis();
        float f = Math.max(1, fadeMs);
        if (valid) return Math.min(1f, (now - foundMs) / f);
        return Math.max(0f, 1f - (now - lostMs) / f);
    }

    public static void reset() {
        valid = false;
        lostMs = 0;
        foundMs = 0;
        lastLos = false;
    }
}
