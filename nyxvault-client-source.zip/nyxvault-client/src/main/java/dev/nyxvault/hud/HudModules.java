package dev.nyxvault.hud;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.util.ClickTracker;
import dev.nyxvault.waypoint.Waypoint;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** All draggable HUD elements. Each is a small, self-contained class. */
public final class HudModules {
    private HudModules() { }

    private static final int WHITE = 0xFFFFFFFF;

    /** Base for single-line text elements with a rounded dark background. */
    abstract static class TextElement extends HudModule {
        protected TextElement(String name, String desc, int x, int y) { super(name, desc, Category.HUD, x, y); }

        protected abstract String text(Minecraft mc);

        @Override public int width(Minecraft mc) { return mc.font.width(text(mc)) + 10; }
        @Override public int height(Minecraft mc) { return 14; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            int w = width(mc), h = height(mc);
            Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
            g.fill(0, 2, 2, h - 2, a(UiSettings.accent()));
            g.drawString(mc.font, text(mc), 6, 3, a(WHITE), true);
        }
    }

    public static final class Watermark extends TextElement {
        public Watermark() { super("Watermark", "Shows the NYXVAULT watermark.", 4, 4); }
        @Override protected String text(Minecraft mc) { return "NYXVAULT CLIENT"; }
    }

    public static final class Fps extends TextElement {
        public Fps() { super("FPS", "FPS and approximate frame time.", 4, 22); }
        @Override protected String text(Minecraft mc) {
            int fps = Math.max(1, mc.getFps());
            return fps + " FPS  (" + String.format("%.1f", 1000f / fps) + " ms)";
        }
    }

    public static final class Coordinates extends TextElement {
        public Coordinates() { super("Coordinates", "Coordinates and facing direction.", 4, 40); }
        @Override protected String text(Minecraft mc) {
            return String.format("XYZ %.1f %.1f %.1f  %s", mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    mc.player.getDirection().getName().toUpperCase());
        }
    }

    public static final class Cps extends TextElement {
        public Cps() { super("CPS", "Clicks per second (physical mouse presses).", 4, 58); }
        @Override protected String text(Minecraft mc) {
            return "CPS " + ClickTracker.leftCps() + " | " + ClickTracker.rightCps();
        }
    }

    public static final class Ping extends TextElement {
        public Ping() { super("Ping", "Latency reported by the server.", 4, 76); }
        @Override protected String text(Minecraft mc) {
            if (mc.getConnection() == null) return "Ping: n/a";
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            return info == null ? "Ping: n/a" : "Ping " + info.getLatency() + " ms";
        }
    }

    public static final class SessionTimer extends TextElement {
        private final long start = System.currentTimeMillis();
        public SessionTimer() { super("Session Timer", "Elapsed time since the game started.", 4, 94); }
        @Override protected String text(Minecraft mc) {
            long s = (System.currentTimeMillis() - start) / 1000;
            return String.format("Session %02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        }
    }

    public static final class WaypointHud extends TextElement {
        public WaypointHud() { super("Waypoint HUD", "Distance, coordinates and direction of the active waypoint.", 4, 112); }
        @Override protected String text(Minecraft mc) {
            Waypoint w = NyxvaultClient.waypoints().active();
            if (w == null) return "No active waypoint";
            if (!w.dimension.equals(mc.level.dimension().toString())) return w.name + ": other dimension";
            double d = w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            return String.format("%s  %.0fm  (%d, %d, %d) %s", w.name, d, (int) w.x, (int) w.y, (int) w.z,
                    w.arrow(mc.player.getX(), mc.player.getZ(), mc.player.getYRot()));
        }
    }

    public static final class Keystrokes extends HudModule {
        public Keystrokes() { super("Keystrokes", "WASD, jump and mouse buttons.", Category.HUD, 4, 140); }
        @Override public int width(Minecraft mc) { return 70; }
        @Override public int height(Minecraft mc) { return 62; }

        private void key(GuiGraphics g, Minecraft mc, int x, int y, int w, String label, boolean down) {
            int bg = down ? Draw.alpha(UiSettings.accent(), 0.8f * opacity.asFloat()) : a(UiSettings.theme.background);
            Draw.round(g, x, y, w, 14, bg);
            g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + 3, a(WHITE), true);
        }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            var o = mc.options;
            key(g, mc, 24, 0, 22, "W", o.keyUp.isDown());
            key(g, mc, 0, 16, 22, "A", o.keyLeft.isDown());
            key(g, mc, 24, 16, 22, "S", o.keyDown.isDown());
            key(g, mc, 48, 16, 22, "D", o.keyRight.isDown());
            key(g, mc, 0, 32, 34, "LMB", o.keyAttack.isDown());
            key(g, mc, 36, 32, 34, "RMB", o.keyUse.isDown());
            key(g, mc, 0, 48, 70, "SPACE", o.keyJump.isDown());
        }
    }

    public static final class ArmorHud extends HudModule {
        private final BoolSetting durability = add(new BoolSetting("Show Durability", true));
        private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

        public ArmorHud() { super("Armor HUD", "Equipped armor with durability.", Category.HUD, 4, 210); }
        @Override public int width(Minecraft mc) { return durability.get() ? 48 : 18; }
        @Override public int height(Minecraft mc) { return 68; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            Draw.round(g, 0, 0, width(mc), height(mc), a(UiSettings.theme.background));
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(SLOTS[i]);
                if (st.isEmpty()) continue;
                g.renderItem(st, 1, 1 + i * 17);
                if (durability.get() && st.isDamageableItem()) {
                    int left = st.getMaxDamage() - st.getDamageValue();
                    g.drawString(mc.font, Integer.toString(left), 19, 5 + i * 17, a(WHITE), true);
                }
            }
        }
    }

    public static final class PotionHud extends HudModule {
        public PotionHud() { super("Potion HUD", "Active potion effects with timers.", Category.HUD, 4, 282); }

        private List<String> lines(Minecraft mc) {
            List<String> out = new ArrayList<>();
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                String n = e.getEffect().value().getDisplayName().getString();
                int amp = e.getAmplifier() + 1;
                String t;
                if (e.isInfiniteDuration()) t = "inf";
                else { int s = e.getDuration() / 20; t = String.format("%d:%02d", s / 60, s % 60); }
                out.add(n + (amp > 1 ? " " + amp : "") + "  " + t);
            }
            return out;
        }

        @Override public int width(Minecraft mc) {
            int w = 60;
            for (String s : lines(mc)) w = Math.max(w, mc.font.width(s) + 10);
            return w;
        }
        @Override public int height(Minecraft mc) { return Math.max(1, lines(mc).size()) * 12 + 4; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            Draw.round(g, 0, 0, width(mc), height(mc), a(UiSettings.theme.background));
            List<String> l = lines(mc);
            if (l.isEmpty()) { g.drawString(mc.font, "No effects", 5, 4, a(0xFF9CA3AF), true); return; }
            for (int i = 0; i < l.size(); i++) g.drawString(mc.font, l.get(i), 5, 4 + i * 12, a(WHITE), true);
        }
    }

    /** Lists enabled modules (sorted by width). */
    public static final class ModuleList extends HudModule {
        public ModuleList() { super("Module List", "Lists enabled modules.", Category.HUD, 700, 4); }

        private List<Module> enabled() {
            List<Module> l = new ArrayList<>();
            for (Module m : NyxvaultClient.modules().all()) if (m.enabled() && m != this) l.add(m);
            return l;
        }

        @Override public int width(Minecraft mc) {
            int w = 60;
            for (Module m : enabled()) w = Math.max(w, mc.font.width(m.name()) + 10);
            return w;
        }
        @Override public int height(Minecraft mc) { return Math.max(1, enabled().size()) * 11 + 2; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            List<Module> l = enabled();
            l.sort(Comparator.comparingInt((Module m) -> mc.font.width(m.name())).reversed());
            int w = width(mc);
            for (int i = 0; i < l.size(); i++) {
                String n = l.get(i).name();
                int tw = mc.font.width(n);
                g.fill(w - tw - 8, 1 + i * 11, w, 12 + i * 11, a(UiSettings.theme.background));
                g.fill(w - 2, 1 + i * 11, w, 12 + i * 11, a(UiSettings.accent()));
                g.drawString(mc.font, n, w - tw - 5, 3 + i * 11, a(WHITE), true);
            }
        }
    }
}
