package dev.nyxvault.module.player;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.gui.FlipSetupScreen;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.setting.StringSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

/**
 * Buys the cheapest-per-piece lots from an auction menu and resells the bought items one piece at a
 * time through Auction Seller. Menu slots are configurable (defaults match a 6-row menu whose bottom
 * row holds: 47 refresh, 48 previous page, 50 next page, 52 sort). Only for a server that allows it.
 */
public final class AuctionFlipper extends Module {
    private final StringSetting openCmd = add(new StringSetting("Open Command", "ah", 24, "Команда открытия аукциона (без /)"));
    private final StringSetting menuTitle = add(new StringSetting("Menu Title", "Аукцион", 24, "Часть названия меню аукциона"));
    private final StringSetting priceWord = add(new StringSetting("Price Word", "Цена", 16, "Слово перед ценой в описании лота"));
    private final StringSetting filterS = add(new StringSetting("Item Filter", "", 24, "Часть названия предмета (пусто - любой)"));
    private final NumberSetting maxUnit = add(NumberSetting.integer("Max Buy Price", 5000, 1, 2000000000));
    private final NumberSetting resell = add(NumberSetting.integer("Resell Price", 9000, 1, 2000000000));
    private final NumberSetting lotSlots = add(NumberSetting.integer("Lot Slots", 45, 9, 54));
    private final NumberSetting refreshSlot = add(NumberSetting.integer("Refresh Slot", 47, -1, 200));
    private final NumberSetting prevSlot = add(NumberSetting.integer("Prev Page Slot", 48, -1, 200));
    private final NumberSetting nextSlot = add(NumberSetting.integer("Next Page Slot", 50, -1, 200));
    private final NumberSetting sortSlot = add(NumberSetting.integer("Sort Slot", 52, -1, 200));
    private final NumberSetting confirmSlot = add(NumberSetting.integer("Confirm Slot", -1, -1, 200));
    private final NumberSetting pages = add(NumberSetting.integer("Pages To Scan", 1, 1, 7));
    private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 10, 4, 100));
    private final NumberSetting cycle = add(NumberSetting.integer("Cycle (sec)", 5, 2, 120));
    private final NumberSetting maxBought = add(NumberSetting.integer("Max Bought", 0, 0, 10000));
    private final NumberSetting budgetS = add(NumberSetting.integer("Budget", 0, 0, 2000000000));
    private final StringSetting qtyTitle = add(new StringSetting("Quantity Menu Title", "Покупка", 24, "Часть названия меню выбора количества"));
    private final NumberSetting qtyConfirm = add(NumberSetting.integer("Qty Confirm Slot", 4, 0, 53));
    private final NumberSetting qtyPlus1 = add(NumberSetting.integer("Qty +1 Slot", 5, 0, 53));
    private final NumberSetting qtyMinus1 = add(NumberSetting.integer("Qty -1 Slot", 3, 0, 53));
    private final NumberSetting qtyPlus10 = add(NumberSetting.integer("Qty +10 Slot", 6, 0, 53));
    private final NumberSetting qtyMinus10 = add(NumberSetting.integer("Qty -10 Slot", 2, 0, 53));
    private final BoolSetting debug = add(new BoolSetting("Debug Scan", true));
    private final BoolSetting useSearch = add(new BoolSetting("Use Search Command", true));
    private final BoolSetting askSetup = add(new BoolSetting("Ask Setup On Start", true));
    private final BoolSetting resellOn = add(new BoolSetting("Resell Bought", true));
    private final BoolSetting stopOnDamage = add(new BoolSetting("Stop On Damage", true));

    public static volatile int boughtCount, spent;
    public static volatile String status = "Idle";

    private enum St { CLOSED, OPENING, SORT, SCAN, QTY, RETURN, CONFIRM, VERIFY, SELL, SELLER }
    private St st = St.CLOSED;
    private int wait, page, bought, tries, sortTries, sellTimeout;
    private boolean awaiting, needSell;
    private Item boughtItem, pendItem;
    private int pendBefore, pendCost, fails, qtyTarget, qtySteps;
    private float lastHp;

    public AuctionFlipper() {
        super("Auction Flipper", "Buys the cheapest-per-piece lots from the auction menu and resells them. Configure the menu in the settings.", Category.PLAYER);
    }

    @Override protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        st = St.CLOSED; fails = 0; wait = 0; page = 0; bought = 0; tries = 0; sortTries = 0; boughtItem = null; needSell = false;
        boughtCount = 0; spent = 0; status = "Idle"; awaiting = false;
        lastHp = p == null ? 0 : p.getHealth();
        if (p == null) { setEnabled(false); return; }
        if (askSetup.get()) {
            awaiting = true; status = "Setup";
            mc.setScreen(new FlipSetupScreen(this, filterS.get(), maxUnit.asInt(), resell.asInt(), budgetS.asInt()));
        } else {
            Notifications.push("Перекуп: до " + maxUnit.asInt() + " за шт., продажа " + resell.asInt());
        }
    }

    public void confirmSetup(String filter, int max, int sell, int budget) {
        filterS.set(filter); maxUnit.set((double) max); resell.set((double) sell); budgetS.set((double) budget);
        awaiting = false;
        Notifications.push("Перекуп: до " + max + " за шт., продажа " + sell);
    }

    public void cancelSetup() { awaiting = false; setEnabled(false); }

    @Override protected void onDisable() { status = "Idle"; awaiting = false; }

    private void stop(String why) {
        Notifications.push(why + " Куплено: " + bought);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.screen instanceof AbstractContainerScreen<?>) mc.setScreen(null);
        setEnabled(false);
    }

    @Override public void onWorldChange() { if (enabled()) stop("Смена мира."); }

    /** Price per piece of a lot, or -1 when the lore has no price. */
    /** All tooltip lines of the stack exactly as the game builds them for a hover (falls back to the lore). */
    private static java.util.List<Component> linesOf(ItemStack s) {
        Minecraft mc = Minecraft.getInstance();
        try {
            if (mc.level != null && mc.player != null) {
                return s.getTooltipLines(Item.TooltipContext.of(mc.level), mc.player, net.minecraft.world.item.TooltipFlag.NORMAL);
            }
        } catch (Throwable ignored) { }
        ItemLore lore = s.get(DataComponents.LORE);
        return lore == null ? java.util.List.of() : lore.lines();
    }

    private double unitPrice(ItemStack s) {
        double total = -1, unit = -1;
        for (Component c : linesOf(s)) {
            String t = c.getString();
            int i = t.indexOf(priceWord.get());
            if (i < 0) continue;
            int colon = t.indexOf(':', i);
            if (colon < 0) continue; // the price is always written after a colon ("Цена за 1 ед.: 16 666")
            StringBuilder d = new StringBuilder();
            for (int k = colon + 1; k < t.length(); k++) {
                char ch = t.charAt(k);
                if (ch >= '0' && ch <= '9') d.append(ch);
                else if (d.length() > 0 && ch != ' ' && ch != ',' && ch != '.' && ch != ' ') break;
            }
            if (d.length() == 0 || d.length() > 10) continue;
            double v = Long.parseLong(d.toString());
            String low = t.toLowerCase();
            if (low.contains("за ед") || low.contains("за 1") || low.contains("за шт")) { if (unit < 0) unit = v; }
            else if (total < 0) total = v;
        }
        if (unit >= 0) return unit;
        return total < 0 ? -1 : total / Math.max(1, s.getCount());
    }

    /** True when the sort button's lore has its check mark on a "per unit, cheapest first" line. */
    private boolean sortedOk(AbstractContainerMenu m) {
        int sl = sortSlot.asInt();
        if (sl < 0 || sl >= m.slots.size()) return true;
        java.util.List<Component> ls = linesOf(m.slots.get(sl).getItem());
        if (ls.isEmpty()) return true;
        for (Component c : ls) {
            String t = c.getString();
            if (t.contains("✔") || t.contains("✓") || t.contains("√")) {
                String low = t.toLowerCase();
                return low.contains("дешев") && low.contains("за ед");
            }
        }
        return true;
    }

    private static String loreSample(ItemStack s) {
        java.util.List<Component> ls = linesOf(s);
        if (ls.isEmpty()) return "нет описания у предмета";
        StringBuilder b = new StringBuilder();
        for (Component c : ls) {
            if (b.length() > 90) break;
            if (b.length() > 0) b.append(" / ");
            b.append(c.getString());
        }
        return b.toString();
    }

    private static int countOf(Player p, Item item) {
        Inventory inv = p.getInventory();
        int n = 0;
        for (int i = 0; i < 36; i++) if (inv.getItem(i).getItem() == item) n += inv.getItem(i).getCount();
        return n;
    }

    private void click(Minecraft mc, Player p, int slot) {
        mc.gameMode.handleInventoryMouseClick(p.containerMenu.containerId, slot, 0, ClickType.PICKUP, p);
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null || mc.getConnection() == null || awaiting) return;
        if (stopOnDamage.get()) {
            float hp = p.getHealth();
            if (hp < lastHp - 0.01f) { stop("Получен урон."); return; }
            lastHp = hp;
        }
        if (maxBought.asInt() > 0 && bought >= maxBought.asInt()) { stop("Достигнут лимит."); return; }
        if (wait > 0) { wait--; return; }

        boolean searching = useSearch.get() && !filterS.get().isEmpty();
        boolean menuOpen = mc.screen instanceof AbstractContainerScreen<?> cs
                && (searching || cs.getTitle().getString().contains(menuTitle.get()))
                && p.containerMenu != p.inventoryMenu;

        switch (st) {
            case CLOSED -> {
                if (mc.screen != null) return;
                status = "Waiting";
                if (resellOn.get() && needSell) { st = St.SELL; return; }
                mc.getConnection().sendCommand(searching ? "ah search " + filterS.get() : openCmd.get());
                st = St.OPENING; tries = 0; page = 0; sortTries = 0;
                wait = delay.asInt();
            }
            case OPENING -> {
                if (menuOpen) { st = St.SORT; return; }
                if (++tries > 40) { st = St.CLOSED; wait = cycle.asInt() * 20; }
            }
            case SORT -> {
                if (!menuOpen) { st = St.CLOSED; wait = cycle.asInt() * 20; return; }
                if (!sortedOk(p.containerMenu) && ++sortTries <= 6) {
                    click(mc, p, sortSlot.asInt());
                    wait = delay.asInt();
                    return;
                }
                st = St.SCAN; status = "Scanning";
            }
            case SCAN -> {
                if (!menuOpen) { st = St.CLOSED; wait = cycle.asInt() * 20; return; }
                AbstractContainerMenu m = p.containerMenu;
                int lim = Math.min(lotSlots.asInt(), m.slots.size());
                String f = searching ? "" : filterS.get().toLowerCase(); // the server already filtered by /ah search
                int seen = 0, priced = 0, cheap = 0;
                double minUnit = -1;
                String sample = null;
                for (int i = 0; i < lim; i++) {
                    ItemStack s = m.slots.get(i).getItem();
                    if (s.isEmpty()) continue;
                    if (!f.isEmpty() && !s.getHoverName().getString().toLowerCase().contains(f)) continue;
                    seen++;
                    double unit = unitPrice(s);
                    if (unit >= 0) { priced++; if (minUnit < 0 || unit < minUnit) minUnit = unit; }
                    else if (sample == null) sample = loreSample(s);
                    if (unit < 0 || unit > maxUnit.asInt()) continue;
                    cheap++;
                    double total = unit * s.getCount();
                    long left = budgetS.asInt() > 0 ? (long) budgetS.asInt() - spent : Long.MAX_VALUE;
                    if (left < unit) { stop("Бюджет закончился."); return; }
                    pendItem = s.getItem();
                    pendBefore = countOf(p, pendItem);
                    if (total <= left) { // enough money for the whole lot: left click buys it fully
                        pendCost = (int) Math.min(Integer.MAX_VALUE, Math.round(total));
                        click(mc, p, i);
                        wait = delay.asInt();
                        st = confirmSlot.asInt() >= 0 ? St.CONFIRM : St.VERIFY;
                    } else { // not enough for all of it: right click, then choose how many pieces
                        qtyTarget = (int) Math.max(1, Math.min(s.getCount() - 1, Math.floor(left / unit)));
                        pendCost = (int) Math.round(qtyTarget * unit);
                        mc.gameMode.handleInventoryMouseClick(m.containerId, i, 1, ClickType.PICKUP, p);
                        st = St.QTY; qtySteps = 0; tries = 0;
                        wait = delay.asInt();
                    }
                    return;
                }
                if (debug.get()) {
                    String msg = "Лотов: " + seen + ", с ценой: " + priced + ", подходят: " + cheap
                            + (minUnit >= 0 ? ", мин. цена за шт: " + Math.round(minUnit) : "") + ", лимит: " + maxUnit.asInt();
                    if (seen > 0 && priced == 0 && sample != null) msg += " | Описание: " + sample;
                    Notifications.push(msg);
                }
                if (nextSlot.asInt() >= 0 && page + 1 < pages.asInt()) {
                    click(mc, p, nextSlot.asInt()); page++;
                    wait = delay.asInt();
                } else {
                    st = St.RETURN;
                }
            }
            case QTY -> {
                boolean qm = mc.screen instanceof AbstractContainerScreen<?> cs2
                        && cs2.getTitle().getString().contains(qtyTitle.get())
                        && p.containerMenu != p.inventoryMenu;
                if (!qm) {
                    if (++tries > 30) { mc.setScreen(null); fails++; st = St.CLOSED; wait = cycle.asInt() * 20; }
                    return;
                }
                AbstractContainerMenu qmenu = p.containerMenu;
                int cs = qtyConfirm.asInt();
                int cur = qmenu.slots.size() > cs ? qmenu.slots.get(cs).getItem().getCount() : 1;
                if (cur == qtyTarget) { click(mc, p, cs); st = St.VERIFY; wait = delay.asInt(); return; }
                if (++qtySteps > 40) { mc.setScreen(null); fails++; st = St.CLOSED; wait = cycle.asInt() * 20; return; }
                int diff = qtyTarget - cur;
                int slot = diff > 0 ? (diff >= 10 ? qtyPlus10.asInt() : qtyPlus1.asInt())
                                    : (-diff >= 10 ? qtyMinus10.asInt() : qtyMinus1.asInt());
                click(mc, p, slot);
                wait = delay.asInt();
            }
            case RETURN -> {
                if (!menuOpen) { st = St.CLOSED; wait = cycle.asInt() * 20; return; }
                if (page > 0 && prevSlot.asInt() >= 0) { click(mc, p, prevSlot.asInt()); page--; wait = delay.asInt(); return; }
                if (refreshSlot.asInt() >= 0) click(mc, p, refreshSlot.asInt());
                page = 0; wait = cycle.asInt() * 20;
                st = St.SORT; sortTries = 0;
            }
            case CONFIRM -> {
                if (mc.screen instanceof AbstractContainerScreen<?> && p.containerMenu != p.inventoryMenu) click(mc, p, confirmSlot.asInt());
                st = St.VERIFY; wait = delay.asInt();
            }
            case VERIFY -> {
                if (mc.screen instanceof AbstractContainerScreen<?>) mc.setScreen(null);
                if (countOf(p, pendItem) > pendBefore) {
                    bought++; boughtCount = bought; spent += pendCost;
                    boughtItem = pendItem; needSell = true; fails = 0;
                } else if (++fails >= 3) {
                    stop("Покупка не проходит: не хватает денег или лоты забрали.");
                    return;
                }
                st = St.CLOSED; wait = delay.asInt() * 2;
            }
            case SELL -> {
                if (mc.screen != null) return;
                if (boughtItem == null) { needSell = false; st = St.CLOSED; return; }
                status = "Selling";
                Inventory inv = p.getInventory();
                int idx = -1;
                for (int i = 0; i < 36; i++) if (inv.getItem(i).getItem() == boughtItem) { idx = i; break; }
                if (idx < 0) { needSell = false; st = St.CLOSED; return; }
                int sel = inv.getSelectedSlot();
                if (idx >= 9) { mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, idx, sel, ClickType.SWAP, p); wait = 5; return; }
                if (sel != idx) { inv.setSelectedSlot(idx); wait = 5; return; }
                Module seller = NyxvaultClient.modules().get("Auction Seller");
                if (!(seller instanceof AuctionSeller as)) { needSell = false; st = St.CLOSED; return; }
                as.startSilent(resell.asInt());
                needSell = false; sellTimeout = 0; st = St.SELLER;
            }
            case SELLER -> {
                Module seller = NyxvaultClient.modules().get("Auction Seller");
                if (seller == null || !seller.enabled() || ++sellTimeout > 20 * 60 * 20) {
                    st = St.CLOSED; wait = delay.asInt();
                }
            }
        }
    }
}
