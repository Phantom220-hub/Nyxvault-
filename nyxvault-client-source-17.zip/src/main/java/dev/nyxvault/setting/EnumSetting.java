package dev.nyxvault.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final E[] constants;

    public EnumSetting(String name, E def) {
        super(name, def);
        this.constants = def.getDeclaringClass().getEnumConstants();
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value.name()); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        String s = e.getAsString();
        for (E c : constants) if (c.name().equals(s)) { value = c; return; }
    }

    @Override public String display() { return value.name(); }

    @Override public void interact(int direction) {
        int i = (value.ordinal() + direction + constants.length) % constants.length;
        value = constants[i];
    }
}
