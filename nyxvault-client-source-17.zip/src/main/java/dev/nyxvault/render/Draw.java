package dev.nyxvault.render;

import net.minecraft.client.gui.GuiGraphics;

/** Small drawing helpers built only on GuiGraphics.fill (cheap, no custom pipelines). */
public final class Draw {
    private Draw() { }

    /** Filled rectangle with 1px-cut corners to look rounded. */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + w, y + h - 1, color);
    }

    /** Thin illuminated border. */
    public static void border(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + 1, color);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + 1, y + h - 1, color);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    public static int alpha(int argb, float a) {
        int na = Math.max(0, Math.min(255, Math.round(((argb >>> 24) & 0xFF) * a)));
        return (na << 24) | (argb & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, aa = (a >>> 24) & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255, ba = (b >>> 24) & 255;
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }

    /** Frame-rate independent exponential approach of {@code current} toward {@code target}. */
    public static float approach(float current, float target, float speed, float dtSeconds) {
        float k = 1f - (float) Math.exp(-speed * dtSeconds);
        return current + (target - current) * k;
    }
}
