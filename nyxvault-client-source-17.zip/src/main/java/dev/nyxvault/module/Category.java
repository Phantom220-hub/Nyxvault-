package dev.nyxvault.module;

public enum Category {
    COMBAT("Combat"),
    VISUALS("Visuals"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    HUD("HUD"),
    WORLD("World"),
    UTILITIES("Utilities"),
    MISC("Misc"),
    SETTINGS("Settings");

    public final String title;
    Category(String title) { this.title = title; }
}
