package dev.nyxvault.visual;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Lines;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Smooth ribbon/line trail. Samples are recorded per rendered frame (only after the head moved a
 * minimum distance, so the history is bounded), smoothed with a Catmull-Rom spline, projected and
 * drawn as rotated line segments (see {@link Lines}). Purely visual: it never touches movement,
 * physics or particles. Drawn on the HUD layer in first person only; it is not depth-tested.
 *
 * Safety: the buffer is cleared on world change, death, teleport (jump larger than 8 blocks),
 * and when the module is disabled, so distant points are never joined by a giant line.
 */
public abstract class TrailModule extends OverlayModule {
    public enum Style { LINE, DOUBLE, RIBBON, GRADIENT, MINIMAL, DOTS, FILLED }

    private static final int CP = 162;            // max control points (buffer 160 + head)
    private static final int SP = CP * 4 + 8;     // max smoothed points

    private final EnumSetting<Style> style;
    private final ColorSetting color;
    private final ColorSetting color2;
    private final NumberSetting length;
    private final NumberSetting width;
    private final NumberSetting opacity;
    private final NumberSetting lifetime;
    private final NumberSetting smoothing;
    private final BoolSetting performance;

    private final TrailBuffer buf = new TrailBuffer(160);
    protected final double[] head = new double[6];

    // Scratch arrays, allocated once.
    private final double[] cx = new double[CP], cy = new double[CP], cz = new double[CP];
    private final double[] dx = new double[CP], dy = new double[CP], dz = new double[CP];
    private final float[] cage = new float[CP];
    private final float[] sx = new float[SP], sy = new float[SP], sx2 = new float[SP], sy2 = new float[SP];
    private final float[] sa = new float[SP], st = new float[SP];
    private final boolean[] ok = new boolean[SP], ok2 = new boolean[SP];

    protected TrailModule(String name, String desc, Category cat, Style defStyle, int c1, int c2, int defLength, double defWidth) {
        super(name, desc, cat);
        this.style = add(new EnumSetting<>("Style", defStyle));
        this.color = add(new ColorSetting("Color", c1));
        this.color2 = add(new ColorSetting("Gradient Color", c2));
        this.length = add(NumberSetting.integer("Length", defLength, 5, 150));
        this.width = add(NumberSetting.decimal("Width", defWidth, 0.5, 8.0, 0.5));
        this.opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
        this.lifetime = add(NumberSetting.integer("Lifetime (ms)", 900, 150, 5000));
        this.smoothing = add(NumberSetting.integer("Smoothing Quality", 2, 1, 4));
        this.performance = add(new BoolSetting("Performance Mode", false));
    }

    /**
     * Fill {@code out} with the current head: [0..2] main point, [3..5] second point (ribbon edge).
     * @return false when there is no live head (the trail then just fades out).
     */
    protected abstract boolean sampleHead(Minecraft mc, float partialTick, double[] out);

    /** Minimum distance (blocks) between recorded samples. */
    protected double minStep() { return 0.12; }

    @Override protected void onDisable() { buf.clear(); }
    @Override public void onWorldChange() { buf.clear(); }

    private static double cr(double a, double b, double c, double d, double t) {
        return 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t * t * t);
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (mc.player == null || mc.level == null || !mc.player.isAlive()) { buf.clear(); return; }
        float pt = delta.getGameTimeDeltaPartialTick(true);
        long now = System.currentTimeMillis();
        long life = lifetime.asInt();
        buf.prune(now, life);

        boolean headOn = sampleHead(mc, pt, head);
        if (headOn) {
            int n = buf.size();
            if (n == 0) {
                buf.add(head[0], head[1], head[2], head[3], head[4], head[5], now);
            } else {
                double ddx = head[0] - buf.x(n - 1), ddy = head[1] - buf.y(n - 1), ddz = head[2] - buf.z(n - 1);
                double d2 = ddx * ddx + ddy * ddy + ddz * ddz;
                if (d2 > 64.0) { // teleport / dimension jump: never join distant points
                    buf.clear();
                    buf.add(head[0], head[1], head[2], head[3], head[4], head[5], now);
                } else if (d2 >= minStep() * minStep()) {
                    buf.add(head[0], head[1], head[2], head[3], head[4], head[5], now);
                }
            }
        }
        if (!WorldProjector.valid) return; // third person: not drawn (see class comment)

        boolean perfMode = performance.get();
        float perf = UiSettings.perfFactor() * (perfMode ? 0.5f : 1f);
        int maxPts = Math.max(4, Math.round(length.asInt() * perf));
        int n = buf.size();
        int s0 = Math.max(0, n - maxPts);
        int cnt = 0;
        for (int i = s0; i < n && cnt < CP - 1; i++) {
            cx[cnt] = buf.x(i); cy[cnt] = buf.y(i); cz[cnt] = buf.z(i);
            dx[cnt] = buf.x2(i); dy[cnt] = buf.y2(i); dz[cnt] = buf.z2(i);
            cage[cnt] = (now - buf.time(i)) / (float) life;
            cnt++;
        }
        if (headOn && cnt < CP) {
            cx[cnt] = head[0]; cy[cnt] = head[1]; cz[cnt] = head[2];
            dx[cnt] = head[3]; dy[cnt] = head[4]; dz[cnt] = head[5];
            cage[cnt] = 0f;
            cnt++;
        }
        if (cnt < 2) return;

        Style stl = style.get();
        boolean rib = stl == Style.RIBBON || stl == Style.FILLED;
        int sub = perfMode ? 1 : Math.max(1, Math.round(smoothing.asInt() * Math.min(1f, UiSettings.perfFactor())));
        if (UiSettings.reducedEffects) sub = 1;
        int total = (cnt - 1) * sub + 1;

        int m = 0;
        for (int i = 0; i < cnt - 1; i++) {
            int i0 = Math.max(0, i - 1), i1 = i, i2 = i + 1, i3 = Math.min(cnt - 1, i + 2);
            for (int k = 0; k < sub && m < SP - 1; k++) {
                float t = k / (float) sub;
                double px = cr(cx[i0], cx[i1], cx[i2], cx[i3], t);
                double py = cr(cy[i0], cy[i1], cy[i2], cy[i3], t);
                double pz = cr(cz[i0], cz[i1], cz[i2], cz[i3], t);
                ok[m] = WorldProjector.project(px, py, pz);
                sx[m] = WorldProjector.out[0]; sy[m] = WorldProjector.out[1];
                if (rib) {
                    double qx = cr(dx[i0], dx[i1], dx[i2], dx[i3], t);
                    double qy = cr(dy[i0], dy[i1], dy[i2], dy[i3], t);
                    double qz = cr(dz[i0], dz[i1], dz[i2], dz[i3], t);
                    ok2[m] = WorldProjector.project(qx, qy, qz);
                    sx2[m] = WorldProjector.out[0]; sy2[m] = WorldProjector.out[1];
                }
                float age = cage[i1] + (cage[i2] - cage[i1]) * t;
                sa[m] = Math.max(0f, 1f - age);
                st[m] = m / (float) total;
                m++;
            }
        }
        // last control point
        ok[m] = WorldProjector.project(cx[cnt - 1], cy[cnt - 1], cz[cnt - 1]);
        sx[m] = WorldProjector.out[0]; sy[m] = WorldProjector.out[1];
        if (rib) {
            ok2[m] = WorldProjector.project(dx[cnt - 1], dy[cnt - 1], dz[cnt - 1]);
            sx2[m] = WorldProjector.out[0]; sy2[m] = WorldProjector.out[1];
        }
        sa[m] = Math.max(0f, 1f - cage[cnt - 1]);
        st[m] = 1f;
        m++;

        float baseW = width.asFloat();
        float op = opacity.asFloat();
        int c1 = color.get(), c2 = color2.get();
        for (int j = 1; j < m; j++) {
            if (!ok[j - 1] || !ok[j]) continue;
            float t = st[j];
            float a = Math.min(1f, sa[j]) * op * (0.15f + 0.85f * t);
            if (a < 0.02f) continue;
            float w = stl == Style.MINIMAL ? 1f : baseW * (0.35f + 0.65f * t);
            int base = stl == Style.GRADIENT ? Draw.mix(c2, c1, t) : c1;
            int col = Draw.alpha(base, a);
            switch (stl) {
                case DOUBLE -> {
                    float ex = sx[j] - sx[j - 1], ey = sy[j] - sy[j - 1];
                    float len = (float) Math.sqrt(ex * ex + ey * ey);
                    if (len > 0.05f) {
                        float o = (w + 1.5f) * 0.5f;
                        float ox = -ey / len * o, oy = ex / len * o;
                        Lines.segment(g, sx[j - 1] + ox, sy[j - 1] + oy, sx[j] + ox, sy[j] + oy, Math.max(1f, w * 0.6f), col);
                        Lines.segment(g, sx[j - 1] - ox, sy[j - 1] - oy, sx[j] - ox, sy[j] - oy, Math.max(1f, w * 0.6f), col);
                    }
                }
                case DOTS -> {
                    if (j % Math.max(2, sub * 3) == 0) {
                        int r = Math.max(1, Math.round(baseW * (0.5f + 0.5f * t)));
                        int px = Math.round(sx[j]), py = Math.round(sy[j]);
                        if (!perfMode) Lines.disc(g, px, py, r + 2, Draw.alpha(base, a * 0.25f));
                        Lines.disc(g, px, py, r, col);
                    }
                }
                case FILLED -> {
                    if (ok2[j - 1] && ok2[j]) {
                        Lines.segment(g, sx[j], sy[j], sx2[j], sy2[j], Math.max(2f, w * 0.9f), Draw.alpha(base, a * 0.45f));
                        Lines.segment(g, sx2[j - 1], sy2[j - 1], sx2[j], sy2[j], 1.5f, Draw.alpha(base, a));
                    }
                }
                case RIBBON -> {
                    if (ok2[j - 1] && ok2[j]) {
                        Lines.segment(g, sx[j - 1], sy[j - 1], sx[j], sy[j], Math.max(1f, w * 0.6f), col);
                        Lines.segment(g, sx2[j - 1], sy2[j - 1], sx2[j], sy2[j], Math.max(1f, w * 0.6f), col);
                        if ((j % 3) == 0) Lines.segment(g, sx[j], sy[j], sx2[j], sy2[j], 1f, Draw.alpha(base, a * 0.45f));
                    }
                }
                default -> Lines.segment(g, sx[j - 1], sy[j - 1], sx[j], sy[j], w, col);
            }
        }
    }
}
