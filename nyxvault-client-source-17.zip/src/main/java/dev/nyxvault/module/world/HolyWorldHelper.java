package dev.nyxvault.module.world;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Lines;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

/**
 * Marks players whose entity the CLIENT already has but that are flagged invisible (for example by
 * a potion). It reads only what the server has legitimately sent to your client; it cannot reveal
 * entities the server hides, uses no packets and no x-ray. Off by default. Whether a server allows
 * such indicators must be checked against that server's rules. First person only.
 */
public final class HolyWorldHelper extends OverlayModule {
    public enum Shape { DIAMOND, CIRCLE, TRIANGLE, RING }

    private final BoolSetting indicator = add(new BoolSetting("Invisible Indicator", true));
    private final EnumSetting<Shape> shape = add(new EnumSetting<>("Shape", Shape.DIAMOND));
    private final NumberSetting size = add(NumberSetting.integer("Indicator Size", 6, 2, 24));
    private final NumberSetting height = add(NumberSetting.decimal("Height Offset", 0.4, -1.0, 2.0, 0.1));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFFEC4899));
    private final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
    private final BoolSetting showName = add(new BoolSetting("Show Name", true));
    private final BoolSetting showDistance = add(new BoolSetting("Show Distance", true));
    private final NumberSetting maxDistance = add(NumberSetting.integer("Max Distance", 64, 8, 160));

    public HolyWorldHelper() {
        super("HolyWorld Helper", "Indicator for invisible players that your client already knows about. Off by default; check server rules.", Category.WORLD);
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (!indicator.get() || !WorldProjector.valid || mc.level == null || mc.player == null) return;
        double max2 = (double) maxDistance.asInt() * maxDistance.asInt();
        int col = Draw.alpha(color.get(), opacity.asFloat());
        int s = size.asInt();
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isInvisible() || !p.isAlive()) continue;
            double d2 = mc.player.distanceToSqr(p);
            if (d2 > max2) continue;
            if (!WorldProjector.project(p.getX(), p.getY() + p.getBbHeight() + height.get(), p.getZ())) continue;
            if (!WorldProjector.onScreen(30f)) continue;
            float x = WorldProjector.out[0], y = WorldProjector.out[1];
            switch (shape.get()) {
                case CIRCLE -> Lines.disc(g, Math.round(x), Math.round(y), s, col);
                case RING -> Lines.circle(g, x, y, s, 2f, col, 16);
                case TRIANGLE -> {
                    Lines.segment(g, x - s, y - s, x + s, y - s, 2f, col);
                    Lines.segment(g, x + s, y - s, x, y + s, 2f, col);
                    Lines.segment(g, x, y + s, x - s, y - s, 2f, col);
                }
                default -> {
                    Lines.segment(g, x, y - s, x + s, y, 2f, col);
                    Lines.segment(g, x + s, y, x, y + s, 2f, col);
                    Lines.segment(g, x, y + s, x - s, y, 2f, col);
                    Lines.segment(g, x - s, y, x, y - s, 2f, col);
                }
            }
            String t = (showName.get() ? p.getName().getString() : "")
                    + (showName.get() && showDistance.get() ? "  " : "")
                    + (showDistance.get() ? String.format("%.0f м", Math.sqrt(d2)) : "");
            if (!t.isEmpty()) g.drawString(mc.font, t, Math.round(x) - mc.font.width(t) / 2, Math.round(y) - s - 11, col, true);
        }
    }
}
