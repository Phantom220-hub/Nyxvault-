package dev.nyxvault.module.misc;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.util.Notifications;

/**
 * Keeps the modules that HolyWorld's rules list as forbidden (automation of inventory/trading,
 * auto attack, ESP/tracers, auto bridge) switched off while it is on. It only turns modules off;
 * it cannot make a build allowed by the server - check mods.holyworld.me.
 */
public final class HolyWorldSafeMode extends Module {
    private static final String[] BLOCKED = {
            "Auto Totem", "Auto Attack", "Auto Bridge", "Player ESP", "Hotbar Fill", "Auction Seller", "Auction Flipper"
    };

    public HolyWorldSafeMode() {
        super("HolyWorld Safe Mode", "Keeps modules forbidden by HolyWorld rules switched off (auto inventory, auto attack, ESP, auto bridge, auto sell).", Category.MISC);
    }

    @Override protected void onEnable() { sweep(true); }

    @Override public void onTick() { sweep(false); }

    private void sweep(boolean notify) {
        int off = 0;
        for (String n : BLOCKED) {
            Module m = NyxvaultClient.modules().get(n);
            if (m != null && m.enabled()) { m.setEnabled(false); off++; }
        }
        if (off > 0) Notifications.push("Безопасный режим: отключено модулей " + off);
        else if (notify) Notifications.push("Безопасный режим включён");
    }
}
