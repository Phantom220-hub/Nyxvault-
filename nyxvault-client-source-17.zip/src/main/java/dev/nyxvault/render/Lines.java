package dev.nyxvault.render;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Smooth 2D primitives on top of GuiGraphics.fill.
 *
 * Why the old trail looked like "a chain of squares": it stamped many small axis-aligned squares
 * along the path. A line segment is now ONE rotated, stretched quad (matrix rotate + scale), so
 * consecutive segments join into a continuous stroke. No allocations, no particles.
 */
public final class Lines {
    public static final int TABLE = 64;
    public static final float[] COS = new float[TABLE];
    public static final float[] SIN = new float[TABLE];

    static {
        for (int i = 0; i < TABLE; i++) {
            double a = i * 2.0 * Math.PI / TABLE;
            COS[i] = (float) Math.cos(a);
            SIN[i] = (float) Math.sin(a);
        }
    }

    private Lines() { }

    private static boolean far(float x, float y) {
        return x < -300f || y < -300f || x > WorldProjector.sw + 300f || y > WorldProjector.sh + 300f;
    }

    /** Thick line from (x0,y0) to (x1,y1) in GUI pixels. Ends are extended by half the width so joints overlap. */
    public static void segment(GuiGraphics g, float x0, float y0, float x1, float y1, float w, int color) {
        if (((color >>> 24) & 0xFF) == 0) return;
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f || len > 3000f) return;
        if (far(x0, y0) && far(x1, y1)) return;
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(x0, y0);
        pose.rotate((float) Math.atan2(dy, dx));
        pose.translate(-w * 0.5f, -w * 0.5f);
        pose.scale(len + w, w);
        g.fill(0, 0, 1, 1, color);
        pose.popMatrix();
    }

    /** Filled circle built from horizontal scanlines (crisp, no squares). */
    public static void disc(GuiGraphics g, int cx, int cy, int r, int color) {
        if (r < 1) { g.fill(cx, cy, cx + 1, cy + 1, color); return; }
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            g.fill(cx - hw, cy + dy, cx + hw + 1, cy + dy + 1, color);
        }
    }

    /** Screen-space circle outline using the sin/cos table; {@code n} must divide 64 (16, 32 or 64). */
    public static void circle(GuiGraphics g, float cx, float cy, float r, float w, int color, int n) {
        int step = TABLE / n;
        float px = cx + r, py = cy;
        for (int i = 1; i <= n; i++) {
            int k = (i * step) % TABLE;
            float x = cx + COS[k] * r, y = cy + SIN[k] * r;
            segment(g, px, py, x, y, w, color);
            px = x; py = y;
        }
    }
}
