package dev.nyxvault.module.combat;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Hits the entity under your crosshair with a normal attack once the weapon cooldown has recharged.
 * Made for mob farms (for example a creeper farm). It never aims for you, never changes reach,
 * damage or movement, and does at most one attack per tick. By default only hostile mobs are hit;
 * players are attacked only with the ALL_LIVING filter. Servers may forbid automated attacks,
 * so use it only where that is allowed.
 */
public final class AutoAttack extends Module {
    public enum Filter { HOSTILE_MOBS, CREEPERS_ONLY, ALL_LIVING }

    private final EnumSetting<Filter> filter = add(new EnumSetting<>("Target Filter", Filter.HOSTILE_MOBS));
    private final NumberSetting minCooldown = add(NumberSetting.integer("Min Cooldown (%)", 95, 50, 100));
    private final BoolSetting skipUsing = add(new BoolSetting("Pause While Using Item", true));

    public AutoAttack() {
        super("Auto Attack", "Hits the mob under your crosshair when the weapon is recharged. For mob farms. Check server rules.", Category.COMBAT);
    }

    private boolean allowed(Entity e) {
        if (!(e instanceof LivingEntity le) || !le.isAlive() || e == Minecraft.getInstance().player) return false;
        return switch (filter.get()) {
            case CREEPERS_ONLY -> e instanceof Creeper;
            case HOSTILE_MOBS -> e instanceof Enemy && !(e instanceof Player);
            case ALL_LIVING -> true;
        };
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null || mc.level == null || mc.screen != null || !p.isAlive()) return;
        if (skipUsing.get() && p.isUsingItem()) return;
        if (!(mc.hitResult instanceof EntityHitResult hit) || hit.getType() != HitResult.Type.ENTITY) return;
        Entity target = hit.getEntity();
        if (!allowed(target)) return;
        if (p.getAttackStrengthScale(0f) * 100f < minCooldown.asInt()) return;
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
