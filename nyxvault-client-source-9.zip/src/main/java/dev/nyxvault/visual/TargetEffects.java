package dev.nyxvault.visual;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Lines;
import dev.nyxvault.render.Rings;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Glowing orbs and tilted orbit rings around your current target (see {@link TargetFocus}).
 * Pure 2D overlay math: no particles, no entities. First person only, needs a line of sight.
 */
public final class TargetEffects extends OverlayModule {
    public enum Style { SINGLE_ORB, ORBIT_RINGS, MULTI_ORB }

    private final EnumSetting<Style> style = add(new EnumSetting<>("Style", Style.ORBIT_RINGS));
    private final BoolSetting showOrbs = add(new BoolSetting("Show Orbs", true));
    private final BoolSetting showRings = add(new BoolSetting("Show Rings", true));
    private final BoolSetting showLines = add(new BoolSetting("Show Orbit Lines", true));
    private final BoolSetting showAccent = add(new BoolSetting("Show Accent Ring", false));
    private final ColorSetting orbColor = add(new ColorSetting("Orb Color", 0xFFA855F7));
    private final ColorSetting ringColor = add(new ColorSetting("Ring Color", 0xFF22D3EE));
    private final NumberSetting orbitRadius = add(NumberSetting.decimal("Orbit Radius", 0.9, 0.4, 3.0, 0.1));
    private final NumberSetting speed = add(NumberSetting.decimal("Speed", 1.0, 0.25, 4.0, 0.25));
    private final NumberSetting orbSize = add(NumberSetting.integer("Orb Size", 3, 1, 8));
    private final NumberSetting orbCount = add(NumberSetting.integer("Orb Count", 3, 1, 8));
    private final NumberSetting thickness = add(NumberSetting.decimal("Ring Thickness", 1.5, 1.0, 4.0, 0.5));
    private final NumberSetting opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
    private final BoolSetting reverse = add(new BoolSetting("Reverse Direction", false));
    private final NumberSetting fade = add(NumberSetting.integer("Fade Duration (ms)", 300, 100, 1500));
    private final BoolSetting performance = add(new BoolSetting("Performance Mode", false));

    public TargetEffects() {
        super("Target Effects", "Orbs and orbit rings around the enemy you are fighting (needs line of sight, first person).", Category.COMBAT);
    }

    /** Projects a point on a circle of the given radius, tilted around the X axis, then spun around Y. */
    private static boolean orbitPoint(double cx, double cy, double cz, float r, float theta, float tilt, float spin) {
        float lx = r * (float) Math.cos(theta);
        float lz = r * (float) Math.sin(theta);
        float ly = lz * (float) Math.sin(tilt);
        lz = lz * (float) Math.cos(tilt);
        float cs = (float) Math.cos(spin), sn = (float) Math.sin(spin);
        float wx = lx * cs - lz * sn, wz = lx * sn + lz * cs;
        return WorldProjector.project(cx + wx, cy + ly, cz + wz);
    }

    private void orbitLine(GuiGraphics g, double cx, double cy, double cz, float r, float tilt, float spin, float th, int color, int n) {
        boolean have = false;
        float px = 0, py = 0;
        for (int i = 0; i <= n; i++) {
            boolean ok = orbitPoint(cx, cy, cz, r, (float) (i * 2.0 * Math.PI / n), tilt, spin);
            float x = WorldProjector.out[0], y = WorldProjector.out[1];
            if (ok && have) Lines.segment(g, px, py, x, y, th, color);
            have = ok; px = x; py = y;
        }
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        float a = TargetFocus.alpha(fade.asInt());
        if (a <= 0.01f || !WorldProjector.valid) return;
        float op = a * opacity.asFloat();
        boolean perf = performance.get();
        int n = Rings.quality(perf);
        double time = (System.currentTimeMillis() % 3600000L) / 1000.0;
        float dir = reverse.get() ? -1f : 1f;
        float ang = (float) (time * speed.asFloat() * 2.0 * dir);
        float r = orbitRadius.asFloat();
        double cx = TargetFocus.x, cz = TargetFocus.z;
        double cy = TargetFocus.y + TargetFocus.height * 0.5;
        Style st = style.get();

        int rc = Draw.alpha(ringColor.get(), op * 0.8f);
        int oc = Draw.alpha(orbColor.get(), op);
        float th = thickness.asFloat();

        if (showAccent.get()) {
            Rings.ring(g, TargetFocus.x, TargetFocus.y + 0.02, cz, r, ang * 0.5f, th, Draw.alpha(ringColor.get(), op * 0.6f), 0, false, true, n, 0);
        }

        int ringCount = st == Style.ORBIT_RINGS ? (perf ? 2 : 3) : 0;
        if (showRings.get() && ringCount > 0) {
            for (int k = 0; k < ringCount; k++) {
                float tilt = (float) (Math.PI / 3.0 * (k + 1) - 0.4);
                float spin = ang * 0.35f * (k % 2 == 0 ? 1 : -1) + k * 1.1f;
                orbitLine(g, cx, cy, cz, r * (1f - 0.08f * k), tilt, spin, th, rc, n);
            }
        }

        if (!showOrbs.get()) return;
        int count = switch (st) {
            case SINGLE_ORB -> 1;
            case ORBIT_RINGS -> Math.min(ringCount, Math.max(1, orbCount.asInt()));
            case MULTI_ORB -> orbCount.asInt();
        };
        if (perf) count = Math.min(count, 3);
        int size = orbSize.asInt();
        for (int i = 0; i < count; i++) {
            float theta, tilt, spin, rad = r;
            if (st == Style.ORBIT_RINGS) {
                tilt = (float) (Math.PI / 3.0 * (i + 1) - 0.4);
                spin = ang * 0.35f * (i % 2 == 0 ? 1 : -1) + i * 1.1f;
                theta = ang * 1.6f + i * 2.1f;
                rad = r * (1f - 0.08f * i);
            } else {
                tilt = 0.35f;
                spin = 0f;
                theta = ang + i * (float) (2.0 * Math.PI / count);
            }
            if (st == Style.MULTI_ORB && showLines.get() && i == 0) {
                orbitLine(g, cx, cy, cz, rad, tilt, spin, 1f, Draw.alpha(ringColor.get(), op * 0.35f), n);
            }
            if (!orbitPoint(cx, cy, cz, rad, theta, tilt, spin)) continue;
            int ox = Math.round(WorldProjector.out[0]), oy = Math.round(WorldProjector.out[1]);
            if (!perf) Lines.disc(g, ox, oy, size + 2, Draw.alpha(orbColor.get(), op * 0.25f));
            Lines.disc(g, ox, oy, size, oc);
            if (size >= 3) Lines.disc(g, ox, oy, Math.max(1, size / 2), Draw.alpha(0xFFFFFFFF, op * 0.8f));
            if (showLines.get() && st != Style.MULTI_ORB && !perf) {
                // short comet tail behind the orb along the orbit
                if (orbitPoint(cx, cy, cz, rad, theta - 0.25f * dir, tilt, spin)) {
                    Lines.segment(g, ox, oy, WorldProjector.out[0], WorldProjector.out[1], size * 0.8f, Draw.alpha(orbColor.get(), op * 0.4f));
                }
            }
        }
    }
}
