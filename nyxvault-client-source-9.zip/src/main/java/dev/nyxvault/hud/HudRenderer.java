package dev.nyxvault.hud;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.gui.HudEditorScreen;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.util.Notifications;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Draws enabled overlay modules and on-screen notifications each frame. */
public final class HudRenderer {
    private HudRenderer() { }

    public static void init() {
        HudRenderCallback.EVENT.register(HudRenderer::render);
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (mc.screen instanceof HudEditorScreen) return; // editor draws the elements itself
        try {
            dev.nyxvault.render.WorldProjector.update(mc);
            dev.nyxvault.visual.TargetFocus.update(mc, delta.getGameTimeDeltaPartialTick(true));
        } catch (Throwable t) {
            NyxvaultClient.LOGGER.error("Camera projection failed", t);
            return;
        }
        for (Module m : NyxvaultClient.modules().all()) {
            if (!(m instanceof OverlayModule o) || !m.enabled()) continue;
            try {
                o.renderOverlay(g, mc, delta);
            } catch (Throwable t) {
                NyxvaultClient.LOGGER.error("Overlay {} failed; disabling", m.name(), t);
                m.setEnabled(false);
            }
        }
        drawNotifications(g, mc);
    }

    private static void drawNotifications(GuiGraphics g, Minecraft mc) {
        Notifications.prune();
        List<Notifications.Entry> list = Notifications.active();
        if (list.isEmpty()) return;
        int cx = mc.getWindow().getGuiScaledWidth() / 2;
        int y = 30;
        long life = Notifications.lifetimeMs();
        for (Notifications.Entry e : list) {
            long age = System.currentTimeMillis() - e.createdMs();
            float in = UiSettings.animationIntensity <= 0f ? 1f : Math.min(1f, age / 180f);
            float out = Math.min(1f, (life - age) / 300f);
            float a = Math.max(0f, Math.min(in, out));
            int w = mc.font.width(e.text()) + 16;
            int x = cx - w / 2;
            int yy = y - Math.round((1f - in) * 8);
            Draw.round(g, x, yy, w, 16, Draw.alpha(UiSettings.theme.panel, a));
            Draw.border(g, x, yy, w, 16, Draw.alpha(UiSettings.accent(), a));
            g.drawString(mc.font, e.text(), x + 8, yy + 4, Draw.alpha(0xFFFFFFFF, a), true);
            y += 19;
        }
    }
}
