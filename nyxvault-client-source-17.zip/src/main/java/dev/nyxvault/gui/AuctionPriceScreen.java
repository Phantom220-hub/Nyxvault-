package dev.nyxvault.gui;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.player.AuctionSeller;
import dev.nyxvault.render.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Price prompt for Auction Seller: type the price by hand (digits only) or use the quick buttons,
 * then confirm. Drawn in a fixed virtual area scaled to the window so it fits phone screens.
 * Uses only the input events the other screens already use (key, codepoint, mouse x/y/button).
 */
public final class AuctionPriceScreen extends Screen {
    private static final int PW = 300, PH = 170;
    private static final long MAX = 2_000_000_000L;

    private final AuctionSeller module;
    private final String itemName;
    private final StringBuilder text = new StringBuilder();
    private boolean done;
    private float s = 1f, ox, oy;

    public AuctionPriceScreen(AuctionSeller module, String itemName, int currentPrice) {
        super(Component.literal("Цена"));
        this.module = module;
        this.itemName = itemName;
        text.append(currentPrice);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        if (!done) { done = true; module.cancelPrice(); }
        minecraft.setScreen(null);
    }

    private long value() {
        if (text.length() == 0) return 0;
        try { return Math.min(MAX, Long.parseLong(text.toString())); } catch (NumberFormatException e) { return MAX; }
    }

    private void add(long d) { set(Math.max(1, value() + d)); }
    private void set(long v) { text.setLength(0); text.append(Math.max(0, Math.min(MAX, v))); }

    private void confirm() {
        long v = value();
        if (v < 1) return;
        done = true;
        module.confirmPrice((int) v);
        minecraft.setScreen(null);
    }

    private void layout() {
        s = Math.max(0.5f, Math.min(2.5f, Math.min(width / (PW + 16f), height / (PH + 16f))));
        ox = (width - PW * s) / 2f;
        oy = (height - PH * s) / 2f;
    }

    private static boolean in(float mx, float my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void button(GuiGraphics g, float mx, float my, int x, int y, int w, int h, String label, int accent) {
        boolean hov = in(mx, my, x, y, w, h);
        Draw.round(g, x, y, w, h, hov ? 0xFF1B1B3A : UiSettings.theme.panel);
        Draw.border(g, x, y, w, h, accent);
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    private static String grouped(long v) {
        String r = Long.toString(v);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < r.length(); i++) {
            if (i > 0 && (r.length() - i) % 3 == 0) b.append(' ');
            b.append(r.charAt(i));
        }
        return b.toString();
    }

    private static final String[] QUICK_LABEL = { "-10к", "-1к", "+1к", "+10к", "+100к" };
    private static final long[] QUICK_VALUE = { -10_000, -1_000, 1_000, 10_000, 100_000 };

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        layout();
        float mx = (float) ((mouseX - ox) / s), my = (float) ((mouseY - oy) / s);
        g.fill(0, 0, width, height, 0xAA000000);
        g.pose().pushMatrix();
        g.pose().translate(ox, oy);
        g.pose().scale(s, s);
        int accent = UiSettings.accent();
        Draw.round(g, 0, 0, PW, PH, UiSettings.theme.background);
        Draw.border(g, 0, 0, PW, PH, accent);

        g.drawString(font, "Автопродажа на аукционе", 12, 10, 0xFFFFFFFF, true);
        g.drawString(font, "Предмет: " + itemName, 12, 26, 0xFF9CA3AF, true);
        g.drawString(font, "Цена за 1 штуку:", 12, 46, 0xFFFFFFFF, true);

        Draw.round(g, 12, 58, PW - 24, 22, 0xFF0B0B1A);
        Draw.border(g, 12, 58, PW - 24, 22, accent);
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        g.drawString(font, text + (caret ? "_" : ""), 18, 65, 0xFFFFFFFF, true);
        g.drawString(font, grouped(value()), PW - 18 - font.width(grouped(value())), 65, 0xFF9CA3AF, true);

        int bw = (PW - 24 - 4 * 4) / 5;
        for (int i = 0; i < QUICK_LABEL.length; i++) button(g, mx, my, 12 + i * (bw + 4), 90, bw, 18, QUICK_LABEL[i], accent);

        g.drawString(font, "Цифры с клавиатуры, Enter - старт, Esc - отмена", 12, 116, 0xFF6B7280, true);
        button(g, mx, my, 12, 138, 130, 22, "Старт", accent);
        button(g, mx, my, PW - 12 - 130, 138, 130, 22, "Отмена", 0xFF6B7280);
        g.pose().popMatrix();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = (float) ((event.x() - ox) / s), my = (float) ((event.y() - oy) / s);
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        int bw = (PW - 24 - 4 * 4) / 5;
        for (int i = 0; i < QUICK_VALUE.length; i++) {
            if (in(mx, my, 12 + i * (bw + 4), 90, bw, 18)) { add(QUICK_VALUE[i]); return true; }
        }
        if (in(mx, my, 12, 138, 130, 22)) { confirm(); return true; }
        if (in(mx, my, PW - 12 - 130, 138, 130, 22)) { onClose(); return true; }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { confirm(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (text.length() > 0) text.setLength(text.length() - 1);
            return true;
        }
        return true; // swallow other keys so they never reach gameplay
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if (cp >= '0' && cp <= '9' && text.length() < 10) {
            if (text.length() == 1 && text.charAt(0) == '0') text.setLength(0);
            text.append((char) cp);
            if (value() >= MAX) set(MAX);
        }
        return true;
    }
}
