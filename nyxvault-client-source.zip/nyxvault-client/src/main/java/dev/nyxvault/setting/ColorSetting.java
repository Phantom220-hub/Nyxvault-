package dev.nyxvault.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** ARGB color setting. GUI click cycles through presets. */
public final class ColorSetting extends Setting<Integer> {
    public static final int[] PRESETS = {
            0xFFA855F7, // purple
            0xFF3B82F6, // blue
            0xFF22D3EE, // cyan
            0xFF22C55E, // green
            0xFFEAB308, // yellow
            0xFFEF4444, // red
            0xFFFFFFFF  // white
    };

    public ColorSetting(String name, int argb) { super(name, argb); }

    @Override public JsonElement toJson() { return new JsonPrimitive(String.format("#%08X", value)); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        String s = e.getAsString().trim();
        if (s.startsWith("#")) s = s.substring(1);
        try {
            long v = Long.parseLong(s, 16);
            if (s.length() == 6) v |= 0xFF000000L;
            else if (s.length() != 8) return;
            value = (int) v;
        } catch (NumberFormatException ignored) { }
    }

    @Override public String display() { return String.format("#%06X", value & 0xFFFFFF); }

    @Override public void interact(int direction) {
        int idx = -1;
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == value) { idx = i; break; }
        idx = (idx + direction + PRESETS.length) % PRESETS.length;
        value = PRESETS[idx];
    }
}
