package dev.nyxvault.gui;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * HUD editor. Drag elements, scroll over one to change its scale, right-click to enable/disable,
 * press R to reset positions. Input here never reaches gameplay because this is a Screen.
 */
public final class HudEditorScreen extends Screen {
    private HudModule dragging;
    private int grabDx, grabDy;

    public HudEditorScreen() { super(Component.literal("NYXVAULT HUD Editor")); }

    @Override public boolean isPauseScreen() { return false; }

    private List<HudModule> elements() {
        List<HudModule> l = new ArrayList<>();
        for (Module m : NyxvaultClient.modules().all()) if (m instanceof HudModule h) l.add(h);
        return l;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x66000000);
        g.drawCenteredString(font, "HUD EDITOR  -  drag: move | scroll: scale | right-click: on/off | R: reset | ESC: save & close",
                width / 2, 6, 0xFFFFFFFF);
        for (HudModule h : elements()) {
            int[] b = h.bounds(minecraft);
            if (h.enabled()) {
                h.renderOverlay(g, minecraft, minecraft.getDeltaTracker());
            } else {
                Draw.round(g, b[0], b[1], b[2], b[3], 0x33FFFFFF);
                g.drawString(font, h.name() + " (off)", b[0] + 2, b[1] + 2, 0xFF9CA3AF, false);
            }
            boolean hover = mouseX >= b[0] && mouseX < b[0] + b[2] && mouseY >= b[1] && mouseY < b[1] + b[3];
            Draw.border(g, b[0] - 1, b[1] - 1, b[2] + 2, b[3] + 2,
                    h == dragging ? UiSettings.accent() : hover ? UiSettings.secondary() : 0x55FFFFFF);
        }
    }

    private HudModule at(double mx, double my) {
        List<HudModule> l = elements();
        for (int i = l.size() - 1; i >= 0; i--) {
            int[] b = l.get(i).bounds(minecraft);
            if (mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3]) return l.get(i);
        }
        return null;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        HudModule h = at(event.x(), event.y());
        if (h == null) return super.mouseClicked(event, doubleClick);
        if (event.button() == 1) {
            h.toggle();
            ConfigManager.requestSave();
        } else if (event.button() == 0) {
            int[] b = h.bounds(minecraft);
            dragging = h;
            grabDx = (int) event.x() - b[0];
            grabDy = (int) event.y() - b[1];
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging == null) return false;
        dragging.moveTo(minecraft, (int) event.x() - grabDx, (int) event.y() - grabDy);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            ConfigManager.requestSave();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        HudModule h = at(mouseX, mouseY);
        if (h == null) return false;
        h.scale.interact(scrollY > 0 ? 1 : -1);
        h.moveTo(minecraft, h.x.asInt(), h.y.asInt()); // re-clamp so it stays reachable
        ConfigManager.requestSave();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_R) {
            for (HudModule h : elements()) { h.x.reset(); h.y.reset(); h.scale.reset(); h.moveTo(minecraft, h.x.asInt(), h.y.asInt()); }
            ConfigManager.requestSave();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override public void removed() {
        ConfigManager.save();
        super.removed();
    }
}
