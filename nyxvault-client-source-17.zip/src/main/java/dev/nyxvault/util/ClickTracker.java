package dev.nyxvault.util;

import net.minecraft.client.Minecraft;

/** Tracks physical mouse presses to compute CPS. Polled once per client tick. */
public final class ClickTracker {
    private static final long[] left = new long[64];
    private static final long[] right = new long[64];
    private static int leftHead, rightHead;
    private static boolean leftDown, rightDown;
    /** Timestamp (ms) of the last confirmed local attack click, for UI. */
    public static volatile long lastLeftMs;

    private ClickTracker() { }

    public static void tick(Minecraft mc) {
        boolean l = mc.mouseHandler.isLeftPressed();
        boolean r = mc.mouseHandler.isRightPressed();
        long now = System.currentTimeMillis();
        if (l && !leftDown) { left[leftHead++ & 63] = now; lastLeftMs = now; }
        if (r && !rightDown) { right[rightHead++ & 63] = now; }
        leftDown = l;
        rightDown = r;
    }

    /** Count a synthetic click (used by AutoClicker so CPS shows real output). */
    public static void recordLeft() { left[leftHead++ & 63] = System.currentTimeMillis(); }
    public static void recordRight() { right[rightHead++ & 63] = System.currentTimeMillis(); }

    public static int leftCps() { return count(left); }
    public static int rightCps() { return count(right); }

    private static int count(long[] arr) {
        long now = System.currentTimeMillis();
        int c = 0;
        for (long t : arr) if (t != 0 && now - t <= 1000) c++;
        return c;
    }
}
