package dev.nyxvault.hud;

import dev.nyxvault.util.Lang;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.ClickTracker;
import dev.nyxvault.waypoint.Waypoint;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** All draggable HUD elements. Each is a small, self-contained class. */
public final class HudModules {
    private HudModules() { }

    private static final int WHITE = 0xFFFFFFFF;

    /** Base for single-line text elements with a rounded dark background. */
    abstract static class TextElement extends HudModule {
        protected TextElement(String name, String desc, int x, int y) { super(name, desc, Category.HUD, x, y); }

        protected abstract String text(Minecraft mc);

        @Override public int width(Minecraft mc) { return mc.font.width(text(mc)) + 10; }
        @Override public int height(Minecraft mc) { return 14; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            int w = width(mc), h = height(mc);
            Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
            g.fill(0, 2, 2, h - 2, a(UiSettings.accent()));
            g.drawString(mc.font, text(mc), 6, 3, a(WHITE), true);
        }
    }

    public static final class Watermark extends TextElement {
        public Watermark() { super("Watermark", "Shows the NYXVAULT watermark.", 4, 4); }
        @Override protected String text(Minecraft mc) { return "NYXVAULT CLIENT"; }
    }

    public static final class Fps extends TextElement {
        public Fps() { super("FPS", "FPS and approximate frame time.", 4, 22); }
        @Override protected String text(Minecraft mc) {
            int fps = Math.max(1, mc.getFps());
            return fps + " FPS  (" + String.format("%.1f", 1000f / fps) + " " + Lang.t("ms") + ")";
        }
    }

    public static final class Coordinates extends TextElement {
        public Coordinates() { super("Coordinates", "Coordinates and facing direction.", 4, 40); }
        @Override protected String text(Minecraft mc) {
            return String.format("XYZ %.1f %.1f %.1f  %s", mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    Lang.t(mc.player.getDirection().getName()));
        }
    }

    public static final class Cps extends TextElement {
        public Cps() { super("CPS", "Clicks per second (physical mouse presses).", 4, 58); }
        @Override protected String text(Minecraft mc) {
            return "CPS " + ClickTracker.leftCps() + " | " + ClickTracker.rightCps();
        }
    }

    public static final class Ping extends TextElement {
        public Ping() { super("Ping", "Latency reported by the server.", 4, 76); }
        @Override protected String text(Minecraft mc) {
            if (mc.getConnection() == null) return Lang.t("Ping: n/a");
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            return info == null ? Lang.t("Ping: n/a") : Lang.t("Ping") + " " + info.getLatency() + " " + Lang.t("ms");
        }
    }

    public static final class SessionTimer extends TextElement {
        private final long start = System.currentTimeMillis();
        public SessionTimer() { super("Session Timer", "Elapsed time since the game started.", 4, 94); }
        @Override protected String text(Minecraft mc) {
            long s = (System.currentTimeMillis() - start) / 1000;
            return String.format(Lang.t("Session") + " %02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        }
    }

    public static final class NetherCoords extends TextElement {
        public NetherCoords() { super("Nether Coords", "Coordinates in the other dimension (Overworld / 8, Nether x 8).", 4, 76); }
        @Override protected String text(Minecraft mc) {
            String dim = mc.level.dimension().toString();
            double x = mc.player.getX(), z = mc.player.getZ();
            if (dim.contains("the_nether")) return String.format(Lang.t("Overworld") + " %.0f %.0f", x * 8, z * 8);
            if (dim.contains("overworld")) return String.format(Lang.t("Nether") + " %.0f %.0f", x / 8, z / 8);
            return Lang.t("No conversion here");
        }
    }

    public static final class WaypointHud extends TextElement {
        public WaypointHud() { super("Waypoint HUD", "Distance, coordinates and direction of the active waypoint.", 4, 112); }
        @Override protected String text(Minecraft mc) {
            Waypoint w = NyxvaultClient.waypoints().active();
            if (w == null) return Lang.t("No active waypoint");
            if (!w.dimension.equals(mc.level.dimension().toString())) return w.name + Lang.t(": other dimension");
            double d = w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            return String.format("%s  %.0f" + Lang.t("m") + "  (%d, %d, %d) %s", w.name, d, (int) w.x, (int) w.y, (int) w.z,
                    w.arrow(mc.player.getX(), mc.player.getZ(), mc.player.getYRot()));
        }
    }

    public static final class Keystrokes extends HudModule {
        public Keystrokes() { super("Keystrokes", "WASD, jump and mouse buttons.", Category.HUD, 4, 140); }
        @Override public int width(Minecraft mc) { return 70; }
        @Override public int height(Minecraft mc) { return 62; }

        private void key(GuiGraphics g, Minecraft mc, int x, int y, int w, String label, boolean down) {
            int bg = down ? Draw.alpha(UiSettings.accent(), 0.8f * opacity.asFloat()) : a(UiSettings.theme.background);
            Draw.round(g, x, y, w, 14, bg);
            g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + 3, a(WHITE), true);
        }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            var o = mc.options;
            key(g, mc, 24, 0, 22, "W", o.keyUp.isDown());
            key(g, mc, 0, 16, 22, "A", o.keyLeft.isDown());
            key(g, mc, 24, 16, 22, "S", o.keyDown.isDown());
            key(g, mc, 48, 16, 22, "D", o.keyRight.isDown());
            key(g, mc, 0, 32, 34, Lang.t("LMB"), o.keyAttack.isDown());
            key(g, mc, 36, 32, 34, Lang.t("RMB"), o.keyUse.isDown());
            key(g, mc, 0, 48, 70, Lang.t("SPACE"), o.keyJump.isDown());
        }
    }

    public static final class ArmorHud extends HudModule {
        private final BoolSetting durability = add(new BoolSetting("Show Durability", true));
        private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

        public ArmorHud() { super("Armor HUD", "Equipped armor with durability.", Category.HUD, 4, 210); }
        @Override public int width(Minecraft mc) { return durability.get() ? 48 : 18; }
        @Override public int height(Minecraft mc) { return 68; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            Draw.round(g, 0, 0, width(mc), height(mc), a(UiSettings.theme.background));
            for (int i = 0; i < 4; i++) {
                ItemStack st = mc.player.getItemBySlot(SLOTS[i]);
                if (st.isEmpty()) continue;
                g.renderItem(st, 1, 1 + i * 17);
                if (durability.get() && st.isDamageableItem()) {
                    int left = st.getMaxDamage() - st.getDamageValue();
                    g.drawString(mc.font, Integer.toString(left), 19, 5 + i * 17, a(WHITE), true);
                }
            }
        }
    }

    public static final class PotionHud extends HudModule {
        public PotionHud() { super("Potion HUD", "Active potion effects with timers.", Category.HUD, 4, 282); }

        private List<String> lines(Minecraft mc) {
            List<String> out = new ArrayList<>();
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                String n = e.getEffect().value().getDisplayName().getString();
                int amp = e.getAmplifier() + 1;
                String t;
                if (e.isInfiniteDuration()) t = Lang.t("inf");
                else { int s = e.getDuration() / 20; t = String.format("%d:%02d", s / 60, s % 60); }
                out.add(n + (amp > 1 ? " " + amp : "") + "  " + t);
            }
            return out;
        }

        @Override public int width(Minecraft mc) {
            int w = 60;
            for (String s : lines(mc)) w = Math.max(w, mc.font.width(s) + 10);
            return w;
        }
        @Override public int height(Minecraft mc) { return Math.max(1, lines(mc).size()) * 12 + 4; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            Draw.round(g, 0, 0, width(mc), height(mc), a(UiSettings.theme.background));
            List<String> l = lines(mc);
            if (l.isEmpty()) { g.drawString(mc.font, Lang.t("No effects"), 5, 4, a(0xFF9CA3AF), true); return; }
            for (int i = 0; i < l.size(); i++) g.drawString(mc.font, l.get(i), 5, 4 + i * 12, a(WHITE), true);
        }
    }

    /** Lists enabled modules with smooth enter/exit transitions. */
    public static final class ModuleList extends HudModule {
        public enum Align { RIGHT, LEFT }

        private static final Comparator<Module> BY_LENGTH = Comparator.comparingInt((Module m) -> Lang.module(m).length()).reversed();
        private final EnumSetting<Align> align = add(new EnumSetting<>("Alignment", Align.RIGHT));
        private final NumberSetting spacing = add(NumberSetting.integer("Spacing", 1, 0, 6));
        private final BoolSetting accentBar = add(new BoolSetting("Accent Bar", true));
        private final List<Module> cache = new ArrayList<>();
        private int maxW = 60;
        private long lastNanos = System.nanoTime();

        public ModuleList() { super("Module List", "Lists enabled modules with smooth transitions.", Category.HUD, 700, 4); }

        private int rowH() { return 11 + spacing.asInt(); }

        /** Advances per-module animations and rebuilds the visible list once per frame. */
        private void refresh(Minecraft mc) {
            long now = System.nanoTime();
            float dt = Math.min(0.1f, (now - lastNanos) / 1e9f);
            lastNanos = now;
            cache.clear();
            int w = 60;
            for (Module m : NyxvaultClient.modules().all()) {
                if (m == this) continue;
                float tgt = m.enabled() ? 1f : 0f;
                m.listAnim = UiSettings.animationIntensity <= 0f ? tgt
                        : Draw.approach(m.listAnim, tgt, 14f * Math.max(0.25f, UiSettings.animationSpeed), dt);
                if (Math.abs(m.listAnim - tgt) < 0.01f) m.listAnim = tgt;
                if (m.listAnim > 0.02f) {
                    cache.add(m);
                    w = Math.max(w, mc.font.width(Lang.module(m)) + 10);
                }
            }
            cache.sort(BY_LENGTH);
            maxW = w;
        }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, net.minecraft.client.DeltaTracker delta) {
            refresh(mc);
            super.renderOverlay(g, mc, delta);
        }

        @Override public int width(Minecraft mc) { return maxW; }
        @Override public int height(Minecraft mc) { return Math.max(1, cache.size()) * rowH() + 2; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            boolean right = align.get() == Align.RIGHT;
            int rh = rowH();
            for (int i = 0; i < cache.size(); i++) {
                Module m = cache.get(i);
                float an = m.listAnim;
                String n = Lang.module(m);
                int tw = mc.font.width(n);
                int slide = Math.round((1f - an) * (tw + 12));
                int y = 1 + i * rh;
                int bg = Draw.alpha(a(UiSettings.theme.background), an);
                int tc = Draw.alpha(a(WHITE), an);
                int ac = Draw.alpha(a(UiSettings.accent()), an);
                if (right) {
                    int x1 = maxW + slide, x0 = x1 - tw - 8;
                    g.fill(x0, y, x1, y + 11, bg);
                    if (accentBar.get()) g.fill(x1 - 2, y, x1, y + 11, ac);
                    g.drawString(mc.font, n, x0 + 3, y + 2, tc, true);
                } else {
                    int x0 = -slide, x1 = x0 + tw + 8;
                    g.fill(x0, y, x1, y + 11, bg);
                    if (accentBar.get()) g.fill(x0, y, x0 + 2, y + 11, ac);
                    g.drawString(mc.font, n, x0 + 5, y + 2, tc, true);
                }
            }
        }
    }
}
