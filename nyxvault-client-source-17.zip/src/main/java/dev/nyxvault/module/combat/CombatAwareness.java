package dev.nyxvault.module.combat;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Indicators;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Information about the player you are LOOKING at (you aim and attack yourself). No auto aim, no
 * attacks, no target lock: it only remembers who your crosshair last pointed at for a few seconds.
 */
public final class CombatAwareness extends HudModule {
    private final BoolSetting showDistance = add(new BoolSetting("Show Distance", true));
    private final BoolSetting showHealth = add(new BoolSetting("Show Health", true));
    private final BoolSetting showMovement = add(new BoolSetting("Show Movement", true));
    private final BoolSetting offscreen = add(new BoolSetting("Off-screen Indicator", true));
    private final ColorSetting color = add(new ColorSetting("Color", 0xFF22D3EE));
    private final NumberSetting indicatorSize = add(NumberSetting.integer("Indicator Size", 8, 4, 20));
    private final NumberSetting hold = add(NumberSetting.decimal("Hold Time (s)", 3.0, 1.0, 10.0, 0.5));

    private Player tracked;
    private long seenMs;

    public CombatAwareness() {
        super("Combat Awareness", "Info about the player you are looking at: distance, health, movement, off-screen arrow. No aiming or attacks.", Category.COMBAT, 300, 150);
    }

    @Override protected void onDisable() { tracked = null; }
    @Override public void onWorldChange() { tracked = null; }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) { tracked = null; return; }
        long now = System.currentTimeMillis();
        if (mc.hitResult instanceof EntityHitResult h && h.getEntity() instanceof Player pl && pl != mc.player) {
            tracked = pl; seenMs = now;
        }
        if (tracked != null && (!tracked.isAlive() || tracked.level() != mc.level || now - seenMs > hold.get() * 1000.0)) tracked = null;
    }

    @Override public int width(Minecraft mc) { return 128; }
    @Override public int height(Minecraft mc) { return 14 + (showDistance.get() ? 11 : 0) + (showHealth.get() ? 11 : 0) + (showMovement.get() ? 11 : 0); }

    private static String arrow(double mx, double mz, float yaw) {
        double angle = Math.toDegrees(Math.atan2(-mx, mz));
        double rel = ((angle - yaw) % 360 + 540) % 360 - 180;
        String[] a = {"вперёд", "вперёд-вправо", "вправо", "назад-вправо", "назад", "назад-влево", "влево", "вперёд-влево"};
        return a[(((int) Math.round(rel / 45.0)) % 8 + 8) % 8];
    }

    @Override protected void draw(GuiGraphics g, Minecraft mc) {
        Player t = tracked;
        int w = width(mc), h = height(mc);
        if (t == null) {
            if (!HudModule.editing) return;
            Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
            Draw.border(g, 0, 0, w, h, a(0xFF4B5563));
            g.drawString(mc.font, "Нет игрока в прицеле", 6, 4, a(0xFF9CA3AF), true);
            return;
        }
        int c = color.get();
        Draw.round(g, 0, 0, w, h, a(UiSettings.theme.background));
        Draw.border(g, 0, 0, w, h, a(c));
        g.drawString(mc.font, mc.font.plainSubstrByWidth(t.getName().getString(), w - 10), 5, 3, a(0xFFFFFFFF), true);
        int y = 14;
        if (showDistance.get()) { g.drawString(mc.font, String.format("Дистанция: %.1f м", mc.player.distanceTo(t)), 5, y, a(0xFFD1D5DB), true); y += 11; }
        if (showHealth.get()) {
            float hp = t.getHealth() + t.getAbsorptionAmount();
            g.drawString(mc.font, String.format("Здоровье: %.1f / %.0f", hp, t.getMaxHealth()), 5, y, a(hp <= 6f ? 0xFFEF4444 : 0xFFD1D5DB), true); y += 11;
        }
        if (showMovement.get()) {
            double mx = t.getX() - t.xo, mz = t.getZ() - t.zo;
            String m = mx * mx + mz * mz < 0.0004 ? "стоит" : arrow(mx, mz, mc.player.getYRot());
            g.drawString(mc.font, "Движется: " + m, 5, y, a(0xFFD1D5DB), true);
        }
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        super.renderOverlay(g, mc, delta);
        Player t = tracked;
        if (!offscreen.get() || t == null || mc.player == null) return;
        boolean on = WorldProjector.valid
                && WorldProjector.project(t.getX(), t.getY() + t.getBbHeight() * 0.5, t.getZ()) && WorldProjector.onScreen(0f);
        if (!on) {
            Indicators.edge(g, mc, t.getX() - mc.player.getX(), t.getZ() - mc.player.getZ(),
                    Draw.alpha(color.get(), opacity.asFloat()), indicatorSize.asInt());
        }
    }
}
