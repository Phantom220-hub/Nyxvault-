package dev.nyxvault.module;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.hud.ExtraHudModules;
import dev.nyxvault.hud.HudModules;
import dev.nyxvault.hud.WorldOverlays;
import dev.nyxvault.module.combat.TotemModules;
import dev.nyxvault.module.player.UtilityModules;
import dev.nyxvault.visual.Trails;
import dev.nyxvault.module.combat.CombatModules;
import dev.nyxvault.module.misc.InterfaceModule;
import dev.nyxvault.module.player.PlayerModules;
import dev.nyxvault.module.world.WaypointsModule;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Registry of all modules; polls module keybinds and drives per-tick logic. */
public final class ModuleManager {
    private final Map<String, Module> byName = new LinkedHashMap<>();
    private final boolean[] keyState = new boolean[512];
    private Object lastLevel;
    public final WaypointsModule waypointsModule = new WaypointsModule();
    public final InterfaceModule interfaceModule = new InterfaceModule();

    public ModuleManager() {
        // Combat
        register(new CombatModules.Crosshair());
        register(new CombatModules.HitMarker());
        register(new CombatModules.TargetHud());
        register(new Trails.WeaponTrail());
        register(new dev.nyxvault.visual.TargetCircle());
        register(new dev.nyxvault.visual.TargetEffects());
        register(new dev.nyxvault.module.combat.HitEffects());
        register(new TotemModules.AutoTotem());
        register(new dev.nyxvault.module.combat.AutoAttack());
        // Visuals
        register(new PlayerModules.Brightness());
        register(new Trails.MotionTrail());
        register(new dev.nyxvault.visual.JumpCircle());
        register(new WorldOverlays.DamageFlash());
        // Movement
        register(new PlayerModules.AutoSprint());
        register(new dev.nyxvault.module.player.AutoBridge());
        // Player
        register(new UtilityModules.ResourceAlerts());
        register(new UtilityModules.HealthAlert());
        register(new dev.nyxvault.module.player.PlayerAlert());
        // HUD
        register(new HudModules.Watermark());
        register(new HudModules.Fps());
        register(new HudModules.Coordinates());
        register(new HudModules.NetherCoords());
        register(new HudModules.Cps());
        register(new HudModules.Ping());
        register(new HudModules.SessionTimer());
        register(new HudModules.Keystrokes());
        register(new HudModules.ArmorHud());
        register(new HudModules.PotionHud());
        register(new HudModules.ModuleList());
        register(new HudModules.WaypointHud());
        register(new ExtraHudModules.TotemHud());
        register(new ExtraHudModules.PopCounter());
        register(new ExtraHudModules.CombatHud());
        register(new ExtraHudModules.PlayerInfo());
        register(new ExtraHudModules.SessionStatsHud());
        register(new ExtraHudModules.CompassHud());
        register(new ExtraHudModules.ClockHud());
        register(new ExtraHudModules.TargetBlockHud());
        register(new ExtraHudModules.LightLevelHud());
        register(new ExtraHudModules.NearbyPlayers());
        register(new ExtraHudModules.ItemCounter());
        // World
        register(waypointsModule);
        register(new WorldOverlays.WaypointMarkers());
        register(new WorldOverlays.TntCountdown());
        register(new UtilityModules.DeathWaypoint());
        // Utilities
        register(new PlayerModules.AutoClicker());
        // Settings
        register(interfaceModule);
    }

    private void register(Module m) { byName.put(m.name(), m); }

    public List<Module> all() { return Collections.unmodifiableList(new ArrayList<>(byName.values())); }
    public Module get(String name) { return byName.get(name); }

    public List<Module> inCategory(Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : byName.values()) if (m.category() == c) l.add(m);
        return l;
    }

    public List<Module> search(String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        List<Module> l = new ArrayList<>();
        for (Module m : byName.values()) {
            if (dev.nyxvault.util.Lang.matches(m, q)) l.add(m);
        }
        return l;
    }

    /** Returns the other module already using this key, or null. */
    public Module keyConflict(Module self, int key) {
        if (key < 0) return null;
        for (Module m : byName.values()) if (m != self && m.key() == key) return m;
        return null;
    }

    public void panic() {
        int n = 0;
        for (Module m : byName.values()) {
            if (m.enabled() && m.panicEligible()) { m.setEnabled(false); n++; }
        }
        dev.nyxvault.util.Notifications.push(dev.nyxvault.util.Lang.t("PANIC: ") + n + dev.nyxvault.util.Lang.t(" module(s) disabled"));
        ConfigManager.requestSave();
    }

    public void tick(Minecraft mc) {
        Object lvl = mc.level;
        if (lvl != lastLevel) { // join / dimension change / disconnect: drop cached visual state
            lastLevel = lvl;
            for (Module m : byName.values()) {
                try { m.onWorldChange(); } catch (Throwable t) { NyxvaultClient.LOGGER.error("onWorldChange failed in {}", m.name(), t); }
            }
            dev.nyxvault.visual.TargetFocus.reset();
        }
        // Keybind polling (only without an open screen so typing never toggles modules).
        if (mc.screen == null && mc.player != null) {
            for (Module m : byName.values()) {
                int k = m.key();
                if (k < 0 || k >= keyState.length) continue;
                boolean down = InputConstants.isKeyDown(mc.getWindow(), k);
                if (down && !keyState[k]) { m.toggle(); ConfigManager.requestSave(); }
                keyState[k] = down;
            }
        }
        interfaceModule.onTick();
        waypointsModule.onTick();
        if (mc.player == null) return;
        for (Module m : byName.values()) {
            if (!m.enabled() || m == interfaceModule || m == waypointsModule) continue;
            try {
                m.onTick();
            } catch (Throwable t) {
                NyxvaultClient.LOGGER.error("Module {} crashed in tick; disabling it", m.name(), t);
                m.setEnabled(false);
            }
        }
    }
}
