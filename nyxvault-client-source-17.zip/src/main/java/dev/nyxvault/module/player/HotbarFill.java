package dev.nyxvault.module.player;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Spreads the item type you hold across the empty hotbar slots, N per slot (default 1), using
 * ordinary inventory clicks one at a time (pick up the stack, right-click each empty slot, put the
 * rest back). Switch the module on (or press its key) to run it once; it turns itself off when done.
 * It uses the biggest single stack of that item, never touches occupied slots, and aborts if a
 * container/other screen takes over. Servers may restrict automated inventory clicks.
 */
public final class HotbarFill extends Module {
    private final NumberSetting perSlot = add(NumberSetting.integer("Items Per Slot", 1, 1, 4));
    private final NumberSetting delay = add(NumberSetting.integer("Delay (ticks)", 2, 1, 10));

    private final int[] opSlot = new int[64];
    private final int[] opBtn = new int[64];
    private int n, idx, cooldown, waited, src = -1;
    private boolean started;

    public HotbarFill() {
        super("Hotbar Fill", "Spreads the held item across empty hotbar slots, one per slot. Turn on to run once. Check server rules.", Category.PLAYER);
    }

    @Override protected void onEnable() { n = 0; idx = 0; cooldown = 0; waited = 0; started = false; src = -1; }

    @Override protected void onDisable() {
        // If we stopped halfway, put the carried stack back so nothing stays on the cursor.
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (started && p != null && mc.gameMode != null && p.containerMenu == p.inventoryMenu
                && !p.containerMenu.getCarried().isEmpty() && src >= 0) {
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, src, 0, ClickType.PICKUP, p);
        }
        started = false;
    }

    private void op(int slot, int button) {
        if (n < opSlot.length) { opSlot[n] = slot; opBtn[n] = button; n++; }
    }

    /** Builds the click list. Returns false (with a message) when there is nothing sensible to do. */
    private boolean plan(Player p) {
        ItemStack held = p.getMainHandItem();
        if (held.isEmpty()) { Notifications.push("Возьмите предмет в руку"); return false; }
        Item item = held.getItem();
        Inventory inv = p.getInventory();
        int best = -1, bestCnt = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() == item && s.getCount() > bestCnt) { best = i; bestCnt = s.getCount(); }
        }
        if (best < 0) { Notifications.push("Предмет не найден"); return false; }
        if (bestCnt < 2) { Notifications.push("Нужна стопка больше одной штуки"); return false; }
        src = best < 9 ? 36 + best : best;
        n = 0; idx = 0;
        op(src, 0); // pick the whole stack up
        int remaining = bestCnt, filled = 0;
        for (int h = 0; h < 9 && remaining > 0; h++) {
            boolean target = h == best || inv.getItem(h).isEmpty();
            if (!target) continue;
            for (int k = 0; k < perSlot.asInt() && remaining > 0; k++) { op(36 + h, 1); remaining--; }
            filled++;
        }
        if (filled == 0) { Notifications.push("Нет пустых ячеек на панели"); n = 0; return false; }
        if (remaining > 0) op(src, 0); // put the rest back
        Notifications.push("Заполнение панели: " + held.getHoverName().getString());
        return true;
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.gameMode == null) return;
        if (!started) {
            if (++waited > 200) { Notifications.push("Заполнение панели отменено"); setEnabled(false); return; }
            if (mc.screen != null && !(mc.screen instanceof InventoryScreen)) return; // wait until the menu is closed
            if (!plan(p)) { setEnabled(false); return; }
            started = true;
            return;
        }
        if (p.containerMenu != p.inventoryMenu) { setEnabled(false); return; }
        if (cooldown > 0) { cooldown--; return; }
        if (idx >= n) { setEnabled(false); return; }
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, opSlot[idx], opBtn[idx], ClickType.PICKUP, p);
        idx++;
        cooldown = delay.asInt() - 1;
    }
}
