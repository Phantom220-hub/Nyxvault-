package dev.nyxvault.gui;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.util.Notifications;
import dev.nyxvault.waypoint.Waypoint;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

/**
 * "Метки мира": list, add/edit form and delete confirmation for waypoints.
 * Everything is drawn in a fixed virtual 420x250 area scaled to the window, so it fits phone screens
 * (Android launchers). Text fields are minimal custom controls that use only the input events the
 * Click GUI already uses (key, codepoint, mouse x/y/button).
 */
public final class WaypointScreen extends Screen {
    /** Set by "/nyx wp gui"; the client tick opens the screen once the chat screen has closed. */
    public static volatile boolean pendingOpen;

    private enum Mode { LIST, EDIT, CONFIRM }

    private static final int PW = 420, PH = 250;
    private static final int ROW_H = 30;

    private final Screen parent;
    private Mode mode = Mode.LIST;
    private float s = 1f, ox, oy;

    // list
    private float scroll, scrollTarget;
    private boolean sortByDistance;
    private int dragY = Integer.MIN_VALUE;

    // edit
    private Waypoint editing;      // null = new
    private final StringBuilder[] fields = { new StringBuilder(), new StringBuilder(), new StringBuilder(), new StringBuilder() };
    private int focus;             // 0 name, 1 x, 2 y, 3 z
    private int editColor = ColorSetting.PRESETS[0];
    private boolean editAuto;
    private String error = "";

    // confirm
    private Waypoint toDelete;

    public WaypointScreen(Screen parent) {
        super(Component.literal("Метки мира"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        ConfigManager.save();
        minecraft.setScreen(parent);
    }

    @Override public void removed() {
        ConfigManager.save();
        super.removed();
    }

    // ------------------------------------------------------------------ helpers

    private void layout() {
        s = Math.max(0.5f, Math.min(2.5f, Math.min(width / (PW + 16f), height / (PH + 16f))));
        ox = (width - PW * s) / 2f;
        oy = (height - PH * s) / 2f;
    }

    private float vx(double mx) { return (float) ((mx - ox) / s); }
    private float vy(double my) { return (float) ((my - oy) / s); }
    private static boolean in(float mx, float my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private static String fmt(double d) {
        return d == Math.rint(d) ? Long.toString((long) d) : String.format(Locale.ROOT, "%.1f", d);
    }

    private List<Waypoint> list() { return NyxvaultClient.waypoints().search("", sortByDistance); }

    private void button(GuiGraphics g, float mx, float my, int x, int y, int w, int h, String text, int accent) {
        boolean hov = in(mx, my, x, y, w, h);
        Draw.round(g, x, y, w, h, hov ? 0xFF1B1B3A : UiSettings.theme.panel);
        Draw.border(g, x, y, w, h, accent);
        g.drawString(font, text, x + (w - font.width(text)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    private String trim(String t, int maxW) {
        if (font.width(t) <= maxW) return t;
        String r = t;
        while (r.length() > 1 && font.width(r + "..") > maxW) r = r.substring(0, r.length() - 1);
        return r + "..";
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        layout();
        float mx = vx(mouseX), my = vy(mouseY);
        g.fill(0, 0, width, height, 0xAA000000);
        g.pose().pushMatrix();
        g.pose().translate(ox, oy);
        g.pose().scale(s, s);
        int accent = UiSettings.accent();
        Draw.round(g, 0, 0, PW, PH, UiSettings.theme.background);
        Draw.border(g, 0, 0, PW, PH, accent);

        smoothScroll();
        switch (mode) {
            case LIST -> drawList(g, mx, my, accent);
            case EDIT -> drawEdit(g, mx, my, accent);
            case CONFIRM -> { drawList(g, -1000, -1000, accent); drawConfirm(g, mx, my, accent); }
        }
        g.pose().popMatrix();
    }

    private void smoothScroll() {
        float max = Math.max(0, list().size() * ROW_H - 170);
        scrollTarget = Math.max(0, Math.min(max, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35f;
        if (Math.abs(scroll - scrollTarget) < 0.3f) scroll = scrollTarget;
    }

    private void drawList(GuiGraphics g, float mx, float my, int accent) {
        g.drawString(font, "Метки мира", 12, 10, 0xFFFFFFFF, true);
        List<Waypoint> all = list();
        g.drawString(font, "(" + all.size() + ")", 12 + font.width("Метки мира") + 6, 10, 0xFF9CA3AF, true);
        button(g, mx, my, 150, 6, 88, 18, "+ Добавить", accent);
        button(g, mx, my, 244, 6, 92, 18, sortByDistance ? "Сорт.: дистанция" : "Сорт.: имя", 0xFF374151);
        button(g, mx, my, 342, 6, 70, 18, "Закрыть", 0xFFEF4444);

        int top = 32, vh = 170;
        g.enableScissor(Math.round(ox + 8 * s), Math.round(oy + top * s), Math.round(ox + (PW - 8) * s), Math.round(oy + (top + vh) * s));
        Minecraft mc = Minecraft.getInstance();
        String dim = mc.level == null ? "" : mc.level.dimension().toString();
        if (all.isEmpty()) g.drawString(font, "Меток пока нет. Нажмите «+ Добавить».", 14, top + 6, 0xFF6B7280, true);
        for (int i = 0; i < all.size(); i++) {
            Waypoint w = all.get(i);
            int py = top + i * ROW_H - Math.round(scroll);
            if (py + ROW_H < top || py > top + vh) continue;
            boolean active = w.id.equals(NyxvaultClient.waypoints().activeId());
            Draw.round(g, 8, py, PW - 16, ROW_H - 3, UiSettings.theme.panel);
            Draw.border(g, 8, py, PW - 16, ROW_H - 3, active ? accent : 0xFF2A2A4A);
            g.fill(14, py + 6, 22, py + 14, w.color | 0xFF000000);
            String name = (active ? "* " : "") + w.name + (w.enabled ? "" : " (выкл.)") + (w.autoRemove ? "  [авто]" : "");
            g.drawString(font, trim(name, 190), 28, py + 4, 0xFFFFFFFF, true);
            String dist = mc.player == null ? "" : (w.dimension.equals(dim)
                    ? String.format(Locale.ROOT, "  %.0f м", w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ()))
                    : "  другое измерение");
            g.drawString(font, trim(fmt(w.x) + " " + fmt(w.y) + " " + fmt(w.z) + dist, 220), 28, py + 15, 0xFF9CA3AF, true);
            button(g, mx, my, PW - 16 - 150, py + 4, 46, 16, active ? "Активна" : "Выбрать", 0xFF374151);
            button(g, mx, my, PW - 16 - 100, py + 4, 46, 16, "Изм.", 0xFF374151);
            button(g, mx, my, PW - 16 - 50, py + 4, 50, 16, "Удалить", 0xFFEF4444);
        }
        g.disableScissor();
        float max = Math.max(0, all.size() * ROW_H - vh);
        if (max > 0) { // scrollbar
            int th = Math.max(16, Math.round(vh * (vh / (vh + max))));
            int ty = top + Math.round((vh - th) * (scroll / max));
            g.fill(PW - 6, top, PW - 3, top + vh, 0x55000000);
            g.fill(PW - 6, ty, PW - 3, ty + th, accent);
        }
        g.drawString(font, "Колесо или перетаскивание: прокрутка. Автоудаление работает при включённой настройке в модуле «Метки мира».", 12, PH - 14, 0xFF6B7280, false);
    }

    private void field(GuiGraphics g, float mx, float my, int idx, int x, int y, int w, String label, int accent) {
        g.drawString(font, label, x, y - 10, 0xFF9CA3AF, true);
        boolean foc = focus == idx;
        Draw.round(g, x, y, w, 16, 0xFF000000);
        Draw.border(g, x, y, w, 16, foc ? accent : 0xFF374151);
        boolean caret = foc && (System.currentTimeMillis() / 500) % 2 == 0;
        g.drawString(font, trim(fields[idx].toString(), w - 10) + (caret ? "_" : ""), x + 4, y + 4, 0xFFFFFFFF, true);
    }

    private void drawEdit(GuiGraphics g, float mx, float my, int accent) {
        g.drawString(font, editing == null ? "Новая метка" : "Редактирование метки", 12, 10, 0xFFFFFFFF, true);
        field(g, mx, my, 0, 14, 44, 392, "Название", accent);
        field(g, mx, my, 1, 14, 82, 124, "X", accent);
        field(g, mx, my, 2, 150, 82, 124, "Y", accent);
        field(g, mx, my, 3, 286, 82, 120, "Z", accent);
        button(g, mx, my, 14, 106, 110, 18, "Моя позиция", accent);

        g.drawString(font, "Цвет", 14, 140, 0xFF9CA3AF, true);
        for (int i = 0; i < ColorSetting.PRESETS.length; i++) {
            int cx = 14 + i * 26;
            int c = ColorSetting.PRESETS[i];
            g.fill(cx, 152, cx + 20, 168, c | 0xFF000000);
            if ((c | 0xFF000000) == (editColor | 0xFF000000)) Draw.border(g, cx - 2, 150, 24, 20, 0xFFFFFFFF);
        }
        button(g, mx, my, 14, 178, 250, 18, "Автоудаление при прибытии: " + (editAuto ? "ВКЛ" : "ВЫКЛ"), editAuto ? accent : 0xFF374151);
        if (!error.isEmpty()) g.drawString(font, error, 14, 204, 0xFFEF4444, true);
        button(g, mx, my, 14, 222, 110, 20, "Сохранить", 0xFF22C55E);
        button(g, mx, my, 132, 222, 110, 20, "Отмена", 0xFFEF4444);
        g.drawString(font, "Tab: следующее поле, Enter: сохранить, Esc: отмена", 250, 228, 0xFF6B7280, false);
    }

    private void drawConfirm(GuiGraphics g, float mx, float my, int accent) {
        g.fill(0, 0, PW, PH, 0xAA000000);
        int x = 60, y = 80, w = PW - 120, h = 84;
        Draw.round(g, x, y, w, h, UiSettings.theme.background);
        Draw.border(g, x, y, w, h, 0xFFEF4444);
        String q = "Удалить метку «" + (toDelete == null ? "" : trim(toDelete.name, 150)) + "»?";
        g.drawString(font, q, x + (w - font.width(q)) / 2, y + 16, 0xFFFFFFFF, true);
        g.drawString(font, "Это действие нельзя отменить.", x + (w - font.width("Это действие нельзя отменить.")) / 2, y + 30, 0xFF9CA3AF, true);
        button(g, mx, my, x + 30, y + 54, 90, 20, "Да, удалить", 0xFFEF4444);
        button(g, mx, my, x + w - 120, y + 54, 90, 20, "Нет", 0xFF374151);
    }

    // ------------------------------------------------------------------ actions

    private void startEdit(Waypoint w) {
        editing = w;
        error = "";
        focus = 0;
        if (w == null) {
            fields[0].setLength(0); fields[0].append("Метка ").append(NyxvaultClient.waypoints().all().size() + 1);
            fillPosition();
            editColor = ColorSetting.PRESETS[0];
            editAuto = false; // per-waypoint auto-remove is off by default
        } else {
            fields[0].setLength(0); fields[0].append(w.name);
            fields[1].setLength(0); fields[1].append(fmt(w.x));
            fields[2].setLength(0); fields[2].append(fmt(w.y));
            fields[3].setLength(0); fields[3].append(fmt(w.z));
            editColor = w.color;
            editAuto = w.autoRemove;
        }
        mode = Mode.EDIT;
    }

    private void fillPosition() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { error = "Игрок не в мире."; return; }
        fields[1].setLength(0); fields[1].append((long) Math.floor(mc.player.getX()));
        fields[2].setLength(0); fields[2].append((long) Math.floor(mc.player.getY()));
        fields[3].setLength(0); fields[3].append((long) Math.floor(mc.player.getZ()));
        error = "";
    }

    private static Double parse(StringBuilder b) {
        String t = b.toString().trim().replace(',', '.');
        if (t.isEmpty() || t.equals("-") || t.equals(".") || t.equals("-.")) return null;
        try {
            double d = Double.parseDouble(t);
            return Double.isFinite(d) ? d : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void save() {
        String name = fields[0].toString().trim();
        if (name.isEmpty()) { error = "Введите название."; focus = 0; return; }
        Double x = parse(fields[1]), y = parse(fields[2]), z = parse(fields[3]);
        if (x == null) { error = "X: введите число."; focus = 1; return; }
        if (y == null) { error = "Y: введите число."; focus = 2; return; }
        if (z == null) { error = "Z: введите число."; focus = 3; return; }
        if (Math.abs(x) > 30_000_000 || Math.abs(z) > 30_000_000) { error = "X и Z должны быть в пределах ±30 000 000."; return; }
        if (y < -2048 || y > 4096) { error = "Y должен быть от -2048 до 4096."; focus = 2; return; }
        Waypoint w = editing;
        if (w == null) {
            w = new Waypoint();
            Minecraft mc = Minecraft.getInstance();
            w.dimension = mc.level == null ? "" : mc.level.dimension().toString();
            w.radius = NyxvaultClient.waypoints().defaultRadius;
        }
        w.name = name;
        w.x = x; w.y = y; w.z = z;
        w.color = editColor | 0xFF000000;
        w.autoRemove = editAuto;
        if (editing == null) NyxvaultClient.waypoints().add(w);
        ConfigManager.requestSave();
        Notifications.push("Метка сохранена");
        mode = Mode.LIST;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = vx(event.x()), my = vy(event.y());
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        switch (mode) {
            case CONFIRM -> {
                int x = 60, y = 80, w = PW - 120;
                if (in(mx, my, x + 30, y + 54, 90, 20)) {
                    if (toDelete != null) {
                        NyxvaultClient.waypoints().remove(toDelete.id);
                        ConfigManager.requestSave();
                        Notifications.push("Метка удалена");
                    }
                    toDelete = null; mode = Mode.LIST;
                } else if (in(mx, my, x + w - 120, y + 54, 90, 20)) {
                    toDelete = null; mode = Mode.LIST;
                }
                return true;
            }
            case EDIT -> {
                if (in(mx, my, 14, 44, 392, 16)) focus = 0;
                else if (in(mx, my, 14, 82, 124, 16)) focus = 1;
                else if (in(mx, my, 150, 82, 124, 16)) focus = 2;
                else if (in(mx, my, 286, 82, 120, 16)) focus = 3;
                else if (in(mx, my, 14, 106, 110, 18)) fillPosition();
                else if (in(mx, my, 14, 178, 250, 18)) editAuto = !editAuto;
                else if (in(mx, my, 14, 222, 110, 20)) save();
                else if (in(mx, my, 132, 222, 110, 20)) mode = Mode.LIST;
                else {
                    for (int i = 0; i < ColorSetting.PRESETS.length; i++) {
                        if (in(mx, my, 14 + i * 26, 152, 20, 16)) editColor = ColorSetting.PRESETS[i];
                    }
                }
                return true;
            }
            default -> {
                if (in(mx, my, 150, 6, 88, 18)) { startEdit(null); return true; }
                if (in(mx, my, 244, 6, 92, 18)) { sortByDistance = !sortByDistance; return true; }
                if (in(mx, my, 342, 6, 70, 18)) { onClose(); return true; }
                List<Waypoint> all = list();
                int top = 32;
                if (my >= top && my < top + 170) {
                    for (int i = 0; i < all.size(); i++) {
                        int py = top + i * ROW_H - Math.round(scroll);
                        Waypoint w = all.get(i);
                        if (in(mx, my, PW - 16 - 150, py + 4, 46, 16)) { NyxvaultClient.waypoints().select(w.id); return true; }
                        if (in(mx, my, PW - 16 - 100, py + 4, 46, 16)) { startEdit(w); return true; }
                        if (in(mx, my, PW - 16 - 50, py + 4, 50, 16)) { toDelete = w; mode = Mode.CONFIRM; return true; }
                    }
                }
                dragY = (int) event.y();
                return true;
            }
        }
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (mode == Mode.LIST && dragY != Integer.MIN_VALUE) {
            scrollTarget -= (float) (dy / s);
            scroll = scrollTarget;
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragY = Integer.MIN_VALUE;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (mode != Mode.LIST) return false;
        scrollTarget -= (float) scrollY * 30f;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (mode == Mode.CONFIRM) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { toDelete = null; mode = Mode.LIST; }
            return true;
        }
        if (mode == Mode.EDIT) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { mode = Mode.LIST; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { save(); return true; }
            if (key == GLFW.GLFW_KEY_TAB) { focus = (focus + 1) % fields.length; return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                StringBuilder f = fields[focus];
                if (f.length() > 0) f.setLength(f.length() - 1);
                return true;
            }
            return true; // swallow other keys so they never reach gameplay
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (mode != Mode.EDIT) return false;
        int cp = event.codepoint();
        if (cp < 32 || cp == 127) return false;
        StringBuilder f = fields[focus];
        if (focus == 0) {
            if (f.length() < 32) f.appendCodePoint(cp);
        } else {
            char c = (char) cp;
            boolean ok = (c >= '0' && c <= '9') || c == '.' || c == ',' || (c == '-' && f.length() == 0);
            if (ok && f.length() < 12) f.append(c);
        }
        return true;
    }
}
