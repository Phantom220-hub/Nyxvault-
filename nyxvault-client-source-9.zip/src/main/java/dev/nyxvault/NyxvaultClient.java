package dev.nyxvault;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.gui.ClickGuiScreen;
import dev.nyxvault.gui.HudEditorScreen;
import dev.nyxvault.gui.WaypointScreen;
import dev.nyxvault.hud.HudRenderer;
import dev.nyxvault.module.ModuleManager;
import dev.nyxvault.module.combat.CombatState;
import dev.nyxvault.module.combat.TotemModules;
import dev.nyxvault.util.ClickTracker;
import dev.nyxvault.util.SessionStats;
import dev.nyxvault.waypoint.WaypointCommands;
import dev.nyxvault.waypoint.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NyxvaultClient implements ClientModInitializer {
    public static final String MOD_ID = "nyxvault";
    public static final Logger LOGGER = LoggerFactory.getLogger("NYXVAULT");

    private static ModuleManager modules;
    private static WaypointManager waypoints;

    private static KeyMapping openGui, openHudEditor, panic, openWaypoints;

    public static ModuleManager modules() { return modules; }
    public static WaypointManager waypoints() { return waypoints; }

    @Override
    public void onInitializeClient() {
        waypoints = new WaypointManager();
        modules = new ModuleManager();
        modules.get("Watermark").setEnabled(true); // sensible first-run default
        ConfigManager.load();
        modules.interfaceModule.apply();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.nyxvault.gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        openHudEditor = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.nyxvault.hud_editor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
        openWaypoints = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.nyxvault.waypoints", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
        panic = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.nyxvault.panic", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));

        HudRenderer.init();

        ClientTickEvents.END_CLIENT_TICK.register(NyxvaultClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.save());

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClientSide() && entity instanceof LivingEntity le) CombatState.onAttack(le);
            return InteractionResult.PASS; // never cancel or alter the attack
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> WaypointCommands.register(dispatcher));

        LOGGER.info("NYXVAULT CLIENT initialized ({} modules)", modules.all().size());
    }

    private static void tick(Minecraft mc) {
        try {
            while (openGui.consumeClick()) mc.setScreen(new ClickGuiScreen());
            while (openHudEditor.consumeClick()) if (mc.player != null) mc.setScreen(new HudEditorScreen());
            while (openWaypoints.consumeClick()) if (mc.player != null && mc.screen == null) mc.setScreen(new WaypointScreen(null));
            while (panic.consumeClick()) modules.panic();
            if (WaypointScreen.pendingOpen && mc.screen == null && mc.player != null) {
                WaypointScreen.pendingOpen = false;
                mc.setScreen(new WaypointScreen(null));
            }

            ClickTracker.tick(mc);
            SessionStats.tick(mc);
            TotemModules.Tracker.tick(mc);
            CombatState.tick(mc);
            modules.tick(mc);
            if (mc.player != null) waypoints.tick(mc);
            ConfigManager.tickSave();
        } catch (Throwable t) {
            LOGGER.error("Unhandled error in NYXVAULT tick", t);
        }
    }
}
