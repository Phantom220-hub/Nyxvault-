package dev.nyxvault.gui;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.render.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;

/** Small text prompt (used by text settings such as the custom nick). Enter saves, Esc cancels. */
public final class TextInputScreen extends Screen {
    private static final int PW = 300, PH = 120;

    private final String prompt;
    private final int maxLength;
    private final Screen parent;
    private final Consumer<String> onDone;
    private final StringBuilder text = new StringBuilder();
    private float s = 1f, ox, oy;

    public TextInputScreen(String prompt, String current, int maxLength, Screen parent, Consumer<String> onDone) {
        super(Component.literal(prompt));
        this.prompt = prompt;
        this.maxLength = maxLength;
        this.parent = parent;
        this.onDone = onDone;
        text.append(current == null ? "" : current);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() { minecraft.setScreen(parent); }

    private void confirm() {
        onDone.accept(text.toString());
        minecraft.setScreen(parent);
    }

    private void layout() {
        s = Math.max(0.5f, Math.min(2.5f, Math.min(width / (PW + 16f), height / (PH + 16f))));
        ox = (width - PW * s) / 2f;
        oy = (height - PH * s) / 2f;
    }

    private static boolean in(float mx, float my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void button(GuiGraphics g, float mx, float my, int x, int y, int w, int h, String label, int accent) {
        boolean hov = in(mx, my, x, y, w, h);
        Draw.round(g, x, y, w, h, hov ? 0xFF1B1B3A : UiSettings.theme.panel);
        Draw.border(g, x, y, w, h, accent);
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        layout();
        float mx = (float) ((mouseX - ox) / s), my = (float) ((mouseY - oy) / s);
        g.fill(0, 0, width, height, 0xAA000000);
        g.pose().pushMatrix();
        g.pose().translate(ox, oy);
        g.pose().scale(s, s);
        int accent = UiSettings.accent();
        Draw.round(g, 0, 0, PW, PH, UiSettings.theme.background);
        Draw.border(g, 0, 0, PW, PH, accent);
        g.drawString(font, prompt, 12, 10, 0xFFFFFFFF, true);
        Draw.round(g, 12, 28, PW - 24, 22, 0xFF0B0B1A);
        Draw.border(g, 12, 28, PW - 24, 22, accent);
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        g.drawString(font, text + (caret ? "_" : ""), 18, 35, 0xFFFFFFFF, true);
        String cnt = text.length() + "/" + maxLength;
        g.drawString(font, cnt, PW - 18 - font.width(cnt), 58, 0xFF6B7280, true);
        g.drawString(font, "Enter - сохранить, Esc - отмена", 12, 58, 0xFF6B7280, true);
        button(g, mx, my, 12, 88, 130, 22, "Сохранить", accent);
        button(g, mx, my, PW - 12 - 130, 88, 130, 22, "Отмена", 0xFF6B7280);
        g.pose().popMatrix();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        layout();
        float mx = (float) ((event.x() - ox) / s), my = (float) ((event.y() - oy) / s);
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        if (in(mx, my, 12, 88, 130, 22)) { confirm(); return true; }
        if (in(mx, my, PW - 12 - 130, 88, 130, 22)) { onClose(); return true; }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { confirm(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (text.length() > 0) text.setLength(text.length() - 1);
            return true;
        }
        return true; // swallow other keys so they never reach gameplay
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if (cp < 32 || cp == 127) return true;
        if (text.length() < maxLength) text.appendCodePoint(cp);
        return true;
    }
}
