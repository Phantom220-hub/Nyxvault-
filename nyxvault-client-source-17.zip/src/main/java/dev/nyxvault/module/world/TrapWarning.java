package dev.nyxvault.module.world;

import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.Indicators;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Block awareness: warns when blocks of the types you selected are close. It only reads blocks of
 * chunks that are already loaded on your client, and by default only blocks with an exposed face.
 * It does not know anyone's intentions, does not break blocks and does not move you.
 */
public final class TrapWarning extends OverlayModule {
    private final BoolSetting obsidian = add(new BoolSetting("Obsidian", true));
    private final BoolSetting cobweb = add(new BoolSetting("Cobweb", true));
    private final BoolSetting tnt = add(new BoolSetting("TNT", true));
    private final BoolSetting lava = add(new BoolSetting("Lava", false));
    private final BoolSetting anvil = add(new BoolSetting("Anvil", false));
    private final BoolSetting dripstone = add(new BoolSetting("Pointed Dripstone", false));
    private final BoolSetting fire = add(new BoolSetting("Fire", false));
    private final NumberSetting radius = add(NumberSetting.integer("Detection Radius", 4, 2, 8));
    private final BoolSetting visibleOnly = add(new BoolSetting("Exposed Blocks Only", true));
    private final ColorSetting color = add(new ColorSetting("Warning Color", 0xFFEF4444));
    private final NumberSetting opacity = add(NumberSetting.decimal("Warning Opacity", 0.6, 0.1, 1.0, 0.05));
    private final BoolSetting sound = add(new BoolSetting("Sound", false));
    private final BoolSetting arrow = add(new BoolSetting("Direction Indicator", true));

    private int tick;
    private boolean found, notified;
    private BlockPos nearest = BlockPos.ZERO;
    private String nearestName = "";
    private double nearestDist;

    public TrapWarning() {
        super("Trap Warning", "Warns when selected blocks are close (loaded, exposed blocks only). Awareness only; no automatic actions.", Category.WORLD);
    }

    @Override protected void onEnable() { found = false; notified = false; tick = 0; }
    @Override public void onWorldChange() { found = false; notified = false; }

    private boolean watched(BlockState s) {
        return (obsidian.get() && s.is(Blocks.OBSIDIAN)) || (cobweb.get() && s.is(Blocks.COBWEB))
                || (tnt.get() && s.is(Blocks.TNT)) || (lava.get() && s.is(Blocks.LAVA))
                || (anvil.get() && s.is(Blocks.ANVIL)) || (dripstone.get() && s.is(Blocks.POINTED_DRIPSTONE))
                || (fire.get() && s.is(Blocks.FIRE));
    }

    @Override public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) { found = false; return; }
        if (++tick % 10 != 0) return;
        BlockPos c = mc.player.blockPosition();
        int r = radius.asInt();
        double best = Double.MAX_VALUE;
        boolean any = false;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    pos.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (!mc.level.hasChunkAt(pos)) continue;
                    BlockState s = mc.level.getBlockState(pos);
                    if (!watched(s)) continue;
                    if (visibleOnly.get() && !exposed(mc, pos)) continue;
                    double d = mc.player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                    if (d < best) { best = d; nearest = pos.immutable(); nearestName = s.getBlock().getName().getString(); any = true; }
                }
            }
        }
        found = any;
        if (any) {
            nearestDist = Math.sqrt(best);
            if (!notified) {
                notified = true;
                Notifications.push("Рядом: " + nearestName, 1);
                if (sound.get()) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7f));
            }
        } else notified = false;
    }

    private static boolean exposed(Minecraft mc, BlockPos pos) {
        for (Direction d : Direction.values()) {
            if (mc.level.getBlockState(pos.relative(d)).isAir()) return true;
        }
        return false;
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (!found || mc.player == null) return;
        float pulse = 0.75f + 0.25f * (float) Math.sin(System.currentTimeMillis() / 180.0);
        Indicators.vignette(g, mc, color.get(), opacity.asFloat() * pulse, 14);
        String t = String.format("Внимание: %s рядом (%.1f м)", nearestName, nearestDist);
        g.drawString(mc.font, t, mc.getWindow().getGuiScaledWidth() / 2 - mc.font.width(t) / 2, 52,
                Draw.alpha(color.get(), 1f), true);
        if (arrow.get()) {
            Indicators.edge(g, mc, nearest.getX() + 0.5 - mc.player.getX(), nearest.getZ() + 0.5 - mc.player.getZ(),
                    Draw.alpha(color.get(), opacity.asFloat()), 8);
        }
    }
}
