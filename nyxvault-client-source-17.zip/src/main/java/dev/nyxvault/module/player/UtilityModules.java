package dev.nyxvault.module.player;

import dev.nyxvault.util.Lang;
import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.InventoryUtil;
import dev.nyxvault.util.Notifications;
import dev.nyxvault.waypoint.Waypoint;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Consolidated resource warnings plus small quality-of-life modules. */
public final class UtilityModules {
    private UtilityModules() { }

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] ARMOR_NAMES = {"Helmet", "Chestplate", "Leggings", "Boots"};

    /**
     * One module for low totems, armor durability and item stock. Each warning fires once when the
     * value crosses its threshold and is re-armed only after the value recovers (no spam).
     */
    public static final class ResourceAlerts extends Module {
        private final BoolSetting totemAlert = add(new BoolSetting("Low Totem Alert", true));
        private final NumberSetting totemThreshold = add(NumberSetting.integer("Totem Threshold", 1, 0, 10));
        private final BoolSetting armorAlert = add(new BoolSetting("Armor Durability Warning", true));
        private final NumberSetting armorPercent = add(NumberSetting.integer("Armor Threshold (%)", 20, 1, 90));
        private final BoolSetting gappleAlert = add(new BoolSetting("Golden Apple Alert", false));
        private final NumberSetting gappleThreshold = add(NumberSetting.integer("Golden Apple Threshold", 3, 0, 64));
        private final BoolSetting pearlAlert = add(new BoolSetting("Ender Pearl Alert", false));
        private final NumberSetting pearlThreshold = add(NumberSetting.integer("Ender Pearl Threshold", 2, 0, 16));

        private boolean totemWarned, gappleWarned, pearlWarned;
        private final boolean[] armorWarned = new boolean[4];
        private int tickGate;

        public ResourceAlerts() { super("Resource Alerts", "Warns once when totems, armor durability or chosen items run low.", Category.PLAYER); }

        @Override protected void onEnable() {
            totemWarned = gappleWarned = pearlWarned = false;
            java.util.Arrays.fill(armorWarned, false);
        }

        @Override public void onTick() {
            if ((tickGate++ & 3) != 0) return; // 5 checks per second is plenty
            Player p = Minecraft.getInstance().player;
            if (p == null) return;

            if (totemAlert.get()) {
                int c = dev.nyxvault.module.combat.TotemModules.Tracker.count();
                int thr = totemThreshold.asInt();
                if (c <= thr && !totemWarned) { Notifications.push(dev.nyxvault.util.Lang.t("LOW TOTEMS: ") + c, 1); totemWarned = true; }
                else if (c > thr) totemWarned = false;
            }
            if (armorAlert.get()) {
                for (int i = 0; i < 4; i++) {
                    ItemStack s = p.getItemBySlot(ARMOR[i]);
                    if (s.isEmpty() || !s.isDamageableItem()) { armorWarned[i] = false; continue; }
                    int max = s.getMaxDamage();
                    float pct = 100f * (max - s.getDamageValue()) / Math.max(1, max);
                    if (pct <= armorPercent.asInt() && !armorWarned[i]) {
                        Notifications.push(dev.nyxvault.util.Lang.t(ARMOR_NAMES[i]) + ": " + dev.nyxvault.util.Lang.t("durability") + " " + Math.round(pct) + "%", 1);
                        armorWarned[i] = true;
                    } else if (pct > armorPercent.asInt() + 5) armorWarned[i] = false;
                }
            }
            if (gappleAlert.get()) {
                int c = InventoryUtil.count(p, Items.GOLDEN_APPLE) + InventoryUtil.count(p, Items.ENCHANTED_GOLDEN_APPLE);
                if (c <= gappleThreshold.asInt() && !gappleWarned) { Notifications.push(dev.nyxvault.util.Lang.t("Golden apples low: ") + c); gappleWarned = true; }
                else if (c > gappleThreshold.asInt()) gappleWarned = false;
            }
            if (pearlAlert.get()) {
                int c = InventoryUtil.count(p, Items.ENDER_PEARL);
                if (c <= pearlThreshold.asInt() && !pearlWarned) { Notifications.push(dev.nyxvault.util.Lang.t("Ender pearls low: ") + c); pearlWarned = true; }
                else if (c > pearlThreshold.asInt()) pearlWarned = false;
            }
        }
    }

    /** Notifies once when health drops to the threshold; re-arms after healing. */
    public static final class HealthAlert extends Module {
        private final NumberSetting hearts = add(NumberSetting.integer("Threshold (hearts)", 4, 1, 10));
        private boolean warned;

        public HealthAlert() { super("Low Health Alert", "Warns once when your health falls to the chosen number of hearts.", Category.PLAYER); }

        @Override protected void onEnable() { warned = false; }

        @Override public void onTick() {
            Player p = Minecraft.getInstance().player;
            if (p == null || !p.isAlive()) return;
            float thr = hearts.asInt() * 2f;
            if (p.getHealth() <= thr && !warned) { Notifications.push(dev.nyxvault.util.Lang.t("LOW HEALTH: ") + String.format("%.1f", p.getHealth() / 2f) + " " + dev.nyxvault.util.Lang.t("hearts"), 1); warned = true; }
            else if (p.getHealth() > thr + 2f) warned = false;
        }
    }

    /** Creates a waypoint where you died (saved locally like any other waypoint). */
    public static final class DeathWaypoint extends Module {
        private final BoolSetting select = add(new BoolSetting("Select As Active", true));
        private boolean wasDead;
        private double dx, dy, dz;
        private String dim = "";

        public DeathWaypoint() { super("Death Waypoint", "Saves a waypoint at the place you died.", Category.WORLD); }

        @Override protected void onEnable() { wasDead = false; }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null || mc.level == null) return;
            boolean dead = p.getHealth() <= 0f || !p.isAlive();
            if (dead && !wasDead) {
                dx = p.getX(); dy = p.getY(); dz = p.getZ();
                dim = mc.level.dimension().toString();
                wasDead = true;
            } else if (!dead && wasDead) {
                wasDead = false;
                Waypoint w = new Waypoint();
                int n = 1;
                while (NyxvaultClient.waypoints().find("Смерть " + n) != null) n++;
                w.name = "Смерть " + n;
                w.description = "Место вашей смерти";
                w.group = "Смерти";
                w.x = dx; w.y = dy; w.z = dz;
                w.dimension = dim;
                w.color = 0xFFEF4444;
                w.autoRemove = false;
                NyxvaultClient.waypoints().add(w);
                if (select.get()) NyxvaultClient.waypoints().select(w.id);
                Notifications.push(dev.nyxvault.util.Lang.t("Death point saved: ") + w.name);
            }
        }
    }
}
