# NYXVAULT CLIENT 1.0.0

Client-side Fabric mod for **Minecraft Java Edition 1.21.11** (Java 21). Click GUI, draggable HUD, PvP feedback, waypoints.

> **Status: source complete, NOT yet compiled.**
> The development sandbox could not reach `maven.fabricmc.net`, Mojang or Gradle servers, so the project has
> never been built, launched in Minecraft, or tested on a server. Several Minecraft 1.21.11 APIs
> (input events, `Identifier`, `KeyMapping.Category`, `GuiGraphics` matrix stack) were written from
> knowledge of the 1.21.9–1.21.11 changes and may need small fixes on the first real compile.
> No JAR is included because none was honestly produced.

## Build the JAR (GitHub Actions — no local setup)
1. Create a GitHub repository and push this folder to it.
2. Open the **Actions** tab → *Build NYXVAULT CLIENT* (runs on every push, or click *Run workflow*).
3. When the run is green, open it and download **nyxvault-client-jar** from *Artifacts*.
   The JAR is `nyxvault-client-1.0.0.jar` (the `-sources` jar is not the mod).
4. If the run is red, open the log: compile errors name the exact file/line to fix.

## Build locally
Requires JDK 21 and Gradle 9.2+: `gradle build` → `build/libs/nyxvault-client-1.0.0.jar`.

## Install
Fabric Loader ≥ 0.18 and **Fabric API 0.141.3+1.21.11** for Minecraft 1.21.11; put the JAR in `.minecraft/mods`.

## Controls
- **Right Shift** – Click GUI (rebind in Controls → NYXVAULT). LMB toggle module, RMB settings, MMB set module key.
- HUD Editor and Panic key – unbound by default; bind them in Controls.
- Commands: `/nyx wp add <name>`, `addat <name> x y z`, `list`, `select`, `remove`, `toggle`, `group`, `export`, `import`.
- Config: `.minecraft/config/nyxvault/config.json` (corrupted files are moved aside, not deleted).

## Implemented (source written, unverified in-game)
Module framework (Boolean/Integer/Decimal/Enum/Color settings, keybinds, conflict detection, panic key), JSON config,
Click GUI (9 categories, search, cards, per-module settings, animations, GUI sounds, themes + custom accent, GUI scale),
HUD editor (drag, scale, enable/disable, reset), HUD elements (Watermark, FPS/frame time, Coordinates + facing,
CPS, Ping, Session timer, Keystrokes, Armor, Potion timers, Module list, Waypoint HUD), Custom Crosshair,
Hit Marker (marker shown only when the target's hurt animation is seen after your attack), Target HUD,
Brightness (restores previous value), Toggle Sprint, AutoClicker, waypoint manager with Auto-Remove on Arrival
(off by default; presets 1/2/3/5/10/custom, active-only or all-reached, notification + sound, same-dimension only),
waypoint import/export with validation, notification toasts.

## Not implemented
World-space waypoint markers/beams/labels, waypoint GUI screen (commands only), waypoint profiles, bookmarks UI,
event/explosion timers, Smooth Zoom/Scrolling, HUD Tags, music display, ambience, nearby players, low-durability alerts,
named config profiles, config import/export UI, crash helper, HolyWorld-specific features (no verified public API exists;
nothing is faked). Android/FoldCraftLauncher compatibility is untested.

## Rules notice
AutoClicker and other automation may violate server rules, including HolyWorld's. Nothing here is claimed to be
permitted on any server; follow each server's rules. The mod contains no anti-cheat bypasses, reach or aim changes.
