package dev.nyxvault.util;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** On-screen notifications plus bounded history. Accessed only from the client thread. */
public final class Notifications {
    public record Entry(String text, long createdMs) { }

    private static final int MAX_HISTORY = 50;
    private static final long LIFETIME_MS = 3500;
    private static final Deque<Entry> active = new ArrayDeque<>();
    private static final List<Entry> history = new ArrayList<>();

    private Notifications() { }

    public static void push(String text) {
        Entry e = new Entry(text, System.currentTimeMillis());
        active.addLast(e);
        history.add(e);
        if (history.size() > MAX_HISTORY) history.remove(0);
        while (active.size() > 5) active.removeFirst();
    }

    public static void prune() {
        long now = System.currentTimeMillis();
        while (!active.isEmpty() && now - active.peekFirst().createdMs() > LIFETIME_MS) active.removeFirst();
    }

    public static List<Entry> active() { return new ArrayList<>(active); }
    public static List<Entry> history() { return List.copyOf(history); }
    public static long lifetimeMs() { return LIFETIME_MS; }
}
