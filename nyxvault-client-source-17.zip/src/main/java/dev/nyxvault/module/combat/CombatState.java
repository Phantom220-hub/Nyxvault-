package dev.nyxvault.module.combat;

import dev.nyxvault.util.SessionStats;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;

/**
 * Tracks the local player's last attack target and whether the hit was confirmed by the client
 * (target started its hurt animation within a few ticks of our attack). It is a client-side
 * heuristic: the server decides actual damage.
 */
public final class CombatState {
    private static LivingEntity pending;
    private static int pendingAge;
    private static LivingEntity lastTarget;
    private static long lastTargetMs;
    private static long lastAttackMs;
    private static long confirmedHitMs;
    /** World position (body center) of the target at the last confirmed hit. */
    public static double hitX, hitY, hitZ;
    private static int combo;
    private static boolean hurtPrev;

    private CombatState() { }

    public static void onAttack(LivingEntity target) {
        pending = target;
        pendingAge = 0;
        lastTarget = target;
        lastTargetMs = System.currentTimeMillis();
        lastAttackMs = lastTargetMs;
        SessionStats.swings++;
    }

    public static void tick(Minecraft mc) {
        // Our own damage ends the combo.
        boolean hurt = mc.player != null && mc.player.hurtTime > 0;
        if (hurt && !hurtPrev) combo = 0;
        hurtPrev = hurt;

        if (pending == null) return;
        if (pending.hurtTime > 0) {
            confirmedHitMs = System.currentTimeMillis();
            hitX = pending.getX(); hitY = pending.getY() + pending.getBbHeight() * 0.5; hitZ = pending.getZ();
            SessionStats.hits++;
            combo++;
            if (combo > SessionStats.maxCombo) SessionStats.maxCombo = combo;
            pending = null;
        } else if (++pendingAge > 3) {
            pending = null; // swing without a visible hit
        }
    }

    public static LivingEntity target(long maxAgeMs) {
        if (lastTarget == null || !lastTarget.isAlive()) return null;
        return System.currentTimeMillis() - lastTargetMs <= maxAgeMs ? lastTarget : null;
    }

    public static long confirmedHitMs() { return confirmedHitMs; }
    public static long lastAttackMs() { return lastAttackMs; }
    public static int combo() { return combo; }
}
