package dev.nyxvault.module.world;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.waypoint.WaypointManager;

/** Settings for the waypoint system, including Auto-Remove on Arrival (off by default). */
public final class WaypointsModule extends Module {
    public enum Preset { BLOCKS_1(1), BLOCKS_2(2), BLOCKS_3(3), BLOCKS_5(5), BLOCKS_10(10), CUSTOM(-1);
        final int blocks;
        Preset(int b) { blocks = b; }
    }

    private final BoolSetting autoRemove = add(new BoolSetting("Auto-Remove on Arrival", false));
    private final EnumSetting<WaypointManager.RemoveMode> mode = add(new EnumSetting<>("Removal Mode", WaypointManager.RemoveMode.ACTIVE_ONLY));
    private final EnumSetting<Preset> preset = add(new EnumSetting<>("Arrival Radius", Preset.BLOCKS_3));
    private final NumberSetting custom = add(NumberSetting.decimal("Custom Radius", 4.0, 0.5, 100.0, 0.5));
    private final BoolSetting notify = add(new BoolSetting("Notification", true));
    private final BoolSetting sound = add(new BoolSetting("Sound", true));

    public WaypointsModule() {
        super("Waypoints", "Waypoint settings. Manage waypoints in the Waypoints screen or with /nyx wp ...", Category.WORLD);
        setEnabled(true);
    }

    @Override public boolean panicEligible() { return false; }

    /** Copies settings into the manager (cheap; runs each tick). */
    public void syncTo(WaypointManager m) {
        m.autoRemove = enabled() && autoRemove.get();
        m.removeMode = mode.get();
        m.defaultRadius = preset.get() == Preset.CUSTOM ? custom.get() : preset.get().blocks;
        m.notify = notify.get();
        m.sound = sound.get();
    }

    @Override public void onTick() { syncTo(NyxvaultClient.waypoints()); }
}
